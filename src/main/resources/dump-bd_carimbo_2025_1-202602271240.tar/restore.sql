--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4 (Debian 17.4-1.pgdg110+2)
-- Dumped by pg_dump version 17.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE bd_carimbo_2025_1;
--
-- Name: bd_carimbo_2025_1; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE bd_carimbo_2025_1 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE bd_carimbo_2025_1 OWNER TO postgres;

\connect bd_carimbo_2025_1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: dbo; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA dbo;


ALTER SCHEMA dbo OWNER TO postgres;

--
-- Name: tiger; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA tiger;


ALTER SCHEMA tiger OWNER TO postgres;

--
-- Name: tiger_data; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA tiger_data;


ALTER SCHEMA tiger_data OWNER TO postgres;

--
-- Name: topology; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA topology;


ALTER SCHEMA topology OWNER TO postgres;

--
-- Name: SCHEMA topology; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA topology IS 'PostGIS Topology schema';


--
-- Name: fuzzystrmatch; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS fuzzystrmatch WITH SCHEMA public;


--
-- Name: EXTENSION fuzzystrmatch; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION fuzzystrmatch IS 'determine similarities and distance between strings';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


--
-- Name: postgis_tiger_geocoder; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis_tiger_geocoder WITH SCHEMA tiger;


--
-- Name: EXTENSION postgis_tiger_geocoder; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis_tiger_geocoder IS 'PostGIS tiger geocoder and reverse geocoder';


--
-- Name: postgis_topology; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis_topology WITH SCHEMA topology;


--
-- Name: EXTENSION postgis_topology; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis_topology IS 'PostGIS topology spatial types and functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Filme.LogInfoMeioSimuladoLiberado; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo."Filme.LogInfoMeioSimuladoLiberado" (
    "Id_LogInfoMeioSimuladoLiberado" integer NOT NULL,
    "DH_Atual" timestamp without time zone NOT NULL,
    "DH_Simulada" timestamp without time zone NOT NULL,
    "MeioSimuladoLibRemovido" bit(1) NOT NULL,
    "Id_MeioSimulado" integer NOT NULL,
    "Id_Partido" integer NOT NULL,
    "Id_Papel" integer NOT NULL,
    "LoginControlador" character varying(50),
    "TipoMeioSimulado" character varying(50),
    "IdentificacaoOcultada" smallint NOT NULL
);


ALTER TABLE dbo."Filme.LogInfoMeioSimuladoLiberado" OWNER TO postgres;

--
-- Name: acompanhamento; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.acompanhamento (
    id_acompanhamento integer NOT NULL,
    id_meiosimulado_um integer NOT NULL,
    id_meiosimulado_um_acompanhamento integer,
    latitudeposgeo numeric(15,9),
    longitudeposgeo numeric(15,9),
    marcacao numeric(15,9),
    distancia double precision,
    tipoacompanhamento integer,
    removida smallint,
    movimento integer,
    datahoratermino character varying(15)
);


ALTER TABLE dbo.acompanhamento OWNER TO postgres;

--
-- Name: acompanhamentomav; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.acompanhamentomav (
    id_meiosimulado integer NOT NULL,
    id_finalidade integer NOT NULL,
    id_acompanhado integer,
    datahoramovimento character varying(14)
);


ALTER TABLE dbo.acompanhamentomav OWNER TO postgres;

--
-- Name: area; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.area (
    id_meiosimulado integer NOT NULL,
    id_finalidade integer NOT NULL,
    tabelaarea character varying(50),
    situacao integer,
    movimento integer,
    eixo double precision NOT NULL,
    eixoacompanhamento double precision NOT NULL
);


ALTER TABLE dbo.area OWNER TO postgres;

--
-- Name: areaambiental; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.areaambiental (
    id_meiosimulado integer NOT NULL,
    diainicio double precision NOT NULL,
    horainicio double precision NOT NULL,
    id_previsaometeorologica integer NOT NULL,
    direcaovento character varying(2),
    horaporsol double precision NOT NULL,
    horanascersol double precision NOT NULL,
    profundidadecamada double precision NOT NULL,
    perfilsonoro character varying(50),
    propagacaoeletromagnetica character varying(50),
    percentagemceu character varying(50),
    temperaturamar double precision NOT NULL,
    horaporlua double precision NOT NULL,
    horanascerlua double precision NOT NULL,
    faselua character varying(50),
    rumocorrente integer,
    veloccorrente double precision
);


ALTER TABLE dbo.areaambiental OWNER TO postgres;

--
-- Name: areapoligonal; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.areapoligonal (
    id_meiosimulado integer NOT NULL
);


ALTER TABLE dbo.areapoligonal OWNER TO postgres;

--
-- Name: areasetorial; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.areasetorial (
    id_meiosimulado integer NOT NULL,
    limitedireito double precision NOT NULL,
    limiteesquerdo double precision NOT NULL,
    limiteinterno double precision NOT NULL,
    limiteexterno double precision NOT NULL
);


ALTER TABLE dbo.areasetorial OWNER TO postgres;

--
-- Name: armamento; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.armamento (
    id_armamento integer NOT NULL,
    nome character varying(50),
    tabelaarmamento character varying(50),
    cargaexplosiva double precision,
    observacao character varying(100),
    empregoarmamento character varying(50)
);


ALTER TABLE dbo.armamento OWNER TO postgres;

--
-- Name: armasas; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.armasas (
    id_armamento integer NOT NULL,
    numprojsalva integer NOT NULL,
    agentelancadorabrev character varying(10),
    alcancemaximo double precision,
    tipo_armasas character varying(50)
);


ALTER TABLE dbo.armasas OWNER TO postgres;

--
-- Name: base; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.base (
    id_base integer NOT NULL,
    nome character varying(50),
    tipobase character varying(50),
    tipobasenum integer,
    id_partido integer NOT NULL,
    extensaocais double precision,
    caladomaximo double precision,
    latitude numeric(15,9),
    longitude numeric(15,9),
    classereparo character varying(600),
    facilidadereparo character varying(600),
    fundeadnummaxnavio integer,
    fundeadcaladomax integer,
    capachangaragem double precision,
    observacao character varying(100),
    "Login" character varying(50)
);


ALTER TABLE dbo.base OWNER TO postgres;

--
-- Name: bomba; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.bomba (
    id_armamento integer NOT NULL,
    tipobomba character varying(50),
    agentelancadorabrev character varying(10),
    pai double precision,
    trigrama character varying(3),
    nomeguiagemabrev character varying(50),
    alcanceeficaz double precision
);


ALTER TABLE dbo.bomba OWNER TO postgres;

--
-- Name: canhao; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.canhao (
    id_armamento integer NOT NULL,
    calibretuboalma character varying(50),
    cadenciatiromantida integer NOT NULL,
    cadenciatirorapida integer NOT NULL,
    numtuboalma character varying(50),
    alcancemaximo double precision,
    alcanceeficaz double precision
);


ALTER TABLE dbo.canhao OWNER TO postgres;

--
-- Name: classeefetivapista; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.classeefetivapista (
    classe_atual integer NOT NULL,
    classe_efetiva integer NOT NULL
);


ALTER TABLE dbo.classeefetivapista OWNER TO postgres;

--
-- Name: codigoerros; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.codigoerros (
    codigoerro integer NOT NULL,
    storedprocedure character varying(100),
    erro character varying(200),
    msgerro character varying(200),
    observacao text
);


ALTER TABLE dbo.codigoerros OWNER TO postgres;

--
-- Name: componentetarefa; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.componentetarefa (
    id_meiosimulado integer NOT NULL,
    id_organizacaotarefa integer NOT NULL,
    situacao integer NOT NULL,
    id_gt integer
);


ALTER TABLE dbo.componentetarefa OWNER TO postgres;

--
-- Name: configuracao; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.configuracao (
    id_configuracao integer NOT NULL,
    id_meiosimulado integer NOT NULL,
    codconfiguracao integer,
    codraioacaoconfiguracao integer NOT NULL,
    caracteristicaconfiguracao character varying(50),
    carga integer NOT NULL,
    capactanquecombexterno integer,
    qtdetanques integer,
    listacabidestanque character varying(50),
    coeficientepos double precision,
    raioacaoaa integer,
    raioacaobb integer,
    qtdebrs_ativa integer,
    alcancemaximobrs double precision,
    listacabidesbrs_ativa character varying(50),
    qtderc integer,
    listacabidesrc character varying(50),
    classecaracteristica character varying(10),
    qtdebrs_passiva integer,
    listacabidesbrs_passiva character varying(50)
);


ALTER TABLE dbo.configuracao OWNER TO postgres;

--
-- Name: dano; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.dano (
    "ID_Plataforma" integer NOT NULL,
    "m_PercentDanoTotal" numeric(15,9),
    "m_DuracaoMaximaReparoBase" numeric(15,9),
    "m_ValorApresentado" character varying(600)
);


ALTER TABLE dbo.dano OWNER TO postgres;

--
-- Name: danoespecifico; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.danoespecifico (
    "ID_DanoEspecifico" integer NOT NULL,
    "ID_TipoDano" integer,
    "ID_Plataforma" integer,
    "LocalReparo" character varying(50),
    "TempoReparoMar" double precision,
    "DHInicioReparoMar_str" character varying(50),
    "TempoReparoBase" double precision,
    "DHInicioReparoBase_str" character varying(50),
    "Perdas" character varying(50)
);


ALTER TABLE dbo.danoespecifico OWNER TO postgres;

--
-- Name: dd_propulsao; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.dd_propulsao (
    "Id_Propulsao" integer NOT NULL,
    "TipoRecursoLogistico" character varying(50),
    "RecursoLogistico" character varying(50),
    "Id_TipoRecursoLogistico" integer,
    "Id_RecursoLogistico" integer,
    "Nome" character varying(10)
);


ALTER TABLE dbo.dd_propulsao OWNER TO postgres;

--
-- Name: dotacaoarmamento; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.dotacaoarmamento (
    id_armamento integer NOT NULL,
    "id_Localizacao" integer NOT NULL,
    "QtdeDotacao" integer,
    "QtdeRCB" integer,
    "QtdeCONS" integer,
    "Reparo" character varying(50),
    "ListaCabidesArm" character varying(50),
    "QtdeLancAvariados" integer,
    "Dano_Armamento" integer
);


ALTER TABLE dbo.dotacaoarmamento OWNER TO postgres;

--
-- Name: dotacaosensor; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.dotacaosensor (
    "Id_DotacaoSensor" integer NOT NULL,
    "Id_Sensor" integer NOT NULL,
    "Id_Localizacao" integer NOT NULL,
    "Situacao" character varying(50),
    "Configurado" smallint
);


ALTER TABLE dbo.dotacaosensor OWNER TO postgres;

--
-- Name: finalidadeacompanhamentomav; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.finalidadeacompanhamentomav (
    "Id_Finalidade" integer NOT NULL,
    "Nome" character varying(50)
);


ALTER TABLE dbo.finalidadeacompanhamentomav OWNER TO postgres;

--
-- Name: finalidadearea; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.finalidadearea (
    "Id_FinalidadeArea" integer NOT NULL,
    "Nome" character varying(50)
);


ALTER TABLE dbo.finalidadearea OWNER TO postgres;

--
-- Name: finalidadelinha; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.finalidadelinha (
    "Id_FinalidadeLinha" integer NOT NULL,
    "Nome" character varying(50)
);


ALTER TABLE dbo.finalidadelinha OWNER TO postgres;

--
-- Name: finalidadepontonotavel; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.finalidadepontonotavel (
    "Id_FinalidadePontoNotavel" integer NOT NULL,
    "Nome" character varying(50)
);


ALTER TABLE dbo.finalidadepontonotavel OWNER TO postgres;

--
-- Name: foguete; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.foguete (
    id_armamento integer NOT NULL,
    "PAI" double precision NOT NULL,
    "AgenteLancadorAbrev" character varying(50),
    "Trigrama" character varying(3),
    "AlcanceEficaz" double precision
);


ALTER TABLE dbo.foguete OWNER TO postgres;

--
-- Name: formatura; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.formatura (
    "Id_Formatura" integer NOT NULL,
    "Id_ModeloFormatura" integer NOT NULL,
    "Id_GuiaFormatura" integer,
    "Eixo" numeric(15,9),
    "Marcacao_Guia" numeric(15,9),
    "Distancia_Guia" numeric(15,9),
    "Id_UM" integer,
    "Login" character varying(50)
);


ALTER TABLE dbo.formatura OWNER TO postgres;

--
-- Name: glossario; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.glossario (
    id integer NOT NULL,
    compactado character varying(50),
    descompactado character varying(50)
);


ALTER TABLE dbo.glossario OWNER TO postgres;

--
-- Name: interceptacao; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.interceptacao (
    "Id_Interceptacao" integer NOT NULL,
    "Id_MeioSimulado_UM" integer NOT NULL,
    "Id_MeioSimulado_Interceptar" integer,
    "Id_MeioSimulado_Area" integer,
    "Id_Trajeto" integer,
    "id_PontoTrajeto" integer,
    "LadoDestino" integer,
    "VelocManobra" double precision,
    "LatitudePosGeo" numeric(15,9),
    "LongitudePosGeo" numeric(15,9),
    "Marcacao" numeric(15,9),
    "Distancia" double precision,
    "DataHoraTermino" character varying(15),
    "TipoInterceptacao" integer,
    "Removida" smallint,
    "NomeBase" character varying(50),
    "Movimento" integer
);


ALTER TABLE dbo.interceptacao OWNER TO postgres;

--
-- Name: itemconfiguracao; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.itemconfiguracao (
    "Id_ItemConfiguracao" integer NOT NULL,
    "Id_Configuracao" integer NOT NULL,
    "Id_Armamento" integer,
    "Id_Sensor" integer,
    "Quantidade" integer NOT NULL,
    "ListaCabideItem" character varying(50)
);


ALTER TABLE dbo.itemconfiguracao OWNER TO postgres;

--
-- Name: linha; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.linha (
    "Id_MeioSimulado" integer NOT NULL,
    "Id_Finalidade" integer,
    "TabelaLinha" character varying(50)
);


ALTER TABLE dbo.linha OWNER TO postgres;

--
-- Name: linhamarcacao; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.linhamarcacao (
    "Id_MeioSimulado" integer NOT NULL,
    "Marcacao" double precision,
    "Distancia" double precision
);


ALTER TABLE dbo.linhamarcacao OWNER TO postgres;

--
-- Name: linhapoligonal; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.linhapoligonal (
    "Id_MeioSimulado" integer NOT NULL
);


ALTER TABLE dbo.linhapoligonal OWNER TO postgres;

--
-- Name: localizacao; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.localizacao (
    "Id_Localizacao" integer NOT NULL,
    "Id_MeioSimulado_PlatSup" integer,
    "Id_MeioSimulado_PlatSub" integer,
    "Id_MeioSimulado_PlatAer" integer,
    "Id_Base" integer,
    "Id_MeioSimulado_PlatTerra" integer
);


ALTER TABLE dbo.localizacao OWNER TO postgres;

--
-- Name: logerrossp; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.logerrossp (
    "Id_Erro" integer NOT NULL,
    dh_erro timestamp without time zone NOT NULL,
    "NomeSP" character varying(200),
    "Num_Secao" integer,
    "CodigoMSSQL" integer NOT NULL,
    "UsuarioConectado" character varying(200),
    "Aplicacao" character varying(200),
    "MensagemErro" character varying(1000)
);


ALTER TABLE dbo.logerrossp OWNER TO postgres;

--
-- Name: logtransacoes; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.logtransacoes (
    "IDLog" integer NOT NULL,
    "NomeSP" character varying(100),
    "ParametrosSP" text,
    "DataHora" timestamp without time zone
);


ALTER TABLE dbo.logtransacoes OWNER TO postgres;

--
-- Name: macambiente; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.macambiente (
    "IdPersistencia" integer NOT NULL,
    "LoginUsuario" character varying(50),
    "TimeStamp" character varying(14),
    "NomePersistencia" character varying(100),
    "FGVER" integer NOT NULL,
    "FRVER" integer NOT NULL,
    "NomeCartaVector" character varying(200),
    "IntervaloAtualizacao" integer NOT NULL,
    "TamanhoSimbologia" integer NOT NULL,
    "EstadoBotaoAtualizacao" integer NOT NULL,
    "ContadorAcompMAV" integer NOT NULL,
    "ContadorModeloPlano" integer NOT NULL,
    "IdVisaoAtiva" integer NOT NULL,
    "PrefixoDeFiguraVisivel" integer NOT NULL
);


ALTER TABLE dbo.macambiente OWNER TO postgres;

--
-- Name: macarmamentovisivel; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.macarmamentovisivel (
    "IdPersistencia" integer NOT NULL,
    "TipoMeio" integer NOT NULL,
    "IdMeio" integer NOT NULL,
    "IdArmamento" integer NOT NULL,
    "NomeArma" character varying(50)
);


ALTER TABLE dbo.macarmamentovisivel OWNER TO postgres;

--
-- Name: maccartaraster; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.maccartaraster (
    "IdPersistencia" integer NOT NULL,
    "IdCartaRaster" integer NOT NULL,
    "NomeCartaRaster" character varying(100),
    "EscalaDe" integer NOT NULL,
    "EscalaPara" integer NOT NULL,
    "ResolucaoX" integer NOT NULL,
    "ResolucaoY" integer NOT NULL,
    "PosicaoMediaSegX" integer NOT NULL,
    "PosicaoMediaSegY" integer NOT NULL,
    "Visivel" integer NOT NULL,
    "RectLimiteSegLeft" integer NOT NULL,
    "RectLimiteSegTop" integer NOT NULL,
    "RectLimiteSegRight" integer NOT NULL,
    "RectLimiteSegBottom" integer NOT NULL,
    "CopyMode" integer NOT NULL,
    "IdEscala" integer NOT NULL
);


ALTER TABLE dbo.maccartaraster OWNER TO postgres;

--
-- Name: macdesenho; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.macdesenho (
    "IdPersistencia" integer NOT NULL,
    "NomeArquivoDesenho" character varying(200),
    "ArquivoDesenho" bytea
);


ALTER TABLE dbo.macdesenho OWNER TO postgres;

--
-- Name: macfiltropartido; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.macfiltropartido (
    "IdPersistencia" integer NOT NULL,
    "IdVisao" integer NOT NULL,
    "IdPartido" integer NOT NULL,
    "Visivel" integer NOT NULL
);


ALTER TABLE dbo.macfiltropartido OWNER TO postgres;

--
-- Name: macmarcador; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.macmarcador (
    "IdPersistencia" integer NOT NULL,
    "IdVisao" integer NOT NULL,
    "IdMarcador" integer NOT NULL,
    "Nome" character varying(100),
    "Escala" integer NOT NULL,
    "Latitude" integer NOT NULL,
    "Longitude" integer NOT NULL,
    "DeslocX" integer NOT NULL,
    "DeslocY" integer NOT NULL
);


ALTER TABLE dbo.macmarcador OWNER TO postgres;

--
-- Name: macmeiovisivel; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.macmeiovisivel (
    "IdPersistencia" integer NOT NULL,
    "TipoMeio" integer NOT NULL,
    "IdMeio" integer NOT NULL
);


ALTER TABLE dbo.macmeiovisivel OWNER TO postgres;

--
-- Name: macmodeloplano; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.macmodeloplano (
    "IdPersistencia" integer NOT NULL,
    "IdPlano" integer NOT NULL,
    "NomePlano" character varying(50),
    "LoginControlador" character varying(50),
    "LatOrigem" double precision NOT NULL,
    "LongOrigem" double precision NOT NULL,
    "Eixo" integer NOT NULL,
    "IdModelo" integer NOT NULL,
    "IdPartido" integer NOT NULL
);


ALTER TABLE dbo.macmodeloplano OWNER TO postgres;

--
-- Name: macplanovisivel; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.macplanovisivel (
    "IdPersistencia" integer NOT NULL,
    "IdPlano" integer NOT NULL
);


ALTER TABLE dbo.macplanovisivel OWNER TO postgres;

--
-- Name: macsensorvisivel; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.macsensorvisivel (
    "IdPersistencia" integer NOT NULL,
    "TipoMeio" integer NOT NULL,
    "IdMeio" integer NOT NULL,
    "IdSensor" integer NOT NULL,
    "NomeSensor" character varying(50)
);


ALTER TABLE dbo.macsensorvisivel OWNER TO postgres;

--
-- Name: mactrajetovisivel; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.mactrajetovisivel (
    "IdPersistencia" integer NOT NULL,
    "IdTrajeto" integer NOT NULL
);


ALTER TABLE dbo.mactrajetovisivel OWNER TO postgres;

--
-- Name: macvisao; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.macvisao (
    "IdPersistencia" integer NOT NULL,
    "IdVisao" integer NOT NULL,
    "WindowLeft" integer NOT NULL,
    "WindowTop" integer NOT NULL,
    "WindowWidth" integer NOT NULL,
    "WindowHeight" integer NOT NULL,
    "WindowState" integer NOT NULL,
    "CorMar" integer NOT NULL,
    "CorBrasil" integer NOT NULL,
    "CorIsobatimetrica" integer NOT NULL,
    "CorContinente" integer NOT NULL,
    "CorLago" integer NOT NULL,
    "CorRio" integer NOT NULL,
    "Escala" integer NOT NULL,
    "Fo" integer NOT NULL,
    "Lo" integer NOT NULL,
    "DeslocMoveX" integer NOT NULL,
    "DeslocMoveY" integer NOT NULL,
    "AmbFigura" bigint NOT NULL,
    "AmbSimbFigura" bigint NOT NULL,
    "AmbNomeFigura" bigint NOT NULL,
    "AmbNomeConexao" bigint NOT NULL,
    "BtnGradeVisivel" integer NOT NULL,
    "BtnDestruidaAbatida" integer NOT NULL,
    "BtnMSliberado" integer NOT NULL,
    "BtnMSlibContato" integer
);


ALTER TABLE dbo.macvisao OWNER TO postgres;

--
-- Name: macvisualarma; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.macvisualarma (
    "IdPersistencia" integer NOT NULL,
    "TipoMeio" integer NOT NULL,
    "IdMeio" integer NOT NULL,
    "TipoAlcanceArmamento" integer NOT NULL,
    "AlcanceArmamentoVisivel" integer NOT NULL,
    "ComPreenchimento" integer NOT NULL
);


ALTER TABLE dbo.macvisualarma OWNER TO postgres;

--
-- Name: macvisualsensor; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.macvisualsensor (
    "IdPersistencia" integer NOT NULL,
    "TipoMeio" integer NOT NULL,
    "IdMeio" integer NOT NULL,
    "TipoAlcanceSensor" integer NOT NULL,
    "AlcanceSensorVisivel" integer NOT NULL,
    "AlcanceMageVisivel" integer NOT NULL,
    "ComPreenchimento" integer NOT NULL
);


ALTER TABLE dbo.macvisualsensor OWNER TO postgres;

--
-- Name: meioexterno; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.meioexterno (
    "Id_MeioSimulado" integer NOT NULL,
    "Tipo" character varying(50),
    "Subtipo" character varying(50),
    "DH_Informacao" character varying(14),
    "Observacoes" character varying(500),
    "Origem" character varying(20),
    "Id_Na_Origem" integer NOT NULL
);


ALTER TABLE dbo.meioexterno OWNER TO postgres;

--
-- Name: meiosimulado; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.meiosimulado (
    "id_MeioSimulado" integer NOT NULL,
    "Nome" character varying(50),
    "AcaoMS" character varying(100),
    id_partido integer,
    "Rumo" double precision,
    "VelocAvanco" double precision,
    "Latitude" numeric(15,9),
    "Longitude" numeric(15,9),
    "Id_MSS" integer,
    "DataHora" character varying(14),
    "TabelaMeioSimulado" character varying(50),
    "Id_trajeto" integer,
    "Id_UM" integer,
    "VelocTrajeto" double precision,
    "ProximoPonto" integer,
    "Trajeto_UltimoPonto" integer,
    "Plano_VoltasRestantes" integer,
    "Id_Plano" integer,
    "Login" character varying(50),
    "Observacao" character varying(100)
);


ALTER TABLE dbo.meiosimulado OWNER TO postgres;

--
-- Name: meiosimuladoliberado; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.meiosimuladoliberado (
    "Id_MeioSimulado" integer NOT NULL,
    "Id_Partido" integer NOT NULL,
    "Id_Papel" integer NOT NULL,
    "LoginControlador" character varying(50),
    "TipoMeioSimulado" character varying(50),
    "IdentificacaoOcultada" smallint NOT NULL
);


ALTER TABLE dbo.meiosimuladoliberado OWNER TO postgres;

--
-- Name: meiosimuladomav; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.meiosimuladomav (
    "id_MeioSimulado" integer NOT NULL,
    "Nome" character varying(50),
    "AcaoMS" character varying(100),
    id_partido integer,
    "Rumo" double precision,
    "VelocAvanco" double precision,
    "Latitude" numeric(15,9),
    "Longitude" numeric(15,9),
    "Id_MSS" integer,
    "DataHora" character varying(14),
    "TabelaMeioSimulado" character varying(50),
    "Id_trajeto" integer,
    "Id_UM" integer,
    "VelocTrajeto" double precision,
    "ProximoPonto" integer,
    "Trajeto_UltimoPonto" integer,
    "Plano_VoltasRestantes" integer,
    "Id_Plano" integer,
    "Login" character varying(50),
    "Observacao" character varying(100)
);


ALTER TABLE dbo.meiosimuladomav OWNER TO postgres;

--
-- Name: mina; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.mina (
    id_armamento integer NOT NULL,
    "AgenteLancadorAbrev" character varying(10),
    "AtuacaoArmamentoAbrev" character varying(50),
    "Peso" double precision NOT NULL,
    "Profundidade" character varying(50),
    "TipoAlvo" character varying(50),
    "TipoMina" character varying(50)
);


ALTER TABLE dbo.mina OWNER TO postgres;

--
-- Name: missil; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.missil (
    id_armamento integer NOT NULL,
    "PAI" double precision,
    "PAM" double precision,
    "PAA" double precision,
    "NomeGuiagemAbrev" character varying(50),
    "Veloc" double precision,
    "AgenteLancadorAbrev" character varying(10),
    "Trigrama" character varying(3),
    "TipoMissil" character varying(50),
    "TipoMissilNum" integer,
    "AlcanceEficaz" double precision
);


ALTER TABLE dbo.missil OWNER TO postgres;

--
-- Name: modeloformatura; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.modeloformatura (
    "Id_ModeloFormatura" integer NOT NULL,
    "Nome" character varying(51),
    "TipoFormatura" character varying(1),
    "PatrulhaSetores" character varying(1)
);


ALTER TABLE dbo.modeloformatura OWNER TO postgres;

--
-- Name: modeloplano; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.modeloplano (
    "Id_ModeloPlano" integer NOT NULL,
    "Nome" character varying(50),
    "TipoPlano" character varying(1),
    id_partido integer
);


ALTER TABLE dbo.modeloplano OWNER TO postgres;

--
-- Name: mss_constante; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.mss_constante (
    "Id_MSSConstante" integer NOT NULL,
    "Nome" character varying(50),
    "Id_TipoRecursoLogisitico" integer NOT NULL,
    "id_RecursoLogistico" integer NOT NULL
);


ALTER TABLE dbo.mss_constante OWNER TO postgres;

--
-- Name: nri; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.nri (
    "Id_MeioSimulado" integer NOT NULL,
    "VelocAvanco" integer NOT NULL,
    "NRI" double precision NOT NULL
);


ALTER TABLE dbo.nri OWNER TO postgres;

--
-- Name: organizacaotarefa; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.organizacaotarefa (
    "Id_OrganizacaoTarefa" integer NOT NULL,
    nome character varying(50),
    "Id_OrganizacaoTarefa_Sup" integer,
    "Situacao" integer NOT NULL,
    "HoraAtivacao" character varying(14),
    "TipoAtivacao" character varying(3),
    "Id_partido" integer NOT NULL
);


ALTER TABLE dbo.organizacaotarefa OWNER TO postgres;

--
-- Name: organizacaotarefaliberada; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.organizacaotarefaliberada (
    "Id_OrganizacaoTarefa" integer NOT NULL,
    "Id_Partido" integer NOT NULL,
    "Id_Papel" integer NOT NULL,
    "LoginControlador" character varying(50)
);


ALTER TABLE dbo.organizacaotarefaliberada OWNER TO postgres;

--
-- Name: partido; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.partido (
    id_partido integer NOT NULL,
    "Nome" character varying(50),
    "CodigoCor" integer NOT NULL,
    "NomeCor" character varying(50),
    "Neutro" character varying(1)
);


ALTER TABLE dbo.partido OWNER TO postgres;

--
-- Name: pdv; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.pdv (
    "Id_PDV" integer NOT NULL,
    "Login_De" character varying(30),
    "GRTA" character varying(30),
    "Sala" character varying(30),
    "Data" character varying(30),
    "Criacao" character varying(30),
    "Liberacao" character varying(30),
    "SeqNumAltPdv" integer,
    "OffsetPrimeiroEvento" integer,
    "XML" text,
    "ControladorNotificado" bit(1),
    "Identificacao" character varying(50),
    "Tipo" character varying(3),
    "Invisivel" bit(1) NOT NULL
);


ALTER TABLE dbo.pdv OWNER TO postgres;

--
-- Name: pista; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.pista (
    id_pista integer NOT NULL,
    "Classe" integer NOT NULL,
    "CapacCarga" character varying(50),
    "CompPista" character varying(50),
    "Pavimentacao" character varying(50)
);


ALTER TABLE dbo.pista OWNER TO postgres;

--
-- Name: pistabase; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.pistabase (
    id_pista integer NOT NULL,
    id_base integer NOT NULL,
    "QuantPista" integer
);


ALTER TABLE dbo.pistabase OWNER TO postgres;

--
-- Name: plano; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.plano (
    "Id_Plano" integer NOT NULL,
    "Id_ModeloPlano" integer NOT NULL,
    "Id_MS_Referencia" integer,
    "Id_Partido" integer NOT NULL,
    "Id_Base_Referencia" integer,
    "Nome" character varying(50),
    "Latitude_Ref" numeric(15,9),
    "Longitude_Ref" numeric(15,9),
    "Distancia_Ref" double precision,
    "Marcacao_Ref" numeric(15,9),
    "Eixo" integer,
    "Movimento" integer,
    "Login" character varying(50)
);


ALTER TABLE dbo.plano OWNER TO postgres;

--
-- Name: plantapropulsora; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.plantapropulsora (
    "Id_PlantaPropulsora" integer NOT NULL,
    "TipoPlanta" character varying(5),
    "Descricao" character varying(50),
    "DesignacaoPlanta" character varying(15)
);


ALTER TABLE dbo.plantapropulsora OWNER TO postgres;

--
-- Name: plataformaaerea; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.plataformaaerea (
    "id_MeioSimulado" integer NOT NULL,
    "id_Localizacao" integer,
    "id_LocalizacaoPousada" integer,
    "NomeTipoAeronave" character varying(50),
    "Id_SituacaoPlataforma" integer NOT NULL,
    "Modelo" character varying(50),
    "Embarcado" character varying(1),
    "TipoAsa" character varying(50),
    "IndiceSortidas" character varying(15),
    "HorasMes" double precision,
    "TipoMotorAeronave" character varying(50),
    "QtdeMotores" integer,
    "Propulsao" character varying(3),
    "Empuxo" double precision,
    "ConsumoMedio" double precision,
    "Altura" double precision,
    "Comprimento" double precision,
    "Largura" double precision,
    "HangaragemS2" double precision,
    "AreaAsas" double precision,
    "DiametroRA" double precision,
    "PesoBasico" double precision,
    "PesoMaximo" double precision,
    "PesoSupAsa" double precision,
    "PesoPotencia" double precision,
    "CargaUtil" double precision,
    "GeometriaVariavel" character varying(1),
    "RazaoSubida" double precision,
    "TetoServico" double precision,
    "TetoVooLibrado" double precision,
    "VelocMAXAlto" double precision,
    "VelocMAXBaixo" double precision,
    "VelocCruzeiroAlto" double precision,
    "VelocCruzeiroBaixo" double precision,
    "Altitude" double precision,
    "HorizontalSubida" double precision,
    "Navegacao" character varying(50),
    "Bloqueio" character varying(1),
    "EquipamentoBloqueio" character varying(50),
    "EmpregoAeronave" character varying(50),
    "ReabastecimentoVoo" character varying(1),
    "OperacaoAeronave" character varying(50),
    "InterceptacaoAeronave" character varying(50),
    "AtaqueAeronave" character varying(50),
    "AltitudePerfilVooA" double precision,
    "AltitudePerfilVooB" double precision,
    "Autonomia" double precision,
    "PerfilVoo" character varying(3),
    "CteConsumo1" double precision,
    "CteConsumo2" double precision,
    "CtePatrulha" double precision,
    "DanoVeloc" double precision,
    "IFF" character varying(1),
    "MAGE" character varying(1),
    "VelocLogistica" double precision,
    "Id_ConfiguracaoCorrente" integer,
    "HF" character varying(10),
    "UHF" character varying(10),
    "VHF" character varying(10),
    "Observacao" character varying(50),
    "Id_Pista" integer,
    "Id_TipoPropulsao" integer,
    "Id_RecursoPropulsao" integer,
    "DanoSensor" double precision,
    "OutrosSistemasComunicacao" character varying(50),
    "Sigla" character varying(10),
    "EmEspera" character varying(1),
    "DHTerminoEspera" character varying(15)
);


ALTER TABLE dbo.plataformaaerea OWNER TO postgres;

--
-- Name: plataformasubmarina; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.plataformasubmarina (
    "id_MeioSimulado" integer NOT NULL,
    id_base integer,
    "NomeClasse" character varying(50),
    "Id_SituacaoPlataforma" integer NOT NULL,
    "DeslocamentoSup" double precision,
    "DeslocamentoImerso" double precision,
    "Boca" double precision,
    "Calado" double precision,
    "Comprimento" double precision,
    "Esnorquel" character varying(50),
    "CoeficienteSeguranca" double precision,
    "Autonomia" double precision,
    "Manutencao" integer,
    "NumTubos" integer,
    "VelocECSup" integer,
    "VelocECImerso" integer,
    "VelocMAXImerso" integer,
    "VelocMMSuperficie" integer,
    "VelocMMEsnorquel" integer,
    "VelocMMNuclear" integer,
    "RAVECSup" integer,
    "RAVelocMAXImerso" integer,
    "RAVelocMMSup" integer,
    "RAVelocMMEsnorquel" integer,
    "RAVelocECImerso" integer,
    "RAVelocMMNuclear" integer,
    "ConsumoVelocECSup" double precision,
    "ConsumoVelocECImerso" double precision,
    "ConsumoVelocMAXImerso" double precision,
    "ConsumoVelocMMSup" double precision,
    "ConsumoVelocMMEsnorquel" double precision,
    "CargaMaxima" double precision,
    "CargaAtual" double precision,
    "CteDescarga1" double precision,
    "CteDescarga2" double precision,
    "Profundidade" integer,
    "Observacao" character varying(100),
    "Propulsao" character varying(3),
    "CteConsumo1" double precision,
    "CteConsumo2" double precision,
    "CtePatrulha" double precision,
    "DanoVeloc" double precision,
    "IFF" character varying(1),
    "MAGE" character varying(1),
    "BandaMAGE" character varying(50),
    "Despist" character varying(10),
    "VLF" character varying(10),
    "HF_LF" character varying(10),
    "VHF" character varying(10),
    "UHF" character varying(10),
    "CotaMaxOperac" double precision,
    "VelocLogistica" double precision,
    "Id_PlantaPropulsora" integer,
    "Id_TipoPropulsao" integer,
    "Id_RecursoPropulsao" integer,
    "DanoSensor" double precision,
    "Sigla" character varying(10),
    "m_DanoComs_HF" integer,
    "m_DanoComs_VHF" integer,
    "m_DanoComs_VLF" integer,
    "m_DanoComs_HF_LF" integer
);


ALTER TABLE dbo.plataformasubmarina OWNER TO postgres;

--
-- Name: plataformasuperficie; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.plataformasuperficie (
    "id_MeioSimulado" integer NOT NULL,
    id_base integer,
    "NomeClasse" character varying(50),
    "Id_SituacaoPlataforma" integer NOT NULL,
    "VelocLogistica" double precision,
    "CteConsumo1" double precision,
    "CteConsumo2" double precision,
    "CtePatrulha" double precision,
    "DanoVeloc" double precision,
    "CME" character varying(1),
    "BandaCME" character varying(50),
    "IFF" character varying(1),
    "MAGE" character varying(1),
    "BandaMAGE" character varying(50),
    "TipoPlatSuperficieNum" integer,
    "TipoPlatSuperficie" character varying(50),
    "Deslocamento" double precision NOT NULL,
    "Calado" double precision NOT NULL,
    "Comprimento" double precision NOT NULL,
    "Boca" double precision NOT NULL,
    "VelocEC" integer,
    "VelocMM" integer,
    "VelocMAX" integer,
    "RAVelocEC" integer,
    "RAVelocMM" integer,
    "RAVelocMAX" integer,
    "ConsumoVelocEC" double precision,
    "ConsumoVelocMM" double precision,
    "ConsumoVelocMAX" double precision,
    "Propulsao" character varying(3),
    "CapacDocagem" double precision,
    "CapacHangaragem" double precision,
    "AreaHangarOcupada" double precision,
    id_pista integer,
    "Observacao" character varying(100),
    "Janela" character varying(1),
    "VHF" character varying(10),
    "UHF" character varying(10),
    "HF" character varying(10),
    "Guia" integer,
    "Id_TipoPropulsao" integer,
    "Id_RecursoPropulsao" integer,
    "Id_PlantaPropulsora" integer,
    "DanoSensor" double precision,
    "Sigla" character varying(10),
    "m_DanoReabastecimento" integer,
    "m_DanoOpsAereasHE" integer,
    "m_DanoOpsAereasAsaFixa" integer,
    "m_DanoComs_HF" integer,
    "m_DanoComs_VHF" integer,
    "m_DanoComs_UHF" integer,
    "EhCapitanea" character varying(1)
);


ALTER TABLE dbo.plataformasuperficie OWNER TO postgres;

--
-- Name: plataformaterrestre; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.plataformaterrestre (
    "Id_MeioSimulado" integer NOT NULL,
    "TipoPlataformaTerrestreNum" integer,
    "TipoPlataformaTerrestre" character varying(50),
    "Id_SituacaoPlataforma" integer,
    "DanoVeloc" double precision,
    "DanoSensor" double precision,
    "VelocMax" double precision,
    "RAVelocMax" double precision,
    "ConsumoVelocMax" double precision,
    "Id_TipoPropulsao" integer,
    "Id_RecursoPropulsao" integer,
    "Observacao" character varying(100),
    "Sigla" character varying(10),
    "Id_LocalizacaoEmbarcada" integer
);


ALTER TABLE dbo.plataformaterrestre OWNER TO postgres;

--
-- Name: pontonotavel; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.pontonotavel (
    "Id_MeioSimulado" integer NOT NULL,
    "Id_Finalidade" integer NOT NULL
);


ALTER TABLE dbo.pontonotavel OWNER TO postgres;

--
-- Name: pontosarea; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.pontosarea (
    "Id_PontosArea" integer NOT NULL,
    "Id_MeioSimulado" integer NOT NULL,
    "Nome" character varying(50),
    "Marcacao" double precision NOT NULL,
    "Distancia" double precision NOT NULL
);


ALTER TABLE dbo.pontosarea OWNER TO postgres;

--
-- Name: pontoslinha; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.pontoslinha (
    "Id_MeioSimulado" integer NOT NULL,
    "Id_PontosLinha" integer NOT NULL,
    "Nome" character varying(50),
    "Marcacao" double precision NOT NULL,
    "Distancia" double precision NOT NULL
);


ALTER TABLE dbo.pontoslinha OWNER TO postgres;

--
-- Name: pontosmodeloformatura; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.pontosmodeloformatura (
    "Id_PontosModeloFormatura" integer NOT NULL,
    "Id_ModeloFormatura" integer NOT NULL,
    "Nome" character varying(50),
    "Marcacao" numeric(15,9),
    "Distancia" numeric(15,9)
);


ALTER TABLE dbo.pontosmodeloformatura OWNER TO postgres;

--
-- Name: pontosmodeloplano; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.pontosmodeloplano (
    "Id_PontosModeloPlano" integer NOT NULL,
    "Id_ModeloPlano" integer NOT NULL,
    "Nome" character varying(10),
    "Marcacao" double precision NOT NULL,
    "Distancia" double precision NOT NULL
);


ALTER TABLE dbo.pontosmodeloplano OWNER TO postgres;

--
-- Name: pontostrajeto; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.pontostrajeto (
    id_pontos integer NOT NULL,
    id_trajeto integer NOT NULL,
    "Nome" character varying(50),
    "Latitude" numeric(15,9),
    "Longitude" numeric(15,9),
    "DataHora" character varying(14),
    "Veloc" double precision NOT NULL
);


ALTER TABLE dbo.pontostrajeto OWNER TO postgres;

--
-- Name: postosformatura; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.postosformatura (
    "Id_PostosFormatura" integer NOT NULL,
    "Id_Formatura" integer NOT NULL,
    "Id_MS_posto" integer,
    "Nome" character varying(50),
    "Marcacao" numeric(15,9),
    "Distancia" numeric(15,9)
);


ALTER TABLE dbo.postosformatura OWNER TO postgres;

--
-- Name: previsaometeorologica; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.previsaometeorologica (
    "Id_PrevisaoMeteorologica" integer NOT NULL,
    "Tempo" character varying(50),
    "VelocVento" character varying(50),
    "PressaoAtm" integer NOT NULL,
    "EstadoMar" character varying(50),
    "Visibilidade" character varying(50),
    "Teto" character varying(50),
    "DegradacaoSensores" double precision NOT NULL,
    "MaximaVeloc" integer NOT NULL,
    "OperacoesAereas" character varying(50)
);


ALTER TABLE dbo.previsaometeorologica OWNER TO postgres;

--
-- Name: recursopropulsao; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.recursopropulsao (
    "Id_RecursoPropulsao" integer NOT NULL,
    "Id_RecursoLogistico" integer NOT NULL,
    "Id_TipoPropulsao" integer NOT NULL
);


ALTER TABLE dbo.recursopropulsao OWNER TO postgres;

--
-- Name: recursoslogisticos; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.recursoslogisticos (
    "Id_RecursoLogistico" integer NOT NULL,
    "Id_Localizacao" integer NOT NULL,
    "Nome" character varying(50),
    "NomeRecLog_Num" integer,
    "Tipo" character varying(50),
    "TipoRecLog_Num" integer,
    "Categoria" character varying(10),
    "CapacArmazenamento" double precision,
    "QtdeRCB" double precision,
    "QtdeCONSFNC" double precision,
    "NumeroTomadas" integer,
    "NumeroTanques" integer,
    "CapacMaxTanque" integer,
    "VazaoFNC" integer,
    "VazaoRCB" integer,
    "Id_Armamento" integer,
    "Id_Sensor" integer
);


ALTER TABLE dbo.recursoslogisticos OWNER TO postgres;

--
-- Name: sensor; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.sensor (
    "id_Sensor" integer NOT NULL,
    "TipoSensor" character varying(50),
    "Nome" character varying(50),
    "Modelo" character varying(50),
    "AlcanceMaximo" double precision,
    "Emprego" character varying(50),
    "ModoOperacao" character varying(50),
    "Dano_Sensor" integer
);


ALTER TABLE dbo.sensor OWNER TO postgres;

--
-- Name: situacaoplataforma; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.situacaoplataforma (
    "Id_SituacaoPlataforma" integer NOT NULL,
    "Nome" character varying(50),
    "TipoPlataforma" character varying(25),
    "Constante" integer
);


ALTER TABLE dbo.situacaoplataforma OWNER TO postgres;

--
-- Name: ssgn_acesso; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.ssgn_acesso (
    "Id_Funcao" integer NOT NULL,
    "Id_Recurso" integer NOT NULL,
    "Id_Fase" integer NOT NULL,
    "Acesso" character varying(10)
);


ALTER TABLE dbo.ssgn_acesso OWNER TO postgres;

--
-- Name: ssgn_auditoria; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.ssgn_auditoria (
    "DataHora" character varying(14),
    "Maquina" character varying(50),
    "LoginWindows" character varying(50),
    "Login" character varying(50),
    "BancoDados" character varying(50),
    "Id_Fase" integer,
    "Id_Funcao" integer,
    "Id_Recurso" integer,
    "Id_Papel" integer,
    "Situacao" character varying(50),
    "Observacao" character varying(200)
);


ALTER TABLE dbo.ssgn_auditoria OWNER TO postgres;

--
-- Name: ssgn_comando; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.ssgn_comando (
    "Id_MSS" integer NOT NULL,
    "Indice" integer,
    "DataHoraExec" character varying(14),
    "Login" character varying(50),
    "StatusComando" character varying(4),
    "FeedBack" integer,
    "Id_MCC" integer,
    "ComandoXML" character varying(100),
    "OffsetEnc" integer,
    "Id_FAB" character varying(100)
);


ALTER TABLE dbo.ssgn_comando OWNER TO postgres;

--
-- Name: ssgn_comando_pdv; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.ssgn_comando_pdv (
    "ID_PDV" character varying(100),
    "id_MSS" integer NOT NULL
);


ALTER TABLE dbo.ssgn_comando_pdv OWNER TO postgres;

--
-- Name: ssgn_comando_preab; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.ssgn_comando_preab (
    "ID_PREAB" character varying(100),
    "id_MSS" integer NOT NULL
);


ALTER TABLE dbo.ssgn_comando_preab OWNER TO postgres;

--
-- Name: ssgn_controlejogo; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.ssgn_controlejogo (
    "Jogo" character varying(50),
    "Versao" character varying(50),
    "Data_Criacao" character varying(15),
    "Id_Fase" integer,
    "DataHoraInicReal" character varying(14),
    "DataHoraInicSimulada" character varying(14),
    "DataHoraAtualReal" character varying(14),
    "DataHoraAtualSimulada" character varying(14),
    "Status" character varying(10),
    "MarchaReal" integer,
    "MarchaSimulada" integer,
    "Delta_T" integer,
    "StatusBackup" character varying(1),
    "TaxaBackup" integer,
    "StatusDeteccao" character varying(1),
    "TaxaDeteccao" integer,
    "TaxaAtuPlatAerea" integer,
    "TaxaAtuPlatSuperficie" integer,
    "TaxaAtuPlatSubmarina" integer,
    "TaxaAtuMeioSimulado" integer,
    "ContAtuPlatAereas" integer,
    "ContAtuPlatSuperficie" integer,
    "ContAtuPlatSubmarina" integer,
    "ContAtuMeioSimulado" integer,
    "ProximoIdMSS" integer,
    "ConstIDPass" integer,
    "DH_Exibicao" timestamp without time zone,
    "MinutosPingRecurso" integer
);


ALTER TABLE dbo.ssgn_controlejogo OWNER TO postgres;

--
-- Name: ssgn_exportacao_processamento; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.ssgn_exportacao_processamento (
    "Id_Exportacao_Processada" integer NOT NULL,
    "Id_Elemento_Exportado" integer NOT NULL,
    "TipoElementoExportacao" character varying(100),
    "NomeElemento" character varying(100),
    "Id_MeioSimulado_Importado" integer,
    "Id_ModeloPlano_Importado" integer,
    "Id_Trajeto_Importado" integer,
    "Id_Partido" integer NOT NULL,
    "ElementoImportado" integer NOT NULL
);


ALTER TABLE dbo.ssgn_exportacao_processamento OWNER TO postgres;

--
-- Name: ssgn_exportacaomav; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.ssgn_exportacaomav (
    "Id_ExportacaoMAV" integer NOT NULL,
    "Login" character varying(50),
    "LoginControlador" character varying(50),
    "Nome" character varying(50),
    "ConteudoXML" character varying(100)
);


ALTER TABLE dbo.ssgn_exportacaomav OWNER TO postgres;

--
-- Name: ssgn_fase; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.ssgn_fase (
    "Id_Fase" integer NOT NULL,
    "Nome" character varying(50)
);


ALTER TABLE dbo.ssgn_fase OWNER TO postgres;

--
-- Name: ssgn_hierarquiacomponente; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.ssgn_hierarquiacomponente (
    "Id_HierarquiaComponente" integer NOT NULL,
    "Id_TipoComponente" integer NOT NULL,
    "Codigo_MCC" character varying(50),
    "Codigo_Pai" character varying(50),
    "Stored_Procedure" character varying(50),
    "CamposApresentados" character varying(80),
    "CampoEnviado" character varying(30),
    "Composicao" character varying(20),
    "CamposParametro" character varying(50)
);


ALTER TABLE dbo.ssgn_hierarquiacomponente OWNER TO postgres;

--
-- Name: ssgn_itemacesso; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.ssgn_itemacesso (
    "Id_Funcao" integer NOT NULL,
    "Id_Recurso" integer NOT NULL,
    "Id_Fase" integer NOT NULL,
    "Id_TagItemMenu" integer NOT NULL
);


ALTER TABLE dbo.ssgn_itemacesso OWNER TO postgres;

--
-- Name: ssgn_itemmenurecurso; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.ssgn_itemmenurecurso (
    "Id_Recurso" integer NOT NULL,
    "Id_TagItemMenu" integer NOT NULL,
    "Nome" character varying(50),
    "Id_TagPai" integer NOT NULL,
    "Nivel" integer NOT NULL
);


ALTER TABLE dbo.ssgn_itemmenurecurso OWNER TO postgres;

--
-- Name: ssgn_logjogo; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.ssgn_logjogo (
    "Id_LogJogo" integer NOT NULL,
    "DH" character varying(14),
    "Id_Recurso" integer NOT NULL,
    "Login" character varying(50),
    "TipoMensagem" integer NOT NULL,
    "Mensagem" character varying(7900),
    "Id_ComandoMSS" integer,
    "Id_ComandoMCC" integer,
    "Id_ComandoEncadeado" integer,
    "Classif" integer,
    "DH_Real" character varying(14)
);


ALTER TABLE dbo.ssgn_logjogo OWNER TO postgres;

--
-- Name: ssgn_msslog; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.ssgn_msslog (
    "IndiceMensagem" integer NOT NULL,
    "Mensagem" character varying(600)
);


ALTER TABLE dbo.ssgn_msslog OWNER TO postgres;

--
-- Name: ssgn_papeisaplicfuncao; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.ssgn_papeisaplicfuncao (
    "Id_Funcao" integer NOT NULL,
    "Id_Papel" integer NOT NULL
);


ALTER TABLE dbo.ssgn_papeisaplicfuncao OWNER TO postgres;

--
-- Name: ssgn_recurso; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.ssgn_recurso (
    "Id_Recurso" integer NOT NULL,
    "Recurso" character varying(10),
    "DescricaoRecurso" character varying(50)
);


ALTER TABLE dbo.ssgn_recurso OWNER TO postgres;

--
-- Name: ssgn_recursologistico; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.ssgn_recursologistico (
    "Id_RecursoLogistico" integer NOT NULL,
    "Nome" character varying(50),
    "Categoria" character varying(10)
);


ALTER TABLE dbo.ssgn_recursologistico OWNER TO postgres;

--
-- Name: ssgn_temp_verificacaoidentificador; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.ssgn_temp_verificacaoidentificador (
    "tagUso" character varying(16),
    "Identificador" character varying(100),
    "Id_Partido" integer NOT NULL,
    "Login" character varying(100),
    "Id_Exportacao" integer NOT NULL,
    "Elemento" character varying(100),
    "DH_Criacao" date
);


ALTER TABLE dbo.ssgn_temp_verificacaoidentificador OWNER TO postgres;

--
-- Name: ssgn_tipocomponente; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.ssgn_tipocomponente (
    "Id_TipoComponente" integer NOT NULL,
    "Nome" character varying(50),
    "Icone" bytea,
    "Grupo" character varying(10),
    "TreeNode" bit(1) NOT NULL,
    "NomeArmamento" character varying(50),
    "PersistenciaEncadeamento" bit(1) NOT NULL,
    "AtualizacaoAutomatica" bit(1) NOT NULL,
    "FiltrarItemRaiz" bit(1) NOT NULL
);


ALTER TABLE dbo.ssgn_tipocomponente OWNER TO postgres;

--
-- Name: ssgnpingrecurso; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.ssgnpingrecurso (
    "Id_SSGNPingRecurso" integer NOT NULL,
    "NomeMaquina" character varying(256),
    "NomeRecurso" character varying(50),
    "DataHoraAtualizacao" timestamp without time zone NOT NULL
);


ALTER TABLE dbo.ssgnpingrecurso OWNER TO postgres;

--
-- Name: tabeladejogos; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.tabeladejogos (
    name character varying(256),
    size integer NOT NULL,
    low integer NOT NULL,
    high integer NOT NULL,
    "Cntrltype" smallint NOT NULL,
    phyname character varying(260),
    "Status" smallint NOT NULL
);


ALTER TABLE dbo.tabeladejogos OWNER TO postgres;

--
-- Name: tempdano; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.tempdano (
    "ID_Plataforma" integer NOT NULL,
    "m_PercentDanoTotal" double precision,
    "m_DuracaoMaximaReparoBase" double precision,
    "m_ValorApresentado" character varying(400)
);


ALTER TABLE dbo.tempdano OWNER TO postgres;

--
-- Name: tempglossario; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.tempglossario (
    id integer NOT NULL,
    compactado character varying(50),
    descompactado character varying(50)
);


ALTER TABLE dbo.tempglossario OWNER TO postgres;

--
-- Name: tipodano; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.tipodano (
    "ID_TipoDano" integer NOT NULL,
    "Descricao" character varying(50)
);


ALTER TABLE dbo.tipodano OWNER TO postgres;

--
-- Name: tipopropulsao; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.tipopropulsao (
    "Id_TipoPropulsao" integer NOT NULL,
    "TipoRecursoLogistico" character varying(50),
    "RecursoLogistico" character varying(50),
    "Id_TipoRecursoLogistico" integer,
    "Id_RecursoLogistico" integer,
    "Nome" character varying(10)
);


ALTER TABLE dbo.tipopropulsao OWNER TO postgres;

--
-- Name: tiporecursologistico; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.tiporecursologistico (
    "Id_TipoRecursoLogistico" integer NOT NULL,
    "Id_RecursoLogistico" integer NOT NULL,
    "TipoRecursoLogistico" character varying(50),
    "Id_Armamento" integer,
    "Id_Sensor" integer
);


ALTER TABLE dbo.tiporecursologistico OWNER TO postgres;

--
-- Name: torpedo; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.torpedo (
    id_armamento integer NOT NULL,
    "TipoTorpedo" character varying(50),
    "PAI" double precision,
    "PaiAS" double precision,
    "PaiASUP" double precision,
    "NomeBusca" character varying(50),
    "AgenteLancadorAbrev" character varying(50),
    "ProfundidadeMax" integer,
    "AlcanceMaximo" double precision,
    "VelocCorrida" integer
);


ALTER TABLE dbo.torpedo OWNER TO postgres;

--
-- Name: trajeto; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.trajeto (
    id_trajeto integer NOT NULL,
    "TipoTrajeto" character varying(50),
    "Nome" character varying(50),
    id_partido integer NOT NULL,
    "Login" character varying(50)
);


ALTER TABLE dbo.trajeto OWNER TO postgres;

--
-- Name: transitopatrulha; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.transitopatrulha (
    "id_MeioSimulado" integer NOT NULL,
    "VelocAvanco" integer NOT NULL,
    "TaxaIndiscricao" double precision NOT NULL
);


ALTER TABLE dbo.transitopatrulha OWNER TO postgres;

--
-- Name: transporteaeronave; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.transporteaeronave (
    "Id_MeioSimulado_PlatSup" integer NOT NULL,
    "Id_MeioSimulado_PlatAer" integer NOT NULL
);


ALTER TABLE dbo.transporteaeronave OWNER TO postgres;

--
-- Name: um; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.um (
    "Id_MeioSimulado_UM" integer NOT NULL,
    "id_Formatura" integer,
    "Id_AreaPatrulha" integer,
    "LadoDestino" integer,
    "Marcacao" numeric(15,9),
    "Distancia" double precision,
    "DataHoraTermino" character varying(15),
    "TipoUM" integer,
    "IncluidaEncadeado" integer
);


ALTER TABLE dbo.um OWNER TO postgres;

--
-- Name: visibilidadepartido; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.visibilidadepartido (
    "Id_partido" integer NOT NULL,
    "Id_partido_visivel" integer NOT NULL
);


ALTER TABLE dbo.visibilidadepartido OWNER TO postgres;

--
-- Data for Name: Filme.LogInfoMeioSimuladoLiberado; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo."Filme.LogInfoMeioSimuladoLiberado" ("Id_LogInfoMeioSimuladoLiberado", "DH_Atual", "DH_Simulada", "MeioSimuladoLibRemovido", "Id_MeioSimulado", "Id_Partido", "Id_Papel", "LoginControlador", "TipoMeioSimulado", "IdentificacaoOcultada") FROM stdin;
\.
COPY dbo."Filme.LogInfoMeioSimuladoLiberado" ("Id_LogInfoMeioSimuladoLiberado", "DH_Atual", "DH_Simulada", "MeioSimuladoLibRemovido", "Id_MeioSimulado", "Id_Partido", "Id_Papel", "LoginControlador", "TipoMeioSimulado", "IdentificacaoOcultada") FROM '$$PATH$$/5083.dat';

--
-- Data for Name: acompanhamento; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.acompanhamento (id_acompanhamento, id_meiosimulado_um, id_meiosimulado_um_acompanhamento, latitudeposgeo, longitudeposgeo, marcacao, distancia, tipoacompanhamento, removida, movimento, datahoratermino) FROM stdin;
\.
COPY dbo.acompanhamento (id_acompanhamento, id_meiosimulado_um, id_meiosimulado_um_acompanhamento, latitudeposgeo, longitudeposgeo, marcacao, distancia, tipoacompanhamento, removida, movimento, datahoratermino) FROM '$$PATH$$/5073.dat';

--
-- Data for Name: acompanhamentomav; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.acompanhamentomav (id_meiosimulado, id_finalidade, id_acompanhado, datahoramovimento) FROM stdin;
\.
COPY dbo.acompanhamentomav (id_meiosimulado, id_finalidade, id_acompanhado, datahoramovimento) FROM '$$PATH$$/5074.dat';

--
-- Data for Name: area; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.area (id_meiosimulado, id_finalidade, tabelaarea, situacao, movimento, eixo, eixoacompanhamento) FROM stdin;
\.
COPY dbo.area (id_meiosimulado, id_finalidade, tabelaarea, situacao, movimento, eixo, eixoacompanhamento) FROM '$$PATH$$/5075.dat';

--
-- Data for Name: areaambiental; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.areaambiental (id_meiosimulado, diainicio, horainicio, id_previsaometeorologica, direcaovento, horaporsol, horanascersol, profundidadecamada, perfilsonoro, propagacaoeletromagnetica, percentagemceu, temperaturamar, horaporlua, horanascerlua, faselua, rumocorrente, veloccorrente) FROM stdin;
\.
COPY dbo.areaambiental (id_meiosimulado, diainicio, horainicio, id_previsaometeorologica, direcaovento, horaporsol, horanascersol, profundidadecamada, perfilsonoro, propagacaoeletromagnetica, percentagemceu, temperaturamar, horaporlua, horanascerlua, faselua, rumocorrente, veloccorrente) FROM '$$PATH$$/5076.dat';

--
-- Data for Name: areapoligonal; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.areapoligonal (id_meiosimulado) FROM stdin;
\.
COPY dbo.areapoligonal (id_meiosimulado) FROM '$$PATH$$/5077.dat';

--
-- Data for Name: areasetorial; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.areasetorial (id_meiosimulado, limitedireito, limiteesquerdo, limiteinterno, limiteexterno) FROM stdin;
\.
COPY dbo.areasetorial (id_meiosimulado, limitedireito, limiteesquerdo, limiteinterno, limiteexterno) FROM '$$PATH$$/5078.dat';

--
-- Data for Name: armamento; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.armamento (id_armamento, nome, tabelaarmamento, cargaexplosiva, observacao, empregoarmamento) FROM stdin;
\.
COPY dbo.armamento (id_armamento, nome, tabelaarmamento, cargaexplosiva, observacao, empregoarmamento) FROM '$$PATH$$/5067.dat';

--
-- Data for Name: armasas; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.armasas (id_armamento, numprojsalva, agentelancadorabrev, alcancemaximo, tipo_armasas) FROM stdin;
\.
COPY dbo.armasas (id_armamento, numprojsalva, agentelancadorabrev, alcancemaximo, tipo_armasas) FROM '$$PATH$$/5070.dat';

--
-- Data for Name: base; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.base (id_base, nome, tipobase, tipobasenum, id_partido, extensaocais, caladomaximo, latitude, longitude, classereparo, facilidadereparo, fundeadnummaxnavio, fundeadcaladomax, capachangaragem, observacao, "Login") FROM stdin;
\.
COPY dbo.base (id_base, nome, tipobase, tipobasenum, id_partido, extensaocais, caladomaximo, latitude, longitude, classereparo, facilidadereparo, fundeadnummaxnavio, fundeadcaladomax, capachangaragem, observacao, "Login") FROM '$$PATH$$/5079.dat';

--
-- Data for Name: bomba; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.bomba (id_armamento, tipobomba, agentelancadorabrev, pai, trigrama, nomeguiagemabrev, alcanceeficaz) FROM stdin;
\.
COPY dbo.bomba (id_armamento, tipobomba, agentelancadorabrev, pai, trigrama, nomeguiagemabrev, alcanceeficaz) FROM '$$PATH$$/5071.dat';

--
-- Data for Name: canhao; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.canhao (id_armamento, calibretuboalma, cadenciatiromantida, cadenciatirorapida, numtuboalma, alcancemaximo, alcanceeficaz) FROM stdin;
\.
COPY dbo.canhao (id_armamento, calibretuboalma, cadenciatiromantida, cadenciatirorapida, numtuboalma, alcancemaximo, alcanceeficaz) FROM '$$PATH$$/5072.dat';

--
-- Data for Name: classeefetivapista; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.classeefetivapista (classe_atual, classe_efetiva) FROM stdin;
\.
COPY dbo.classeefetivapista (classe_atual, classe_efetiva) FROM '$$PATH$$/5068.dat';

--
-- Data for Name: codigoerros; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.codigoerros (codigoerro, storedprocedure, erro, msgerro, observacao) FROM stdin;
\.
COPY dbo.codigoerros (codigoerro, storedprocedure, erro, msgerro, observacao) FROM '$$PATH$$/5069.dat';

--
-- Data for Name: componentetarefa; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.componentetarefa (id_meiosimulado, id_organizacaotarefa, situacao, id_gt) FROM stdin;
\.
COPY dbo.componentetarefa (id_meiosimulado, id_organizacaotarefa, situacao, id_gt) FROM '$$PATH$$/5080.dat';

--
-- Data for Name: configuracao; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.configuracao (id_configuracao, id_meiosimulado, codconfiguracao, codraioacaoconfiguracao, caracteristicaconfiguracao, carga, capactanquecombexterno, qtdetanques, listacabidestanque, coeficientepos, raioacaoaa, raioacaobb, qtdebrs_ativa, alcancemaximobrs, listacabidesbrs_ativa, qtderc, listacabidesrc, classecaracteristica, qtdebrs_passiva, listacabidesbrs_passiva) FROM stdin;
\.
COPY dbo.configuracao (id_configuracao, id_meiosimulado, codconfiguracao, codraioacaoconfiguracao, caracteristicaconfiguracao, carga, capactanquecombexterno, qtdetanques, listacabidestanque, coeficientepos, raioacaoaa, raioacaobb, qtdebrs_ativa, alcancemaximobrs, listacabidesbrs_ativa, qtderc, listacabidesrc, classecaracteristica, qtdebrs_passiva, listacabidesbrs_passiva) FROM '$$PATH$$/5081.dat';

--
-- Data for Name: dano; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.dano ("ID_Plataforma", "m_PercentDanoTotal", "m_DuracaoMaximaReparoBase", "m_ValorApresentado") FROM stdin;
\.
COPY dbo.dano ("ID_Plataforma", "m_PercentDanoTotal", "m_DuracaoMaximaReparoBase", "m_ValorApresentado") FROM '$$PATH$$/5107.dat';

--
-- Data for Name: danoespecifico; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.danoespecifico ("ID_DanoEspecifico", "ID_TipoDano", "ID_Plataforma", "LocalReparo", "TempoReparoMar", "DHInicioReparoMar_str", "TempoReparoBase", "DHInicioReparoBase_str", "Perdas") FROM stdin;
\.
COPY dbo.danoespecifico ("ID_DanoEspecifico", "ID_TipoDano", "ID_Plataforma", "LocalReparo", "TempoReparoMar", "DHInicioReparoMar_str", "TempoReparoBase", "DHInicioReparoBase_str", "Perdas") FROM '$$PATH$$/5108.dat';

--
-- Data for Name: dd_propulsao; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.dd_propulsao ("Id_Propulsao", "TipoRecursoLogistico", "RecursoLogistico", "Id_TipoRecursoLogistico", "Id_RecursoLogistico", "Nome") FROM stdin;
\.
COPY dbo.dd_propulsao ("Id_Propulsao", "TipoRecursoLogistico", "RecursoLogistico", "Id_TipoRecursoLogistico", "Id_RecursoLogistico", "Nome") FROM '$$PATH$$/5082.dat';

--
-- Data for Name: dotacaoarmamento; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.dotacaoarmamento (id_armamento, "id_Localizacao", "QtdeDotacao", "QtdeRCB", "QtdeCONS", "Reparo", "ListaCabidesArm", "QtdeLancAvariados", "Dano_Armamento") FROM stdin;
\.
COPY dbo.dotacaoarmamento (id_armamento, "id_Localizacao", "QtdeDotacao", "QtdeRCB", "QtdeCONS", "Reparo", "ListaCabidesArm", "QtdeLancAvariados", "Dano_Armamento") FROM '$$PATH$$/5109.dat';

--
-- Data for Name: dotacaosensor; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.dotacaosensor ("Id_DotacaoSensor", "Id_Sensor", "Id_Localizacao", "Situacao", "Configurado") FROM stdin;
\.
COPY dbo.dotacaosensor ("Id_DotacaoSensor", "Id_Sensor", "Id_Localizacao", "Situacao", "Configurado") FROM '$$PATH$$/5110.dat';

--
-- Data for Name: finalidadeacompanhamentomav; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.finalidadeacompanhamentomav ("Id_Finalidade", "Nome") FROM stdin;
\.
COPY dbo.finalidadeacompanhamentomav ("Id_Finalidade", "Nome") FROM '$$PATH$$/5084.dat';

--
-- Data for Name: finalidadearea; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.finalidadearea ("Id_FinalidadeArea", "Nome") FROM stdin;
\.
COPY dbo.finalidadearea ("Id_FinalidadeArea", "Nome") FROM '$$PATH$$/5085.dat';

--
-- Data for Name: finalidadelinha; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.finalidadelinha ("Id_FinalidadeLinha", "Nome") FROM stdin;
\.
COPY dbo.finalidadelinha ("Id_FinalidadeLinha", "Nome") FROM '$$PATH$$/5086.dat';

--
-- Data for Name: finalidadepontonotavel; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.finalidadepontonotavel ("Id_FinalidadePontoNotavel", "Nome") FROM stdin;
\.
COPY dbo.finalidadepontonotavel ("Id_FinalidadePontoNotavel", "Nome") FROM '$$PATH$$/5087.dat';

--
-- Data for Name: foguete; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.foguete (id_armamento, "PAI", "AgenteLancadorAbrev", "Trigrama", "AlcanceEficaz") FROM stdin;
\.
COPY dbo.foguete (id_armamento, "PAI", "AgenteLancadorAbrev", "Trigrama", "AlcanceEficaz") FROM '$$PATH$$/5111.dat';

--
-- Data for Name: formatura; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.formatura ("Id_Formatura", "Id_ModeloFormatura", "Id_GuiaFormatura", "Eixo", "Marcacao_Guia", "Distancia_Guia", "Id_UM", "Login") FROM stdin;
\.
COPY dbo.formatura ("Id_Formatura", "Id_ModeloFormatura", "Id_GuiaFormatura", "Eixo", "Marcacao_Guia", "Distancia_Guia", "Id_UM", "Login") FROM '$$PATH$$/5112.dat';

--
-- Data for Name: glossario; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.glossario (id, compactado, descompactado) FROM stdin;
\.
COPY dbo.glossario (id, compactado, descompactado) FROM '$$PATH$$/5088.dat';

--
-- Data for Name: interceptacao; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.interceptacao ("Id_Interceptacao", "Id_MeioSimulado_UM", "Id_MeioSimulado_Interceptar", "Id_MeioSimulado_Area", "Id_Trajeto", "id_PontoTrajeto", "LadoDestino", "VelocManobra", "LatitudePosGeo", "LongitudePosGeo", "Marcacao", "Distancia", "DataHoraTermino", "TipoInterceptacao", "Removida", "NomeBase", "Movimento") FROM stdin;
\.
COPY dbo.interceptacao ("Id_Interceptacao", "Id_MeioSimulado_UM", "Id_MeioSimulado_Interceptar", "Id_MeioSimulado_Area", "Id_Trajeto", "id_PontoTrajeto", "LadoDestino", "VelocManobra", "LatitudePosGeo", "LongitudePosGeo", "Marcacao", "Distancia", "DataHoraTermino", "TipoInterceptacao", "Removida", "NomeBase", "Movimento") FROM '$$PATH$$/5113.dat';

--
-- Data for Name: itemconfiguracao; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.itemconfiguracao ("Id_ItemConfiguracao", "Id_Configuracao", "Id_Armamento", "Id_Sensor", "Quantidade", "ListaCabideItem") FROM stdin;
\.
COPY dbo.itemconfiguracao ("Id_ItemConfiguracao", "Id_Configuracao", "Id_Armamento", "Id_Sensor", "Quantidade", "ListaCabideItem") FROM '$$PATH$$/5114.dat';

--
-- Data for Name: linha; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.linha ("Id_MeioSimulado", "Id_Finalidade", "TabelaLinha") FROM stdin;
\.
COPY dbo.linha ("Id_MeioSimulado", "Id_Finalidade", "TabelaLinha") FROM '$$PATH$$/5115.dat';

--
-- Data for Name: linhamarcacao; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.linhamarcacao ("Id_MeioSimulado", "Marcacao", "Distancia") FROM stdin;
\.
COPY dbo.linhamarcacao ("Id_MeioSimulado", "Marcacao", "Distancia") FROM '$$PATH$$/5116.dat';

--
-- Data for Name: linhapoligonal; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.linhapoligonal ("Id_MeioSimulado") FROM stdin;
\.
COPY dbo.linhapoligonal ("Id_MeioSimulado") FROM '$$PATH$$/5117.dat';

--
-- Data for Name: localizacao; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.localizacao ("Id_Localizacao", "Id_MeioSimulado_PlatSup", "Id_MeioSimulado_PlatSub", "Id_MeioSimulado_PlatAer", "Id_Base", "Id_MeioSimulado_PlatTerra") FROM stdin;
\.
COPY dbo.localizacao ("Id_Localizacao", "Id_MeioSimulado_PlatSup", "Id_MeioSimulado_PlatSub", "Id_MeioSimulado_PlatAer", "Id_Base", "Id_MeioSimulado_PlatTerra") FROM '$$PATH$$/5118.dat';

--
-- Data for Name: logerrossp; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.logerrossp ("Id_Erro", dh_erro, "NomeSP", "Num_Secao", "CodigoMSSQL", "UsuarioConectado", "Aplicacao", "MensagemErro") FROM stdin;
\.
COPY dbo.logerrossp ("Id_Erro", dh_erro, "NomeSP", "Num_Secao", "CodigoMSSQL", "UsuarioConectado", "Aplicacao", "MensagemErro") FROM '$$PATH$$/5089.dat';

--
-- Data for Name: logtransacoes; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.logtransacoes ("IDLog", "NomeSP", "ParametrosSP", "DataHora") FROM stdin;
\.
COPY dbo.logtransacoes ("IDLog", "NomeSP", "ParametrosSP", "DataHora") FROM '$$PATH$$/5090.dat';

--
-- Data for Name: macambiente; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.macambiente ("IdPersistencia", "LoginUsuario", "TimeStamp", "NomePersistencia", "FGVER", "FRVER", "NomeCartaVector", "IntervaloAtualizacao", "TamanhoSimbologia", "EstadoBotaoAtualizacao", "ContadorAcompMAV", "ContadorModeloPlano", "IdVisaoAtiva", "PrefixoDeFiguraVisivel") FROM stdin;
\.
COPY dbo.macambiente ("IdPersistencia", "LoginUsuario", "TimeStamp", "NomePersistencia", "FGVER", "FRVER", "NomeCartaVector", "IntervaloAtualizacao", "TamanhoSimbologia", "EstadoBotaoAtualizacao", "ContadorAcompMAV", "ContadorModeloPlano", "IdVisaoAtiva", "PrefixoDeFiguraVisivel") FROM '$$PATH$$/5091.dat';

--
-- Data for Name: macarmamentovisivel; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.macarmamentovisivel ("IdPersistencia", "TipoMeio", "IdMeio", "IdArmamento", "NomeArma") FROM stdin;
\.
COPY dbo.macarmamentovisivel ("IdPersistencia", "TipoMeio", "IdMeio", "IdArmamento", "NomeArma") FROM '$$PATH$$/5094.dat';

--
-- Data for Name: maccartaraster; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.maccartaraster ("IdPersistencia", "IdCartaRaster", "NomeCartaRaster", "EscalaDe", "EscalaPara", "ResolucaoX", "ResolucaoY", "PosicaoMediaSegX", "PosicaoMediaSegY", "Visivel", "RectLimiteSegLeft", "RectLimiteSegTop", "RectLimiteSegRight", "RectLimiteSegBottom", "CopyMode", "IdEscala") FROM stdin;
\.
COPY dbo.maccartaraster ("IdPersistencia", "IdCartaRaster", "NomeCartaRaster", "EscalaDe", "EscalaPara", "ResolucaoX", "ResolucaoY", "PosicaoMediaSegX", "PosicaoMediaSegY", "Visivel", "RectLimiteSegLeft", "RectLimiteSegTop", "RectLimiteSegRight", "RectLimiteSegBottom", "CopyMode", "IdEscala") FROM '$$PATH$$/5095.dat';

--
-- Data for Name: macdesenho; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.macdesenho ("IdPersistencia", "NomeArquivoDesenho", "ArquivoDesenho") FROM stdin;
\.
COPY dbo.macdesenho ("IdPersistencia", "NomeArquivoDesenho", "ArquivoDesenho") FROM '$$PATH$$/5096.dat';

--
-- Data for Name: macfiltropartido; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.macfiltropartido ("IdPersistencia", "IdVisao", "IdPartido", "Visivel") FROM stdin;
\.
COPY dbo.macfiltropartido ("IdPersistencia", "IdVisao", "IdPartido", "Visivel") FROM '$$PATH$$/5105.dat';

--
-- Data for Name: macmarcador; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.macmarcador ("IdPersistencia", "IdVisao", "IdMarcador", "Nome", "Escala", "Latitude", "Longitude", "DeslocX", "DeslocY") FROM stdin;
\.
COPY dbo.macmarcador ("IdPersistencia", "IdVisao", "IdMarcador", "Nome", "Escala", "Latitude", "Longitude", "DeslocX", "DeslocY") FROM '$$PATH$$/5106.dat';

--
-- Data for Name: macmeiovisivel; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.macmeiovisivel ("IdPersistencia", "TipoMeio", "IdMeio") FROM stdin;
\.
COPY dbo.macmeiovisivel ("IdPersistencia", "TipoMeio", "IdMeio") FROM '$$PATH$$/5097.dat';

--
-- Data for Name: macmodeloplano; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.macmodeloplano ("IdPersistencia", "IdPlano", "NomePlano", "LoginControlador", "LatOrigem", "LongOrigem", "Eixo", "IdModelo", "IdPartido") FROM stdin;
\.
COPY dbo.macmodeloplano ("IdPersistencia", "IdPlano", "NomePlano", "LoginControlador", "LatOrigem", "LongOrigem", "Eixo", "IdModelo", "IdPartido") FROM '$$PATH$$/5098.dat';

--
-- Data for Name: macplanovisivel; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.macplanovisivel ("IdPersistencia", "IdPlano") FROM stdin;
\.
COPY dbo.macplanovisivel ("IdPersistencia", "IdPlano") FROM '$$PATH$$/5099.dat';

--
-- Data for Name: macsensorvisivel; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.macsensorvisivel ("IdPersistencia", "TipoMeio", "IdMeio", "IdSensor", "NomeSensor") FROM stdin;
\.
COPY dbo.macsensorvisivel ("IdPersistencia", "TipoMeio", "IdMeio", "IdSensor", "NomeSensor") FROM '$$PATH$$/5100.dat';

--
-- Data for Name: mactrajetovisivel; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.mactrajetovisivel ("IdPersistencia", "IdTrajeto") FROM stdin;
\.
COPY dbo.mactrajetovisivel ("IdPersistencia", "IdTrajeto") FROM '$$PATH$$/5101.dat';

--
-- Data for Name: macvisao; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.macvisao ("IdPersistencia", "IdVisao", "WindowLeft", "WindowTop", "WindowWidth", "WindowHeight", "WindowState", "CorMar", "CorBrasil", "CorIsobatimetrica", "CorContinente", "CorLago", "CorRio", "Escala", "Fo", "Lo", "DeslocMoveX", "DeslocMoveY", "AmbFigura", "AmbSimbFigura", "AmbNomeFigura", "AmbNomeConexao", "BtnGradeVisivel", "BtnDestruidaAbatida", "BtnMSliberado", "BtnMSlibContato") FROM stdin;
\.
COPY dbo.macvisao ("IdPersistencia", "IdVisao", "WindowLeft", "WindowTop", "WindowWidth", "WindowHeight", "WindowState", "CorMar", "CorBrasil", "CorIsobatimetrica", "CorContinente", "CorLago", "CorRio", "Escala", "Fo", "Lo", "DeslocMoveX", "DeslocMoveY", "AmbFigura", "AmbSimbFigura", "AmbNomeFigura", "AmbNomeConexao", "BtnGradeVisivel", "BtnDestruidaAbatida", "BtnMSliberado", "BtnMSlibContato") FROM '$$PATH$$/5102.dat';

--
-- Data for Name: macvisualarma; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.macvisualarma ("IdPersistencia", "TipoMeio", "IdMeio", "TipoAlcanceArmamento", "AlcanceArmamentoVisivel", "ComPreenchimento") FROM stdin;
\.
COPY dbo.macvisualarma ("IdPersistencia", "TipoMeio", "IdMeio", "TipoAlcanceArmamento", "AlcanceArmamentoVisivel", "ComPreenchimento") FROM '$$PATH$$/5103.dat';

--
-- Data for Name: macvisualsensor; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.macvisualsensor ("IdPersistencia", "TipoMeio", "IdMeio", "TipoAlcanceSensor", "AlcanceSensorVisivel", "AlcanceMageVisivel", "ComPreenchimento") FROM stdin;
\.
COPY dbo.macvisualsensor ("IdPersistencia", "TipoMeio", "IdMeio", "TipoAlcanceSensor", "AlcanceSensorVisivel", "AlcanceMageVisivel", "ComPreenchimento") FROM '$$PATH$$/5104.dat';

--
-- Data for Name: meioexterno; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.meioexterno ("Id_MeioSimulado", "Tipo", "Subtipo", "DH_Informacao", "Observacoes", "Origem", "Id_Na_Origem") FROM stdin;
\.
COPY dbo.meioexterno ("Id_MeioSimulado", "Tipo", "Subtipo", "DH_Informacao", "Observacoes", "Origem", "Id_Na_Origem") FROM '$$PATH$$/5119.dat';

--
-- Data for Name: meiosimulado; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.meiosimulado ("id_MeioSimulado", "Nome", "AcaoMS", id_partido, "Rumo", "VelocAvanco", "Latitude", "Longitude", "Id_MSS", "DataHora", "TabelaMeioSimulado", "Id_trajeto", "Id_UM", "VelocTrajeto", "ProximoPonto", "Trajeto_UltimoPonto", "Plano_VoltasRestantes", "Id_Plano", "Login", "Observacao") FROM stdin;
\.
COPY dbo.meiosimulado ("id_MeioSimulado", "Nome", "AcaoMS", id_partido, "Rumo", "VelocAvanco", "Latitude", "Longitude", "Id_MSS", "DataHora", "TabelaMeioSimulado", "Id_trajeto", "Id_UM", "VelocTrajeto", "ProximoPonto", "Trajeto_UltimoPonto", "Plano_VoltasRestantes", "Id_Plano", "Login", "Observacao") FROM '$$PATH$$/5120.dat';

--
-- Data for Name: meiosimuladoliberado; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.meiosimuladoliberado ("Id_MeioSimulado", "Id_Partido", "Id_Papel", "LoginControlador", "TipoMeioSimulado", "IdentificacaoOcultada") FROM stdin;
\.
COPY dbo.meiosimuladoliberado ("Id_MeioSimulado", "Id_Partido", "Id_Papel", "LoginControlador", "TipoMeioSimulado", "IdentificacaoOcultada") FROM '$$PATH$$/5121.dat';

--
-- Data for Name: meiosimuladomav; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.meiosimuladomav ("id_MeioSimulado", "Nome", "AcaoMS", id_partido, "Rumo", "VelocAvanco", "Latitude", "Longitude", "Id_MSS", "DataHora", "TabelaMeioSimulado", "Id_trajeto", "Id_UM", "VelocTrajeto", "ProximoPonto", "Trajeto_UltimoPonto", "Plano_VoltasRestantes", "Id_Plano", "Login", "Observacao") FROM stdin;
\.
COPY dbo.meiosimuladomav ("id_MeioSimulado", "Nome", "AcaoMS", id_partido, "Rumo", "VelocAvanco", "Latitude", "Longitude", "Id_MSS", "DataHora", "TabelaMeioSimulado", "Id_trajeto", "Id_UM", "VelocTrajeto", "ProximoPonto", "Trajeto_UltimoPonto", "Plano_VoltasRestantes", "Id_Plano", "Login", "Observacao") FROM '$$PATH$$/5122.dat';

--
-- Data for Name: mina; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.mina (id_armamento, "AgenteLancadorAbrev", "AtuacaoArmamentoAbrev", "Peso", "Profundidade", "TipoAlvo", "TipoMina") FROM stdin;
\.
COPY dbo.mina (id_armamento, "AgenteLancadorAbrev", "AtuacaoArmamentoAbrev", "Peso", "Profundidade", "TipoAlvo", "TipoMina") FROM '$$PATH$$/5123.dat';

--
-- Data for Name: missil; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.missil (id_armamento, "PAI", "PAM", "PAA", "NomeGuiagemAbrev", "Veloc", "AgenteLancadorAbrev", "Trigrama", "TipoMissil", "TipoMissilNum", "AlcanceEficaz") FROM stdin;
\.
COPY dbo.missil (id_armamento, "PAI", "PAM", "PAA", "NomeGuiagemAbrev", "Veloc", "AgenteLancadorAbrev", "Trigrama", "TipoMissil", "TipoMissilNum", "AlcanceEficaz") FROM '$$PATH$$/5124.dat';

--
-- Data for Name: modeloformatura; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.modeloformatura ("Id_ModeloFormatura", "Nome", "TipoFormatura", "PatrulhaSetores") FROM stdin;
\.
COPY dbo.modeloformatura ("Id_ModeloFormatura", "Nome", "TipoFormatura", "PatrulhaSetores") FROM '$$PATH$$/5093.dat';

--
-- Data for Name: modeloplano; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.modeloplano ("Id_ModeloPlano", "Nome", "TipoPlano", id_partido) FROM stdin;
\.
COPY dbo.modeloplano ("Id_ModeloPlano", "Nome", "TipoPlano", id_partido) FROM '$$PATH$$/5125.dat';

--
-- Data for Name: mss_constante; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.mss_constante ("Id_MSSConstante", "Nome", "Id_TipoRecursoLogisitico", "id_RecursoLogistico") FROM stdin;
\.
COPY dbo.mss_constante ("Id_MSSConstante", "Nome", "Id_TipoRecursoLogisitico", "id_RecursoLogistico") FROM '$$PATH$$/5092.dat';

--
-- Data for Name: nri; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.nri ("Id_MeioSimulado", "VelocAvanco", "NRI") FROM stdin;
\.
COPY dbo.nri ("Id_MeioSimulado", "VelocAvanco", "NRI") FROM '$$PATH$$/5126.dat';

--
-- Data for Name: organizacaotarefa; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.organizacaotarefa ("Id_OrganizacaoTarefa", nome, "Id_OrganizacaoTarefa_Sup", "Situacao", "HoraAtivacao", "TipoAtivacao", "Id_partido") FROM stdin;
\.
COPY dbo.organizacaotarefa ("Id_OrganizacaoTarefa", nome, "Id_OrganizacaoTarefa_Sup", "Situacao", "HoraAtivacao", "TipoAtivacao", "Id_partido") FROM '$$PATH$$/5156.dat';

--
-- Data for Name: organizacaotarefaliberada; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.organizacaotarefaliberada ("Id_OrganizacaoTarefa", "Id_Partido", "Id_Papel", "LoginControlador") FROM stdin;
\.
COPY dbo.organizacaotarefaliberada ("Id_OrganizacaoTarefa", "Id_Partido", "Id_Papel", "LoginControlador") FROM '$$PATH$$/5157.dat';

--
-- Data for Name: partido; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.partido (id_partido, "Nome", "CodigoCor", "NomeCor", "Neutro") FROM stdin;
\.
COPY dbo.partido (id_partido, "Nome", "CodigoCor", "NomeCor", "Neutro") FROM '$$PATH$$/5128.dat';

--
-- Data for Name: pdv; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.pdv ("Id_PDV", "Login_De", "GRTA", "Sala", "Data", "Criacao", "Liberacao", "SeqNumAltPdv", "OffsetPrimeiroEvento", "XML", "ControladorNotificado", "Identificacao", "Tipo", "Invisivel") FROM stdin;
\.
COPY dbo.pdv ("Id_PDV", "Login_De", "GRTA", "Sala", "Data", "Criacao", "Liberacao", "SeqNumAltPdv", "OffsetPrimeiroEvento", "XML", "ControladorNotificado", "Identificacao", "Tipo", "Invisivel") FROM '$$PATH$$/5127.dat';

--
-- Data for Name: pista; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.pista (id_pista, "Classe", "CapacCarga", "CompPista", "Pavimentacao") FROM stdin;
\.
COPY dbo.pista (id_pista, "Classe", "CapacCarga", "CompPista", "Pavimentacao") FROM '$$PATH$$/5129.dat';

--
-- Data for Name: pistabase; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.pistabase (id_pista, id_base, "QuantPista") FROM stdin;
\.
COPY dbo.pistabase (id_pista, id_base, "QuantPista") FROM '$$PATH$$/5165.dat';

--
-- Data for Name: plano; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.plano ("Id_Plano", "Id_ModeloPlano", "Id_MS_Referencia", "Id_Partido", "Id_Base_Referencia", "Nome", "Latitude_Ref", "Longitude_Ref", "Distancia_Ref", "Marcacao_Ref", "Eixo", "Movimento", "Login") FROM stdin;
\.
COPY dbo.plano ("Id_Plano", "Id_ModeloPlano", "Id_MS_Referencia", "Id_Partido", "Id_Base_Referencia", "Nome", "Latitude_Ref", "Longitude_Ref", "Distancia_Ref", "Marcacao_Ref", "Eixo", "Movimento", "Login") FROM '$$PATH$$/5166.dat';

--
-- Data for Name: plantapropulsora; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.plantapropulsora ("Id_PlantaPropulsora", "TipoPlanta", "Descricao", "DesignacaoPlanta") FROM stdin;
\.
COPY dbo.plantapropulsora ("Id_PlantaPropulsora", "TipoPlanta", "Descricao", "DesignacaoPlanta") FROM '$$PATH$$/5130.dat';

--
-- Data for Name: plataformaaerea; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.plataformaaerea ("id_MeioSimulado", "id_Localizacao", "id_LocalizacaoPousada", "NomeTipoAeronave", "Id_SituacaoPlataforma", "Modelo", "Embarcado", "TipoAsa", "IndiceSortidas", "HorasMes", "TipoMotorAeronave", "QtdeMotores", "Propulsao", "Empuxo", "ConsumoMedio", "Altura", "Comprimento", "Largura", "HangaragemS2", "AreaAsas", "DiametroRA", "PesoBasico", "PesoMaximo", "PesoSupAsa", "PesoPotencia", "CargaUtil", "GeometriaVariavel", "RazaoSubida", "TetoServico", "TetoVooLibrado", "VelocMAXAlto", "VelocMAXBaixo", "VelocCruzeiroAlto", "VelocCruzeiroBaixo", "Altitude", "HorizontalSubida", "Navegacao", "Bloqueio", "EquipamentoBloqueio", "EmpregoAeronave", "ReabastecimentoVoo", "OperacaoAeronave", "InterceptacaoAeronave", "AtaqueAeronave", "AltitudePerfilVooA", "AltitudePerfilVooB", "Autonomia", "PerfilVoo", "CteConsumo1", "CteConsumo2", "CtePatrulha", "DanoVeloc", "IFF", "MAGE", "VelocLogistica", "Id_ConfiguracaoCorrente", "HF", "UHF", "VHF", "Observacao", "Id_Pista", "Id_TipoPropulsao", "Id_RecursoPropulsao", "DanoSensor", "OutrosSistemasComunicacao", "Sigla", "EmEspera", "DHTerminoEspera") FROM stdin;
\.
COPY dbo.plataformaaerea ("id_MeioSimulado", "id_Localizacao", "id_LocalizacaoPousada", "NomeTipoAeronave", "Id_SituacaoPlataforma", "Modelo", "Embarcado", "TipoAsa", "IndiceSortidas", "HorasMes", "TipoMotorAeronave", "QtdeMotores", "Propulsao", "Empuxo", "ConsumoMedio", "Altura", "Comprimento", "Largura", "HangaragemS2", "AreaAsas", "DiametroRA", "PesoBasico", "PesoMaximo", "PesoSupAsa", "PesoPotencia", "CargaUtil", "GeometriaVariavel", "RazaoSubida", "TetoServico", "TetoVooLibrado", "VelocMAXAlto", "VelocMAXBaixo", "VelocCruzeiroAlto", "VelocCruzeiroBaixo", "Altitude", "HorizontalSubida", "Navegacao", "Bloqueio", "EquipamentoBloqueio", "EmpregoAeronave", "ReabastecimentoVoo", "OperacaoAeronave", "InterceptacaoAeronave", "AtaqueAeronave", "AltitudePerfilVooA", "AltitudePerfilVooB", "Autonomia", "PerfilVoo", "CteConsumo1", "CteConsumo2", "CtePatrulha", "DanoVeloc", "IFF", "MAGE", "VelocLogistica", "Id_ConfiguracaoCorrente", "HF", "UHF", "VHF", "Observacao", "Id_Pista", "Id_TipoPropulsao", "Id_RecursoPropulsao", "DanoSensor", "OutrosSistemasComunicacao", "Sigla", "EmEspera", "DHTerminoEspera") FROM '$$PATH$$/5167.dat';

--
-- Data for Name: plataformasubmarina; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.plataformasubmarina ("id_MeioSimulado", id_base, "NomeClasse", "Id_SituacaoPlataforma", "DeslocamentoSup", "DeslocamentoImerso", "Boca", "Calado", "Comprimento", "Esnorquel", "CoeficienteSeguranca", "Autonomia", "Manutencao", "NumTubos", "VelocECSup", "VelocECImerso", "VelocMAXImerso", "VelocMMSuperficie", "VelocMMEsnorquel", "VelocMMNuclear", "RAVECSup", "RAVelocMAXImerso", "RAVelocMMSup", "RAVelocMMEsnorquel", "RAVelocECImerso", "RAVelocMMNuclear", "ConsumoVelocECSup", "ConsumoVelocECImerso", "ConsumoVelocMAXImerso", "ConsumoVelocMMSup", "ConsumoVelocMMEsnorquel", "CargaMaxima", "CargaAtual", "CteDescarga1", "CteDescarga2", "Profundidade", "Observacao", "Propulsao", "CteConsumo1", "CteConsumo2", "CtePatrulha", "DanoVeloc", "IFF", "MAGE", "BandaMAGE", "Despist", "VLF", "HF_LF", "VHF", "UHF", "CotaMaxOperac", "VelocLogistica", "Id_PlantaPropulsora", "Id_TipoPropulsao", "Id_RecursoPropulsao", "DanoSensor", "Sigla", "m_DanoComs_HF", "m_DanoComs_VHF", "m_DanoComs_VLF", "m_DanoComs_HF_LF") FROM stdin;
\.
COPY dbo.plataformasubmarina ("id_MeioSimulado", id_base, "NomeClasse", "Id_SituacaoPlataforma", "DeslocamentoSup", "DeslocamentoImerso", "Boca", "Calado", "Comprimento", "Esnorquel", "CoeficienteSeguranca", "Autonomia", "Manutencao", "NumTubos", "VelocECSup", "VelocECImerso", "VelocMAXImerso", "VelocMMSuperficie", "VelocMMEsnorquel", "VelocMMNuclear", "RAVECSup", "RAVelocMAXImerso", "RAVelocMMSup", "RAVelocMMEsnorquel", "RAVelocECImerso", "RAVelocMMNuclear", "ConsumoVelocECSup", "ConsumoVelocECImerso", "ConsumoVelocMAXImerso", "ConsumoVelocMMSup", "ConsumoVelocMMEsnorquel", "CargaMaxima", "CargaAtual", "CteDescarga1", "CteDescarga2", "Profundidade", "Observacao", "Propulsao", "CteConsumo1", "CteConsumo2", "CtePatrulha", "DanoVeloc", "IFF", "MAGE", "BandaMAGE", "Despist", "VLF", "HF_LF", "VHF", "UHF", "CotaMaxOperac", "VelocLogistica", "Id_PlantaPropulsora", "Id_TipoPropulsao", "Id_RecursoPropulsao", "DanoSensor", "Sigla", "m_DanoComs_HF", "m_DanoComs_VHF", "m_DanoComs_VLF", "m_DanoComs_HF_LF") FROM '$$PATH$$/5168.dat';

--
-- Data for Name: plataformasuperficie; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.plataformasuperficie ("id_MeioSimulado", id_base, "NomeClasse", "Id_SituacaoPlataforma", "VelocLogistica", "CteConsumo1", "CteConsumo2", "CtePatrulha", "DanoVeloc", "CME", "BandaCME", "IFF", "MAGE", "BandaMAGE", "TipoPlatSuperficieNum", "TipoPlatSuperficie", "Deslocamento", "Calado", "Comprimento", "Boca", "VelocEC", "VelocMM", "VelocMAX", "RAVelocEC", "RAVelocMM", "RAVelocMAX", "ConsumoVelocEC", "ConsumoVelocMM", "ConsumoVelocMAX", "Propulsao", "CapacDocagem", "CapacHangaragem", "AreaHangarOcupada", id_pista, "Observacao", "Janela", "VHF", "UHF", "HF", "Guia", "Id_TipoPropulsao", "Id_RecursoPropulsao", "Id_PlantaPropulsora", "DanoSensor", "Sigla", "m_DanoReabastecimento", "m_DanoOpsAereasHE", "m_DanoOpsAereasAsaFixa", "m_DanoComs_HF", "m_DanoComs_VHF", "m_DanoComs_UHF", "EhCapitanea") FROM stdin;
\.
COPY dbo.plataformasuperficie ("id_MeioSimulado", id_base, "NomeClasse", "Id_SituacaoPlataforma", "VelocLogistica", "CteConsumo1", "CteConsumo2", "CtePatrulha", "DanoVeloc", "CME", "BandaCME", "IFF", "MAGE", "BandaMAGE", "TipoPlatSuperficieNum", "TipoPlatSuperficie", "Deslocamento", "Calado", "Comprimento", "Boca", "VelocEC", "VelocMM", "VelocMAX", "RAVelocEC", "RAVelocMM", "RAVelocMAX", "ConsumoVelocEC", "ConsumoVelocMM", "ConsumoVelocMAX", "Propulsao", "CapacDocagem", "CapacHangaragem", "AreaHangarOcupada", id_pista, "Observacao", "Janela", "VHF", "UHF", "HF", "Guia", "Id_TipoPropulsao", "Id_RecursoPropulsao", "Id_PlantaPropulsora", "DanoSensor", "Sigla", "m_DanoReabastecimento", "m_DanoOpsAereasHE", "m_DanoOpsAereasAsaFixa", "m_DanoComs_HF", "m_DanoComs_VHF", "m_DanoComs_UHF", "EhCapitanea") FROM '$$PATH$$/5169.dat';

--
-- Data for Name: plataformaterrestre; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.plataformaterrestre ("Id_MeioSimulado", "TipoPlataformaTerrestreNum", "TipoPlataformaTerrestre", "Id_SituacaoPlataforma", "DanoVeloc", "DanoSensor", "VelocMax", "RAVelocMax", "ConsumoVelocMax", "Id_TipoPropulsao", "Id_RecursoPropulsao", "Observacao", "Sigla", "Id_LocalizacaoEmbarcada") FROM stdin;
\.
COPY dbo.plataformaterrestre ("Id_MeioSimulado", "TipoPlataformaTerrestreNum", "TipoPlataformaTerrestre", "Id_SituacaoPlataforma", "DanoVeloc", "DanoSensor", "VelocMax", "RAVelocMax", "ConsumoVelocMax", "Id_TipoPropulsao", "Id_RecursoPropulsao", "Observacao", "Sigla", "Id_LocalizacaoEmbarcada") FROM '$$PATH$$/5170.dat';

--
-- Data for Name: pontonotavel; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.pontonotavel ("Id_MeioSimulado", "Id_Finalidade") FROM stdin;
\.
COPY dbo.pontonotavel ("Id_MeioSimulado", "Id_Finalidade") FROM '$$PATH$$/5171.dat';

--
-- Data for Name: pontosarea; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.pontosarea ("Id_PontosArea", "Id_MeioSimulado", "Nome", "Marcacao", "Distancia") FROM stdin;
\.
COPY dbo.pontosarea ("Id_PontosArea", "Id_MeioSimulado", "Nome", "Marcacao", "Distancia") FROM '$$PATH$$/5172.dat';

--
-- Data for Name: pontoslinha; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.pontoslinha ("Id_MeioSimulado", "Id_PontosLinha", "Nome", "Marcacao", "Distancia") FROM stdin;
\.
COPY dbo.pontoslinha ("Id_MeioSimulado", "Id_PontosLinha", "Nome", "Marcacao", "Distancia") FROM '$$PATH$$/5173.dat';

--
-- Data for Name: pontosmodeloformatura; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.pontosmodeloformatura ("Id_PontosModeloFormatura", "Id_ModeloFormatura", "Nome", "Marcacao", "Distancia") FROM stdin;
\.
COPY dbo.pontosmodeloformatura ("Id_PontosModeloFormatura", "Id_ModeloFormatura", "Nome", "Marcacao", "Distancia") FROM '$$PATH$$/5174.dat';

--
-- Data for Name: pontosmodeloplano; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.pontosmodeloplano ("Id_PontosModeloPlano", "Id_ModeloPlano", "Nome", "Marcacao", "Distancia") FROM stdin;
\.
COPY dbo.pontosmodeloplano ("Id_PontosModeloPlano", "Id_ModeloPlano", "Nome", "Marcacao", "Distancia") FROM '$$PATH$$/5175.dat';

--
-- Data for Name: pontostrajeto; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.pontostrajeto (id_pontos, id_trajeto, "Nome", "Latitude", "Longitude", "DataHora", "Veloc") FROM stdin;
\.
COPY dbo.pontostrajeto (id_pontos, id_trajeto, "Nome", "Latitude", "Longitude", "DataHora", "Veloc") FROM '$$PATH$$/5158.dat';

--
-- Data for Name: postosformatura; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.postosformatura ("Id_PostosFormatura", "Id_Formatura", "Id_MS_posto", "Nome", "Marcacao", "Distancia") FROM stdin;
\.
COPY dbo.postosformatura ("Id_PostosFormatura", "Id_Formatura", "Id_MS_posto", "Nome", "Marcacao", "Distancia") FROM '$$PATH$$/5176.dat';

--
-- Data for Name: previsaometeorologica; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.previsaometeorologica ("Id_PrevisaoMeteorologica", "Tempo", "VelocVento", "PressaoAtm", "EstadoMar", "Visibilidade", "Teto", "DegradacaoSensores", "MaximaVeloc", "OperacoesAereas") FROM stdin;
\.
COPY dbo.previsaometeorologica ("Id_PrevisaoMeteorologica", "Tempo", "VelocVento", "PressaoAtm", "EstadoMar", "Visibilidade", "Teto", "DegradacaoSensores", "MaximaVeloc", "OperacoesAereas") FROM '$$PATH$$/5131.dat';

--
-- Data for Name: recursopropulsao; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.recursopropulsao ("Id_RecursoPropulsao", "Id_RecursoLogistico", "Id_TipoPropulsao") FROM stdin;
\.
COPY dbo.recursopropulsao ("Id_RecursoPropulsao", "Id_RecursoLogistico", "Id_TipoPropulsao") FROM '$$PATH$$/5177.dat';

--
-- Data for Name: recursoslogisticos; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.recursoslogisticos ("Id_RecursoLogistico", "Id_Localizacao", "Nome", "NomeRecLog_Num", "Tipo", "TipoRecLog_Num", "Categoria", "CapacArmazenamento", "QtdeRCB", "QtdeCONSFNC", "NumeroTomadas", "NumeroTanques", "CapacMaxTanque", "VazaoFNC", "VazaoRCB", "Id_Armamento", "Id_Sensor") FROM stdin;
\.
COPY dbo.recursoslogisticos ("Id_RecursoLogistico", "Id_Localizacao", "Nome", "NomeRecLog_Num", "Tipo", "TipoRecLog_Num", "Categoria", "CapacArmazenamento", "QtdeRCB", "QtdeCONSFNC", "NumeroTomadas", "NumeroTanques", "CapacMaxTanque", "VazaoFNC", "VazaoRCB", "Id_Armamento", "Id_Sensor") FROM '$$PATH$$/5178.dat';

--
-- Data for Name: sensor; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.sensor ("id_Sensor", "TipoSensor", "Nome", "Modelo", "AlcanceMaximo", "Emprego", "ModoOperacao", "Dano_Sensor") FROM stdin;
\.
COPY dbo.sensor ("id_Sensor", "TipoSensor", "Nome", "Modelo", "AlcanceMaximo", "Emprego", "ModoOperacao", "Dano_Sensor") FROM '$$PATH$$/5148.dat';

--
-- Data for Name: situacaoplataforma; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.situacaoplataforma ("Id_SituacaoPlataforma", "Nome", "TipoPlataforma", "Constante") FROM stdin;
\.
COPY dbo.situacaoplataforma ("Id_SituacaoPlataforma", "Nome", "TipoPlataforma", "Constante") FROM '$$PATH$$/5149.dat';

--
-- Data for Name: ssgn_acesso; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.ssgn_acesso ("Id_Funcao", "Id_Recurso", "Id_Fase", "Acesso") FROM stdin;
\.
COPY dbo.ssgn_acesso ("Id_Funcao", "Id_Recurso", "Id_Fase", "Acesso") FROM '$$PATH$$/5133.dat';

--
-- Data for Name: ssgn_auditoria; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.ssgn_auditoria ("DataHora", "Maquina", "LoginWindows", "Login", "BancoDados", "Id_Fase", "Id_Funcao", "Id_Recurso", "Id_Papel", "Situacao", "Observacao") FROM stdin;
\.
COPY dbo.ssgn_auditoria ("DataHora", "Maquina", "LoginWindows", "Login", "BancoDados", "Id_Fase", "Id_Funcao", "Id_Recurso", "Id_Papel", "Situacao", "Observacao") FROM '$$PATH$$/5134.dat';

--
-- Data for Name: ssgn_comando; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.ssgn_comando ("Id_MSS", "Indice", "DataHoraExec", "Login", "StatusComando", "FeedBack", "Id_MCC", "ComandoXML", "OffsetEnc", "Id_FAB") FROM stdin;
\.
COPY dbo.ssgn_comando ("Id_MSS", "Indice", "DataHoraExec", "Login", "StatusComando", "FeedBack", "Id_MCC", "ComandoXML", "OffsetEnc", "Id_FAB") FROM '$$PATH$$/5136.dat';

--
-- Data for Name: ssgn_comando_pdv; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.ssgn_comando_pdv ("ID_PDV", "id_MSS") FROM stdin;
\.
COPY dbo.ssgn_comando_pdv ("ID_PDV", "id_MSS") FROM '$$PATH$$/5159.dat';

--
-- Data for Name: ssgn_comando_preab; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.ssgn_comando_preab ("ID_PREAB", "id_MSS") FROM stdin;
\.
COPY dbo.ssgn_comando_preab ("ID_PREAB", "id_MSS") FROM '$$PATH$$/5135.dat';

--
-- Data for Name: ssgn_controlejogo; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.ssgn_controlejogo ("Jogo", "Versao", "Data_Criacao", "Id_Fase", "DataHoraInicReal", "DataHoraInicSimulada", "DataHoraAtualReal", "DataHoraAtualSimulada", "Status", "MarchaReal", "MarchaSimulada", "Delta_T", "StatusBackup", "TaxaBackup", "StatusDeteccao", "TaxaDeteccao", "TaxaAtuPlatAerea", "TaxaAtuPlatSuperficie", "TaxaAtuPlatSubmarina", "TaxaAtuMeioSimulado", "ContAtuPlatAereas", "ContAtuPlatSuperficie", "ContAtuPlatSubmarina", "ContAtuMeioSimulado", "ProximoIdMSS", "ConstIDPass", "DH_Exibicao", "MinutosPingRecurso") FROM stdin;
\.
COPY dbo.ssgn_controlejogo ("Jogo", "Versao", "Data_Criacao", "Id_Fase", "DataHoraInicReal", "DataHoraInicSimulada", "DataHoraAtualReal", "DataHoraAtualSimulada", "Status", "MarchaReal", "MarchaSimulada", "Delta_T", "StatusBackup", "TaxaBackup", "StatusDeteccao", "TaxaDeteccao", "TaxaAtuPlatAerea", "TaxaAtuPlatSuperficie", "TaxaAtuPlatSubmarina", "TaxaAtuMeioSimulado", "ContAtuPlatAereas", "ContAtuPlatSuperficie", "ContAtuPlatSubmarina", "ContAtuMeioSimulado", "ProximoIdMSS", "ConstIDPass", "DH_Exibicao", "MinutosPingRecurso") FROM '$$PATH$$/5160.dat';

--
-- Data for Name: ssgn_exportacao_processamento; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.ssgn_exportacao_processamento ("Id_Exportacao_Processada", "Id_Elemento_Exportado", "TipoElementoExportacao", "NomeElemento", "Id_MeioSimulado_Importado", "Id_ModeloPlano_Importado", "Id_Trajeto_Importado", "Id_Partido", "ElementoImportado") FROM stdin;
\.
COPY dbo.ssgn_exportacao_processamento ("Id_Exportacao_Processada", "Id_Elemento_Exportado", "TipoElementoExportacao", "NomeElemento", "Id_MeioSimulado_Importado", "Id_ModeloPlano_Importado", "Id_Trajeto_Importado", "Id_Partido", "ElementoImportado") FROM '$$PATH$$/5161.dat';

--
-- Data for Name: ssgn_exportacaomav; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.ssgn_exportacaomav ("Id_ExportacaoMAV", "Login", "LoginControlador", "Nome", "ConteudoXML") FROM stdin;
\.
COPY dbo.ssgn_exportacaomav ("Id_ExportacaoMAV", "Login", "LoginControlador", "Nome", "ConteudoXML") FROM '$$PATH$$/5137.dat';

--
-- Data for Name: ssgn_fase; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.ssgn_fase ("Id_Fase", "Nome") FROM stdin;
\.
COPY dbo.ssgn_fase ("Id_Fase", "Nome") FROM '$$PATH$$/5138.dat';

--
-- Data for Name: ssgn_hierarquiacomponente; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.ssgn_hierarquiacomponente ("Id_HierarquiaComponente", "Id_TipoComponente", "Codigo_MCC", "Codigo_Pai", "Stored_Procedure", "CamposApresentados", "CampoEnviado", "Composicao", "CamposParametro") FROM stdin;
\.
COPY dbo.ssgn_hierarquiacomponente ("Id_HierarquiaComponente", "Id_TipoComponente", "Codigo_MCC", "Codigo_Pai", "Stored_Procedure", "CamposApresentados", "CampoEnviado", "Composicao", "CamposParametro") FROM '$$PATH$$/5162.dat';

--
-- Data for Name: ssgn_itemacesso; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.ssgn_itemacesso ("Id_Funcao", "Id_Recurso", "Id_Fase", "Id_TagItemMenu") FROM stdin;
\.
COPY dbo.ssgn_itemacesso ("Id_Funcao", "Id_Recurso", "Id_Fase", "Id_TagItemMenu") FROM '$$PATH$$/5139.dat';

--
-- Data for Name: ssgn_itemmenurecurso; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.ssgn_itemmenurecurso ("Id_Recurso", "Id_TagItemMenu", "Nome", "Id_TagPai", "Nivel") FROM stdin;
\.
COPY dbo.ssgn_itemmenurecurso ("Id_Recurso", "Id_TagItemMenu", "Nome", "Id_TagPai", "Nivel") FROM '$$PATH$$/5140.dat';

--
-- Data for Name: ssgn_logjogo; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.ssgn_logjogo ("Id_LogJogo", "DH", "Id_Recurso", "Login", "TipoMensagem", "Mensagem", "Id_ComandoMSS", "Id_ComandoMCC", "Id_ComandoEncadeado", "Classif", "DH_Real") FROM stdin;
\.
COPY dbo.ssgn_logjogo ("Id_LogJogo", "DH", "Id_Recurso", "Login", "TipoMensagem", "Mensagem", "Id_ComandoMSS", "Id_ComandoMCC", "Id_ComandoEncadeado", "Classif", "DH_Real") FROM '$$PATH$$/5141.dat';

--
-- Data for Name: ssgn_msslog; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.ssgn_msslog ("IndiceMensagem", "Mensagem") FROM stdin;
\.
COPY dbo.ssgn_msslog ("IndiceMensagem", "Mensagem") FROM '$$PATH$$/5142.dat';

--
-- Data for Name: ssgn_papeisaplicfuncao; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.ssgn_papeisaplicfuncao ("Id_Funcao", "Id_Papel") FROM stdin;
\.
COPY dbo.ssgn_papeisaplicfuncao ("Id_Funcao", "Id_Papel") FROM '$$PATH$$/5143.dat';

--
-- Data for Name: ssgn_recurso; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.ssgn_recurso ("Id_Recurso", "Recurso", "DescricaoRecurso") FROM stdin;
\.
COPY dbo.ssgn_recurso ("Id_Recurso", "Recurso", "DescricaoRecurso") FROM '$$PATH$$/5144.dat';

--
-- Data for Name: ssgn_recursologistico; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.ssgn_recursologistico ("Id_RecursoLogistico", "Nome", "Categoria") FROM stdin;
\.
COPY dbo.ssgn_recursologistico ("Id_RecursoLogistico", "Nome", "Categoria") FROM '$$PATH$$/5145.dat';

--
-- Data for Name: ssgn_temp_verificacaoidentificador; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.ssgn_temp_verificacaoidentificador ("tagUso", "Identificador", "Id_Partido", "Login", "Id_Exportacao", "Elemento", "DH_Criacao") FROM stdin;
\.
COPY dbo.ssgn_temp_verificacaoidentificador ("tagUso", "Identificador", "Id_Partido", "Login", "Id_Exportacao", "Elemento", "DH_Criacao") FROM '$$PATH$$/5146.dat';

--
-- Data for Name: ssgn_tipocomponente; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.ssgn_tipocomponente ("Id_TipoComponente", "Nome", "Icone", "Grupo", "TreeNode", "NomeArmamento", "PersistenciaEncadeamento", "AtualizacaoAutomatica", "FiltrarItemRaiz") FROM stdin;
\.
COPY dbo.ssgn_tipocomponente ("Id_TipoComponente", "Nome", "Icone", "Grupo", "TreeNode", "NomeArmamento", "PersistenciaEncadeamento", "AtualizacaoAutomatica", "FiltrarItemRaiz") FROM '$$PATH$$/5147.dat';

--
-- Data for Name: ssgnpingrecurso; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.ssgnpingrecurso ("Id_SSGNPingRecurso", "NomeMaquina", "NomeRecurso", "DataHoraAtualizacao") FROM stdin;
\.
COPY dbo.ssgnpingrecurso ("Id_SSGNPingRecurso", "NomeMaquina", "NomeRecurso", "DataHoraAtualizacao") FROM '$$PATH$$/5132.dat';

--
-- Data for Name: tabeladejogos; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.tabeladejogos (name, size, low, high, "Cntrltype", phyname, "Status") FROM stdin;
\.
COPY dbo.tabeladejogos (name, size, low, high, "Cntrltype", phyname, "Status") FROM '$$PATH$$/5151.dat';

--
-- Data for Name: tempdano; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.tempdano ("ID_Plataforma", "m_PercentDanoTotal", "m_DuracaoMaximaReparoBase", "m_ValorApresentado") FROM stdin;
\.
COPY dbo.tempdano ("ID_Plataforma", "m_PercentDanoTotal", "m_DuracaoMaximaReparoBase", "m_ValorApresentado") FROM '$$PATH$$/5150.dat';

--
-- Data for Name: tempglossario; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.tempglossario (id, compactado, descompactado) FROM stdin;
\.
COPY dbo.tempglossario (id, compactado, descompactado) FROM '$$PATH$$/5152.dat';

--
-- Data for Name: tipodano; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.tipodano ("ID_TipoDano", "Descricao") FROM stdin;
\.
COPY dbo.tipodano ("ID_TipoDano", "Descricao") FROM '$$PATH$$/5153.dat';

--
-- Data for Name: tipopropulsao; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.tipopropulsao ("Id_TipoPropulsao", "TipoRecursoLogistico", "RecursoLogistico", "Id_TipoRecursoLogistico", "Id_RecursoLogistico", "Nome") FROM stdin;
\.
COPY dbo.tipopropulsao ("Id_TipoPropulsao", "TipoRecursoLogistico", "RecursoLogistico", "Id_TipoRecursoLogistico", "Id_RecursoLogistico", "Nome") FROM '$$PATH$$/5154.dat';

--
-- Data for Name: tiporecursologistico; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.tiporecursologistico ("Id_TipoRecursoLogistico", "Id_RecursoLogistico", "TipoRecursoLogistico", "Id_Armamento", "Id_Sensor") FROM stdin;
\.
COPY dbo.tiporecursologistico ("Id_TipoRecursoLogistico", "Id_RecursoLogistico", "TipoRecursoLogistico", "Id_Armamento", "Id_Sensor") FROM '$$PATH$$/5163.dat';

--
-- Data for Name: torpedo; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.torpedo (id_armamento, "TipoTorpedo", "PAI", "PaiAS", "PaiASUP", "NomeBusca", "AgenteLancadorAbrev", "ProfundidadeMax", "AlcanceMaximo", "VelocCorrida") FROM stdin;
\.
COPY dbo.torpedo (id_armamento, "TipoTorpedo", "PAI", "PaiAS", "PaiASUP", "NomeBusca", "AgenteLancadorAbrev", "ProfundidadeMax", "AlcanceMaximo", "VelocCorrida") FROM '$$PATH$$/5179.dat';

--
-- Data for Name: trajeto; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.trajeto (id_trajeto, "TipoTrajeto", "Nome", id_partido, "Login") FROM stdin;
\.
COPY dbo.trajeto (id_trajeto, "TipoTrajeto", "Nome", id_partido, "Login") FROM '$$PATH$$/5155.dat';

--
-- Data for Name: transitopatrulha; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.transitopatrulha ("id_MeioSimulado", "VelocAvanco", "TaxaIndiscricao") FROM stdin;
\.
COPY dbo.transitopatrulha ("id_MeioSimulado", "VelocAvanco", "TaxaIndiscricao") FROM '$$PATH$$/5180.dat';

--
-- Data for Name: transporteaeronave; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.transporteaeronave ("Id_MeioSimulado_PlatSup", "Id_MeioSimulado_PlatAer") FROM stdin;
\.
COPY dbo.transporteaeronave ("Id_MeioSimulado_PlatSup", "Id_MeioSimulado_PlatAer") FROM '$$PATH$$/5181.dat';

--
-- Data for Name: um; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.um ("Id_MeioSimulado_UM", "id_Formatura", "Id_AreaPatrulha", "LadoDestino", "Marcacao", "Distancia", "DataHoraTermino", "TipoUM", "IncluidaEncadeado") FROM stdin;
\.
COPY dbo.um ("Id_MeioSimulado_UM", "id_Formatura", "Id_AreaPatrulha", "LadoDestino", "Marcacao", "Distancia", "DataHoraTermino", "TipoUM", "IncluidaEncadeado") FROM '$$PATH$$/5182.dat';

--
-- Data for Name: visibilidadepartido; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.visibilidadepartido ("Id_partido", "Id_partido_visivel") FROM stdin;
\.
COPY dbo.visibilidadepartido ("Id_partido", "Id_partido_visivel") FROM '$$PATH$$/5164.dat';

--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.
COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM '$$PATH$$/4881.dat';

--
-- Data for Name: geocode_settings; Type: TABLE DATA; Schema: tiger; Owner: postgres
--

COPY tiger.geocode_settings (name, setting, unit, category, short_desc) FROM stdin;
\.
COPY tiger.geocode_settings (name, setting, unit, category, short_desc) FROM '$$PATH$$/4885.dat';

--
-- Data for Name: pagc_gaz; Type: TABLE DATA; Schema: tiger; Owner: postgres
--

COPY tiger.pagc_gaz (id, seq, word, stdword, token, is_custom) FROM stdin;
\.
COPY tiger.pagc_gaz (id, seq, word, stdword, token, is_custom) FROM '$$PATH$$/4886.dat';

--
-- Data for Name: pagc_lex; Type: TABLE DATA; Schema: tiger; Owner: postgres
--

COPY tiger.pagc_lex (id, seq, word, stdword, token, is_custom) FROM stdin;
\.
COPY tiger.pagc_lex (id, seq, word, stdword, token, is_custom) FROM '$$PATH$$/4887.dat';

--
-- Data for Name: pagc_rules; Type: TABLE DATA; Schema: tiger; Owner: postgres
--

COPY tiger.pagc_rules (id, rule, is_custom) FROM stdin;
\.
COPY tiger.pagc_rules (id, rule, is_custom) FROM '$$PATH$$/4888.dat';

--
-- Data for Name: topology; Type: TABLE DATA; Schema: topology; Owner: postgres
--

COPY topology.topology (id, name, srid, "precision", hasz) FROM stdin;
\.
COPY topology.topology (id, name, srid, "precision", hasz) FROM '$$PATH$$/4883.dat';

--
-- Data for Name: layer; Type: TABLE DATA; Schema: topology; Owner: postgres
--

COPY topology.layer (topology_id, layer_id, schema_name, table_name, feature_column, feature_type, level, child_id) FROM stdin;
\.
COPY topology.layer (topology_id, layer_id, schema_name, table_name, feature_column, feature_type, level, child_id) FROM '$$PATH$$/4884.dat';

--
-- Name: topology_id_seq; Type: SEQUENCE SET; Schema: topology; Owner: postgres
--

SELECT pg_catalog.setval('topology.topology_id_seq', 1, false);


--
-- PostgreSQL database dump complete
--

