import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import "./styles/Login.scss";
import { AuthProvider } from "react-oidc-context";

//defineCustomElements(window);
window
const oidcConfig = {
  authority: window.OAUTH2_URL,
  scope: 'openid profile email',
  client_id: window.OAUTH2_CLIENT_ID,
  client_secret: window.OAUTH2_CLIENT_SECRET,
  redirect_uri: window.location.origin,
  post_logout_redirect_uri: window.location.origin
};

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <AuthProvider {...oidcConfig}>
       <App />
    </AuthProvider>
  </React.StrictMode>
);
