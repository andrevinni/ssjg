import { useEffect, useState } from 'react';
import { useNavigate } from "react-router-dom";
import Cookies from "js-cookie";
import { useAuth } from "react-oidc-context";
import HandleLogin from './HandleLogin';
import { autenticateUserLogin } from '../api/auth';
import Loading from '../components/Loading/Loading';

const Login = () => {

  const auth = useAuth();
  const navigate = useNavigate()
  const [loading, setLoading] = useState(false);
  const [authenticated, setAuthenticated] = useState(false);
    const [errorMessage, setErrorMessage] = useState(null);

// Força logout quando o token expira
  useEffect(() => {
    if (auth.user?.expired) {
      console.warn("⚠️ Sessão expirada");
      Cookies.remove("access_token");
      auth.removeUser();
      setAuthenticated(false);
      navigate("/", { replace: true });
      setErrorMessage("Sua sessão expirou. Faça login novamente.");
    }
  }, [auth.user, navigate]);

   // Escuta o evento de expiração do token
  useEffect(() => {
    const handleTokenExpired = () => {
      console.warn("⚠️ Token expirado pelo evento!");
      Cookies.remove("access_token");
      auth.removeUser();
      setAuthenticated(false);
      navigate("/", { replace: true });
      setErrorMessage("Sua sessão expirou. Faça login novamente.");
    };

    auth.events.addAccessTokenExpired(handleTokenExpired);
    return () => {
      auth.events.removeAccessTokenExpired(handleTokenExpired);
    };
  }, [auth, navigate]);


  useEffect(() => {
       const autenticar = async () => {

      if (auth.isAuthenticated && auth.user?.access_token) {
        setLoading(true);
        const token = auth.user.access_token;

        Cookies.set("access_token", token);

        try {
          await autenticateUserLogin(token);
          setAuthenticated(true)
          setLoading(false);

           navigate("/home", { replace: true });
        } catch (err) {
          setLoading(false);
          setErrorMessage("Erro na autenticação com o Backend")
          console.error("Erro na autenticação:", err);
          Cookies.remove("access_token");
          auth.removeUser();
          setAuthenticated(false);
          navigate("/", { replace: true });
        }
      }
    };

    autenticar();
  },[auth.isAuthenticated, auth.user, authenticated, navigate])

 switch (auth.activeNavigator) {
  case "signinSilent":
    return (
      <Loading
        fullScreen
        message="Restaurando sua sessão…"
      />
    );

  case "signoutRedirect":
    return (
      <Loading
        fullScreen
        message="Encerrando sessão…"
      />
    );

  default:
    break;
}

 

  if (!auth.isAuthenticated) {
    return ( 
    <div >
        <HandleLogin onLogin={auth.signinRedirect} errorMessage={errorMessage} />
      </div>)
  }

  if (loading && !authenticated) {
  return (
    <Loading
      fullScreen
      message="Validando acesso com o servidor…"
    />
  );
}


  return (
  <div>
    {errorMessage ? (
      <div className="error-card">{errorMessage}</div>
    ) : (
      <Loading message="Preparando ambiente…" />
    )}
  </div>
);


};


export default Login;