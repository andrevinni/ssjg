import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "react-oidc-context";
import Loading from "../components/Loading/Loading";

export const PrivateRoute = ({ children }) => {
 const auth = useAuth();
  const location = useLocation();

  // importante: não redirecionar enquanto o auth estiver carregando
  if (auth.isLoading) {
  return <Loading fullScreen />;
}


  if (!auth.isAuthenticated) {
    // salva de onde veio e redireciona para login
    return <Navigate to="/" state={{ from: location }} replace />;
  }

  return children;
};