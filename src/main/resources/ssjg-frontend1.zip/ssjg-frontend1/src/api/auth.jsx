import axios from "axios";
import { api, requestConfig, baseUrl, tratarErroAxios } from "./api";

const DEV_TOKEN = "eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJ3Vm9JYU5wMTRnTjFEa1FZUzROYkpJOVkwaDF1RzVMS0VqN19laGRsLTc4In0.eyJleHAiOjE3NzIxNDY1NjYsImlhdCI6MTc3MjE0Mjk2NiwianRpIjoiOTdhMTBlNmEtYzIzNS00NGE1LTk4NDUtYjJiMzcxM2UyMDc1IiwiaXNzIjoiaHR0cHM6Ly9zc28uc2NvcmUuY3RpbS5tYjo5MDAwL3JlYWxtcy9zY29yZTItZGV2IiwiYXVkIjpbImFwcC1wcm94eSIsImFjY291bnQiLCJhcHAtc2NvcmUiXSwic3ViIjoiZWFjNGJhMGItMzhkYi00Mzk5LTliNmEtMjJjNjJiY2U1YWNlIiwidHlwIjoiQmVhcmVyIiwiYXpwIjoiYXBwLXNzamciLCJzZXNzaW9uX3N0YXRlIjoiZGUzNmM3NjgtMWM1ZC00Yjg5LTg0M2QtZjQxYmZiMTUxY2YwIiwiYWNyIjoiMSIsImFsbG93ZWQtb3JpZ2lucyI6WyIqIl0sInJlYWxtX2FjY2VzcyI6eyJyb2xlcyI6WyJkZWZhdWx0LXJvbGVzLXNjb3JlMi1kZXYiLCJvZmZsaW5lX2FjY2VzcyIsInVtYV9hdXRob3JpemF0aW9uIiwic2NvcmUyLWFwaS1nZXJhbCJdfSwicmVzb3VyY2VfYWNjZXNzIjp7ImFwcC1wcm94eSI6eyJyb2xlcyI6WyJjb211bmljYWNhbyIsImFybWF6ZW5hbWVudG8iLCJwYWRyYW8iLCJ2aWRlbyJdfSwiYWNjb3VudCI6eyJyb2xlcyI6WyJtYW5hZ2UtYWNjb3VudCIsIm1hbmFnZS1hY2NvdW50LWxpbmtzIiwidmlldy1wcm9maWxlIl19LCJhcHAtc2NvcmUiOnsicm9sZXMiOlsidXN1YXJpbyJdfX0sInNjb3BlIjoiZW1haWwgcHJvZmlsZSIsInNpZCI6ImRlMzZjNzY4LTFjNWQtNGI4OS04NDNkLWY0MWJmYjE1MWNmMCIsImVtYWlsX3ZlcmlmaWVkIjpmYWxzZSwibmFtZSI6IlJPQkVSVEEgQ0FTVFJPIFJPQkVSVEEgQ0FTVFJPIiwicHJlZmVycmVkX3VzZXJuYW1lIjoiMDc5MzUzNzc3MDciLCJnaXZlbl9uYW1lIjoiUk9CRVJUQSBDQVNUUk8iLCJmYW1pbHlfbmFtZSI6IlJPQkVSVEEgQ0FTVFJPIiwiZW1haWwiOiIwNzkzNTM3NzcwN0BzY29yZS5tYiJ9.GFDn1Q7WtRTHM0K9nD3gh0HxJFn4TfS2EyQd23ry_AAwnm9bc3-QvQgt81G6GUVmNrCk7HNTHivS1HxuUBnilVB5JjRRiCHoOLgxoPBafWq90G7410n5KE3MbbbdEiZWhJN24GUM_juBG7y_WVZykFqO2xJVuc0rYKF25wPC3cPebQVUCqN-NfkYGhyw4ucpmEpXmCX_bsYHHD8AC6oMVXW-xwpUeH20xnRPPrNBHQTxqZ4vbNgA2n8TpD-C-6EDFyfU65Vl776kIOAjvFzxTwilu3ubI_uAgUcWvvVW9RkTvNI_y2Ci40nYw20-XiGlIXxIgrTAIqVKbhCWOzEUPQ";

export const autenticateUserLogin = (token) => {
  const API_BASE_URL = import.meta.env.VITE_APP_API_BASEURL;
  const tokenFinal = token || DEV_TOKEN;

  return axios.get(`${API_BASE_URL}/login/getAuthorities`, {
    headers: {
      Authorization: `Bearer ${tokenFinal}`,
      Accept: "*/*"
    }
  })
  .then(resp => {
    console.log("Resposta backend:", resp);
    return resp.data || {};
  })
  .catch(err => {
    console.error("Erro Axios:", err.response || err);
    throw err;
  });
};