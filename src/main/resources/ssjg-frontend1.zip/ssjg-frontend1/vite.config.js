import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import svgr from 'vite-plugin-svgr';

export default defineConfig({
  plugins: [react(), 
    svgr({ include: "**/*.svg?react"}),
  ],
    server: {
    fs: {
      strict: true,
    },
  },
  build: {
    outDir: "dist",
  },
  preview: {
    port: 4173,
    strictPort: true,
    historyApiFallback: true,
  },
});