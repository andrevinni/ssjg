describe('Formulário de Consultoria', () => {

    it('Deve solicitar uma consultoria individual', () => {
        cy.start();
        cy.submitLoginForm('papito@webdojo.com','katana123');

        cy.goTo('Formulários', 'Consultoria');
        //cy.goTo('Integração', 'Consulta de CEP');
        //cy.goTo('Tabela', 'Perfis do GitHub');

        //cy.get('#name').type('Michael Jordan');
        cy.get('input[placeholder="Digite seu nome completo"]').type('Banana de Pijama');

        //cy.get('#email').type('mjordan23@twentythree.com');
        cy.get('input[placeholder="Digite seu email"]').type('mjordan23@twentythree.com');

        //cy.get('#phone').type('21 98765-4321');
        cy.get('input[placeholder="(00) 00000-0000"]')
        .type('21 98765-4321')
        .should('have.value', '(21) 98765-4321');

        // Posso usar value="valor", texto entre <option>valor</option> e também label="valor" e value="1"
        // a propriedade label tem precedência sobre o texto entre a tag de abertura/fechamento 
        cy.get('#consultancyType').select('In Company');
        // Outra forma de selecionar
        cy.contains('label', 'Tipo de Consultoria')
        .parent()
        .find('select')
        .select('Individual');

        
        // 23. Interagindo com Botões de Radio

        //Tipo de pessoa: Jurídica
        //cy.contains('span', 'Pessoa Jurídica')
        //.parent()
        //.find('input')
        //.click()

        //Tipo de pessoa: Física
        cy.contains('label', 'Pessoa Física')
        .find('input')
        .check()//.click() ou .check()
        .should('be.checked')

        //validação
        cy.contains('label', 'Pessoa Jurídica')
        .find('input')
        .should('be.not.checked');

        cy.contains('label','CPF')
        .parent()
        .find('input')
        .type('78747292008')
        .should('have.value', '787.472.920-08')

        // 25. Interagindo com Checkboxes e Selecionando com forEach
        
        const discoveryChannels = [
            'Instagram',
            'LinkedIn',
            'Udemy',
            'YouTube',
            'Indicação de Amigo'
        ]

        discoveryChannels.forEach((channel) => {
            cy.contains('label', channel)
            .find('input')
            .check()
            .should('be.checked')        
        })

        // 26. Anexando arquivos para Upload

        cy.get('input[type="file"]')
            .selectFile('./cypress/fixtures/document.pdf', {force: true});

        // 27. Interagindo com Area de Texto

        cy.get('textarea[placeholder="Descreva mais detalhes sobre sua necessidade"]')
        .type('Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incidente ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea comodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.');

        // 28. Interagindo com array de Tags

        // techs.forEach((tech) => {
        //     cy.get('input[placeholder="Digite uma tecnologia e pressione Enter"]')
        //         .type(tech)
        //         .type('{enter}')

        //     cy.contains('label', 'Tecnologias')
        //         .parent()
        //         .contains('span', tech)
        //         .should('be.visible')
        // })

        cy.InteragindoArrayTags();

        cy.contains('label','termos de uso')
            .find('input')
            .check()

        cy.contains('button', 'Enviar formulário')
            .click()
        
        cy.contains('Sua solicitação de consultoria foi enviada com sucesso! Em breve, nossa equipe entrará em contato através do email fornecido.')
            .should('be.visible');

    });

    // 30. Como testar mensagens de Erro e Cores CSS
    it.only('Deve verificar os campos obrigatórios', () => {
        cy.start();
        cy.submitLoginForm('papito@webdojo.com', 'katana123')

        cy.goTo('Formulários', 'Consultoria');
        cy.contains('button', 'Enviar formulário')
            .click()
        
        cy.contains('label', 'Nome Completo')
            .parent()
            .find('p')
            .should('be.visible')
            .should('have.text', 'Campo obrigatório')
            .and('have.class', 'text-red-400')
            .and('have.css', 'color', 'rgb(248, 113, 113)')

        cy.contains('label', 'Email')
            .parent()
            .find('p')
            .should('be.visible')
            .should('have.text', 'Campo obrigatório')
            .and('have.class', 'text-red-400')
            .and('have.css', 'color', 'rgb(248, 113, 113)')

        cy.contains('label', 'termos de uso *')
            .parent()
            .find('p')
            .should('be.visible')
            .should('have.text', 'Você precisa aceitar os termos de uso')
            .and('have.class', 'text-red-400')
            .and('have.css', 'color', 'rgb(248, 113, 113)')
    })
})