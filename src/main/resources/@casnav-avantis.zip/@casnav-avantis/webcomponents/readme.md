# Projeto Stencil com Exemplos em React, Angular e Vanilla JS

Este projeto demonstra o uso de **Web Components** desenvolvidos com [Stencil](https://stenciljs.com/), integrados em diferentes contextos: **React**, **Angular** e **Vanilla JavaScript**. O objetivo é ilustrar como os componentes criados podem ser facilmente reutilizados em diferentes frameworks e ambientes.

---

### 📂 Estrutura do Projeto

```plaintext
.
├── src/                # Código-fonte dos Web Components criados com Stencil
├── dist/               # Saída compilada dos componentes
├── exemplos/           # Pasta com subprojetos de exemplo
│   ├── exemplo-react/      # Exemplo com React
│   ├── exemplo-angular/    # Exemplo com Angular
│   └── exemplo-vanilla/    # Exemplo com Vanilla JS
├── stencil.config.ts   # Arquivo de configuração do Stencil
└── README.md           # Este arquivo
```

### ✨ Web Components Criados

O projeto inclui 2 Web Components simples, desenvolvidos utilizando o Stencil. Esses componentes foram compilados para permitir reutilização em diversos contextos.

Exemplos de como usá-los:

- Em um framework como React ou Angular.
- Diretamente no HTML com Vanilla JS.

### 📦 Subprojetos de Exemplos
**React App:**
  - Integração direta dos Web Components no React, sem o uso de bibliotecas adicionais como o `@stencil/react-wrapper`. O projeto demonstra como utilizar os Web Components nativos em um ambiente React.

**Angular App:**
  - Exemplo de uso dos Web Components nativos em um projeto Angular, sem necessidade de configuradores como o `@stencil/angular-output-target`. Apenas os Web Components compilados são registrados e utilizados.
  
**Vanilla JS:**
  - Um exemplo simples e direto que utiliza os Web Components compilados em um ambiente puramente HTML e JavaScript. Ideal para demonstrações e entendimento básico.

### 🚀 Como Executar 
1. <ins>Executar os Web Components<ins>

- Clone o repositório:
  ```code
  git clone http://gitlab.fsw.casnav.mb/adestramento-1/stencil-web-components-exemplos.git
  ```
- Acesse o diretório principal do projeto:
  ```code
  cd stencil-web-components-exemplos
  ```
- Instale as dependências:
  ```code
  npm install
  ```
  **Visualizar os Componentes com o Servidor de Desenvolvimento**
  - Para iniciar o servidor de desenvolvimento do Stencil e visualizar os   componentes em tempo real:
    ```code
    npm start
    ```
  - O Stencil abrirá automaticamente uma janela no navegador (geralmente em   `http://localhost:3333`) onde você poderá interagir com os componentes  renderizados.
  - Este é o método mais rápido para verificar se os componentes estão  funcionando como esperado.

  **Build dos Componentes**
  - Caso você queira apenas compilar os componentes para distribuição (sem  iniciar o servidor):
    ```code
    npm run build
    ```
  - Os arquivos compilados ficarão disponíveis na pasta `dist/`.
  
2. <ins>Executar os Subprojetos<ins>

    **React App:**
      ```code
      cd exemplos/exemplo-react
      npm install
      npm start
      ```
    **Angular App:**
      ```code
      cd exemplos/exemplo-angular
      npm install
      ng serve
      ```
    **Vanilla JS:**
      ```code
      cd exemplos/exemplo-vanilla
      npm install
      npm start
      ```
      - Pode-se usar um servidor local, como `http-server`, e executar direto o comando:
        ```code
        npx http-server
        ```