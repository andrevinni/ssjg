// tests/config/test.config.js
export const TEST_CONFIG = {
  baseURL: process.env.BASE_URL || 'http://localhost:5173',
  apiURL: process.env.API_URL || 'http://localhost:5173/api',
  credentials: {
    email: process.env.TEST_USER_EMAIL || 'teste@exemplo.com',
    password: process.env.TEST_USER_PASSWORD || 'senha123'
  },
  timeouts: {
    auth: 60000,
    navigation: 10000,
    element: 5000
  }
};