// tests/e2e/login-flexible.spec.js
import { test, expect } from '@playwright/test'

// Mapeamento dos tipos
const TIPOS = {
  '1': { label: 'NIP', field: 'nmId', example: '123456789' },
  '2': { label: 'RG', field: 'nmId', example: '12.345.678-9' },
  '3': { label: 'CPF', field: 'nmId', example: '123.456.789-00' },
  '4': { label: 'CNH', field: 'nmId', example: '12345678901' },
  '5': { label: 'PASSAPORTE', field: 'nmId', example: 'AB123456' },
  'e': { label: 'E-mail', field: 'nmId', example: 'usuario@email.com' }
}

test('login com tipo escolhido via env', async ({ page }) => {
  // Lê o tipo da variável de ambiente (ex: TIPO_ID=e npm test)
  const tipoEscolhido = process.env.TIPO_ID || '3' // padrão email
  const tipo = TIPOS[tipoEscolhido]
  
  if (!tipo) {
    throw new Error(`Tipo inválido: ${tipoEscolhido}. Use: ${Object.keys(TIPOS).join(', ')}`)
  }
  
  console.log(`\n🔐 Testando login com: ${tipo.label}`)
  console.log(`💡 Exemplo de valor: ${tipo.example}`)
  
  await page.goto('http://localhost:5173')
  await page.waitForURL(/sso\./, { timeout: 10_000 })
  
  // Preenche o formulário
  await page.selectOption('select[name="cdTipoId"]', tipoEscolhido)
  await page.fill('input[name="nmId"]', process.env.VALOR_ID || process.env.test.VITE_APP_TEST_CPF)
  await page.fill('input[name="password"]', process.env.test.VITE_APP_TEST_PASSWORD)
  
  // Aguarda input do usuário se necessário (modo debug)
  if (process.env.DEBUG_MODE === 'true') {
    console.log('⏸️  Pressione Enter para continuar...')
    await new Promise(resolve => process.stdin.once('data', resolve))
  }
  
  await page.click('#kc-login')
  await page.waitForURL('**/home', { timeout: 15_000 })
  
  console.log(`✅ Login bem sucedido com ${tipo.label}`)
  await expect(page).toHaveURL('/home')
})