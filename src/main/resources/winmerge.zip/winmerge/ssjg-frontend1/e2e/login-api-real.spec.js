// tests/e2e/login-api-real.spec.js
import { test, expect } from '@playwright/test'

const tiposIdentificador = [
  { tipo: 'e', label: 'E-mail', userVar: 'VITE_APP_TEST_EMAIL' },
  { tipo: '1', label: 'NIP', userVar: 'VITE_APP_TEST_NIP' },
  { tipo: '2', label: 'RG', userVar: 'VITE_APP_TEST_RG' },
  { tipo: '3', label: 'CPF', userVar: 'VITE_APP_TEST_CPF' },
  { tipo: '4', label: 'CNH', userVar: 'VITE_APP_TEST_CNH' },
  { tipo: '5', label: 'PASSAPORTE', userVar: 'VITE_APP_TEST_PASSAPORTE' },
  { tipo: '6', label: 'FUNCIONAL', userVar: 'VITE_APP_TEST_FUNCIONAL' }
]

test.describe('Login com diferentes tipos de identificador', () => {
  for (const { tipo, label, userVar } of tiposIdentificador) {
    test(`deve logar com ${label}`, async ({ page }) => {
      await page.goto('http://localhost:5173')
      await page.waitForURL(/sso\./, { timeout: 10_000 })

      // Seleciona o tipo
      await page.selectOption('select[name="cdTipoId"]', tipo)
      
      // Preenche identificador
      await page.fill('input[name="nmId"]', process.env[userVar])
      
      // Preenche senha
      await page.fill('input[name="password"]', process.env.VITE_APP_TEST_PASSWORD)
      
      // Submete
      await page.click('#kc-login')
      
      // Valida
      await page.waitForURL('**/home', { timeout: 15_000 })
      await expect(page).toHaveURL('/home')
      
      const token = await page.evaluate(() => localStorage.getItem('access_token'))
      expect(token).not.toBeNull()
      
      // Limpa estado para próximo teste
      await page.evaluate(() => localStorage.clear())
    })
  }
})

test('fluxo completo de login via Keycloak', async ({ page }) => {
  await page.goto('http://localhost:5173')
  await page.waitForURL(/sso\./)

  // Aguarda o formulário de identificação carregar
  await page.waitForSelector('#identificacao', { state: 'visible' })
  await page.waitForSelector('input[name="nmId"]', { state: 'visible' })
  
  // Seleciona tipo (se necessário)
  await page.selectOption('select[name="cdTipoId"]', 'e')
  
  // Preenche identificador - usa waitFor + fill combinado
  const nmIdInput = page.locator('input[name="nmId"]')
  await nmIdInput.waitFor({ state: 'visible' })
  await nmIdInput.fill(process.env.test.VITE_APP_TEST_USER)
  
  // O campo password pode estar no iframe ou DOM diferente
  await page.waitForSelector('#password', { state: 'visible' })
  const passwordInput = page.locator('#password')
  await passwordInput.waitFor({ state: 'visible' })
  await passwordInput.fill(process.env.test.VITE_APP_TEST_PASSWORD)
  
  // Clica no botão
  await page.click('#kc-login')
  
  await page.waitForURL('**/home', { timeout: 15_000 })
  await expect(page).toHaveURL('/home')
})

test('debug - inspeciona campos disponíveis', async ({ page }) => {
  await page.goto('http://localhost:5173')
  await page.waitForURL(/sso\./)

  // Aguarda o formulário ficar visível
  await page.waitForSelector('#identificacao', { state: 'visible' })
  
  // Verifica se o campo nmId existe e está visível
  const nmIdExists = await page.locator('input[name="nmId"]').count()
  console.log('Campo nmId existe?', nmIdExists)
  
  const isNmIdVisible = await page.locator('input[name="nmId"]').isVisible()
  console.log('Campo nmId visível?', isNmIdVisible)
  
  const isNmIdEnabled = await page.locator('input[name="nmId"]').isEnabled()
  console.log('Campo nmId habilitado?', isNmIdEnabled)
  
  // Mesmo para password
  const isPasswordVisible = await page.locator('#password').isVisible()
  console.log('Campo password visível?', isPasswordVisible)
  
  // Tira screenshot
  await page.screenshot({ path: 'debug-form.png', fullPage: true })
})

test('verifica iframes', async ({ page }) => {
  await page.goto('http://localhost:5173')
  await page.waitForURL(/sso\./)
  
  // Lista todos os iframes
  const frames = page.frames()
  console.log('Número de frames:', frames.length)
  
  frames.forEach((frame, index) => {
    console.log(`Frame ${index}:`, frame.url())
  })
  
  // Se os campos estiverem em um iframe, você precisa apontar para ele
  const loginFrame = page.frame('nome-do-frame') // ou page.frame({ url: /keycloak/ })
  if (loginFrame) {
    await loginFrame.fill('input[name="nmId"]', process.env.test.VITE_APP_TEST_USER)
  }
})

test('login com selectors específicos', async ({ page }) => {
  await page.goto('http://localhost:5173')
  await page.waitForURL(/sso\./)

  // Usa #nmId (id) ao invés de input[name="nmId"]
  await page.fill('#nmId', process.env.test.VITE_APP_TEST_USER)
  
  // Usa #password (id)
  await page.fill('#password', process.env.test.VITE_APP_TEST_PASSWORD)
  
  // Força um wait extra antes de clicar
  await page.waitForTimeout(1000)
  await page.click('#kc-login')
  
  await page.waitForURL('**/home', { timeout: 15_000 })
})

test('login completo com verificações', async ({ page }) => {
  await page.goto('http://localhost:5173')
  
  // Aguarda redirecionamento para SSO
  await page.waitForURL(/sso\./, { timeout: 10_000 })
  
  // Aguarda o formulário principal estar pronto
  await page.waitForSelector('#kc-form-login', { state: 'attached' })
  
  // Tenta preencher com retry automático
  await page.locator('#nmId').waitFor({ state: 'visible', timeout: 5_000 })
  await page.locator('#nmId').fill(process.env.test.VITE_APP_TEST_USER, { force: true })
  
  await page.locator('#password').waitFor({ state: 'visible', timeout: 5_000 })
  await page.locator('#password').fill(process.env.test.VITE_APP_TEST_PASSWORD, { force: true })
  
  // Aguarda botão habilitado e clica
  await page.locator('#kc-login').waitFor({ state: 'visible' })
  await page.click('#kc-login')
  
  // Aguarda navegação
  await page.waitForURL('**/home', { timeout: 15_000 })
  await expect(page).toHaveURL(/home/)
})