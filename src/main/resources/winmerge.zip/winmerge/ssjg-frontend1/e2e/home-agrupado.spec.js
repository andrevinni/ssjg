import { test, expect } from '@playwright/test';
import { injectToken } from './helpers/auth.js';

// ─── Mock helpers ──────────────────────────────────────────────────────────────

/**
 * Jogo existente conforme observado no DOM real:
 *   nome: "Jogo-SSJG", versao: "1.0", data: 10/03/2026
 */
const MOCK_JOGO_EXISTENTE = {
  id: 1,
  nome: 'Jogo-SSJG',
  versao: '1.0',
  dataCriacao: '2026-03-10T00:00:00.000Z',
  cenarios: [{ id: 1, nome: 'Cenário demo' }],
};

const mockJogosVazio = (page) =>
  page.route('**/jogos', async (route) => {
    if (route.request().method() !== 'GET') return route.continue();
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({ jogos: [] }),
    });
  });

/**
 * Mock com um jogo já criado — representa o estado real da aplicação
 * onde "Jogo-SSJG" já existe no backend.
 */
const mockJogosComUmJogo = (page) =>
  page.route('**/jogos', async (route) => {
    if (route.request().method() !== 'GET') return route.continue();
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({ jogos: [MOCK_JOGO_EXISTENTE] }),
    });
  });

// ─── Testes ────────────────────────────────────────────────────────────────────

test.describe('Home — renderização dos cards', () => {
  test.beforeEach(async ({ page }) => {
    await injectToken(page);
    await page.goto('/home');
  });

  test('exibe os três cards: CARIMBÓ, AZUVER e MAHJID', async ({ page }) => {
    await expect(page.locator('.novo-exercicio-card', { hasText: 'CARIMBÓ' })).toBeVisible();
    await expect(page.locator('.novo-exercicio-card', { hasText: 'AZUVER' })).toBeVisible();
    await expect(page.locator('.novo-exercicio-card', { hasText: 'MAHJID' })).toBeVisible();
  });

  test('AZUVER e MAHJID possuem classe CSS "disabled"', async ({ page }) => {
    await expect(page.locator('.novo-exercicio-card', { hasText: 'AZUVER' })).toHaveClass(/disabled/);
    await expect(page.locator('.novo-exercicio-card', { hasText: 'MAHJID' })).toHaveClass(/disabled/);
  });

  test('CARIMBÓ não possui classe CSS "disabled"', async ({ page }) => {
    await expect(
      page.locator('.novo-exercicio-card', { hasText: 'CARIMBÓ' })
    ).not.toHaveClass(/disabled/);
  });
});

test.describe('Home — interação com cards', () => {
  test.beforeEach(async ({ page }) => {
    await injectToken(page);
  });

  test('clicar em AZUVER (disabled) não navega nem abre modal', async ({ page }) => {
    await page.goto('/home');
    const card = page.locator('.novo-exercicio-card', { hasText: 'AZUVER' });
    
    // Verifica propriedades que impedem interação
    await expect(card).toHaveClass(/disabled/);
    
    // Verifica que não tem atributo href (se for <a>)
    const href = await card.getAttribute('href');
    expect(href).toBeNull();
    
    // Verifica CSS que impede clique
    const pointerEvents = await card.evaluate(el => 
      window.getComputedStyle(el).pointerEvents
    );
    expect(pointerEvents).toBe('none');
  });

  test('clicar em MAHJID (disabled) não navega nem abre modal', async ({ page }) => {
    await page.goto('/home');
    const card = page.locator('.novo-exercicio-card', { hasText: 'MAHJID' });
    
    // Verifica propriedades que impedem interação
    await expect(card).toHaveClass(/disabled/);
    
    // Verifica que não tem atributo href (se for <a>)
    const href = await card.getAttribute('href');
    expect(href).toBeNull();
    
    // Verifica CSS que impede clique
    const pointerEvents = await card.evaluate(el => 
      window.getComputedStyle(el).pointerEvents
    );
    expect(pointerEvents).toBe('none');
  });
  
  test('clicar em CARIMBÓ navega para /carimbo', async ({ page }) => {
    await mockJogosVazio(page);
    await page.goto('/home');
    await page.locator('.novo-exercicio-card', { hasText: 'CARIMBÓ' }).click();
    await expect(page).toHaveURL('/carimbo');
  });

  test('em /carimbo aparecem o card "Adicionar Novo Jogo" e o card do jogo existente', async ({ page }) => {
    // Simula o estado real: backend já tem "Jogo-SSJG" cadastrado
    await mockJogosComUmJogo(page);

    await page.goto('/home');
    await page.locator('.novo-exercicio-card', { hasText: 'CARIMBÓ' }).click();
    await expect(page).toHaveURL('/carimbo');

    // ── Card 1: ação de adicionar ──────────────────────────────────────────
    await expect(
      page.locator('.novo-exercicio-card', { hasText: 'Adicionar Novo Jogo' })
    ).toBeVisible();

    // ── Card 2: jogo existente com seus dados ──────────────────────────────
    const cardJogo = page.locator('.carimbo-card-wrapper');
    await expect(cardJogo).toHaveCount(1);

    await expect(cardJogo.locator('.card-label').getByText('Jogo-SSJG')).toBeVisible();
    await expect(cardJogo.locator('.card-label').getByText('Versão: 1.0')).toBeVisible();
    await expect(cardJogo.locator('.card-label').getByText('Data: 09/03/2026')).toBeVisible();

    // ── Total: 2 cards .novo-exercicio-card visíveis ───────────────────────
    await expect(page.locator('.novo-exercicio-card')).toHaveCount(2);
  });

  test('ao abrir o jogo, o mapa renderiza e o pointermove exibe tooltip sobre uma base', async ({ page }) => {
    // ── Cenário com UMA base posicionada no centro inicial da View do MapGame ──
    // center: fromLonLat([-43.1729, -22.9068]), zoom: 5
    // A base fica exatamente nesse ponto → pixel próximo ao centro do canvas.
    const CENARIO_COM_BASE = {
      id: 1,
      nome: 'Cenário demo',
      bases: [
        {
          nome: 'Base Alfa',
          tipo: 'TERRESTRE',
          partido: 'AZUL',
          coordenadas: { decimal: { latitude: -22.9068, longitude: -43.1729 } },
          simbolo: { sidcExtendido: 'SFGPUCI---**---' },
        },
      ],
    };

    await mockJogosComUmJogo(page);

    // Mock do cenário com a base
    await page.route('**/jogos/1/cenarios/1', async (route) => {
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({ cenario: CENARIO_COM_BASE }),
      });
    });

    // Tiles OSM fake (evita CORS de localhost)
    const tileBody = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAIAAADTED8xAAACwUlEQVR4nO3TMQ0AMAzAsPLHMxC7h2gwesSSAeTJnPsga9YLYJEBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5D2AVNsIpO/z/xGAAAAAElFTkSuQmCC', 'base64');
    await page.route('https://tile.openstreetmap.org/**', async (route) => {
      await route.fulfill({ status: 200, contentType: 'image/png', body: tileBody });
    });

    // ── Fluxo completo: Home → Carimbo → Mapa ────────────────────────────────
    await page.goto('/home');
    await page.locator('.novo-exercicio-card', { hasText: 'CARIMBÓ' }).click();
    await expect(page).toHaveURL('/carimbo');

    await page.locator('.carimbo-card-wrapper').click();
    await expect(page).toHaveURL('/carimbo/mapa/1/1');

    // Aguarda o useCenario resolver e o OpenLayers montar o canvas
    await expect(page.getByText('Carregando cenário...')).not.toBeVisible({ timeout: 5_000 });
    await expect(page.locator('.map-container canvas')).toBeVisible({ timeout: 10_000 });

    // Dá tempo ao OL de plotar as features (plotBases + makeSymbolCanvas)
    await page.waitForTimeout(600);

    // ── Testa o pointermove: varre pixels ao redor do centro do canvas ────────
    // O MapGame inicializa a View em fromLonLat([-43.1729, -22.9068]) zoom 5,
    // então a feature fica próxima ao centro geométrico do .map-container.
    const box = await page.locator('.map-container').boundingBox();
    const cx = box.x + box.width  / 2;
    const cy = box.y + box.height / 2;

    const offsets = [
      [0,0], [-15,0],[15,0],[0,-15],[0,15],
      [-30,0],[30,0],[0,-30],[0,30],
      [-20,-20],[20,20],[-20,20],[20,-20],
    ];

    const tooltip = page.locator('.map-tooltip');
    let found = false;
    for (const [dx, dy] of offsets) {
      await page.mouse.move(cx + dx, cy + dy);
      if (await tooltip.isVisible().catch(() => false)) { found = true; break; }
    }

    // ── Asserções do tooltip (dados vindos do pointermove handler) ────────────
    expect(found, 'Tooltip não apareceu — verifique makeSymbolCanvas em ambiente headless').toBe(true);

    await expect(page.locator('.tooltip-nome')).toHaveText('Base Alfa');
    await expect(
      page.locator('.tooltip-row', { hasText: 'TIPO' }).locator('.tooltip-value')
    ).toHaveText('TERRESTRE');
    await expect(
      page.locator('.tooltip-row', { hasText: 'PARTIDO' }).locator('.tooltip-value')
    ).toHaveText('AZUL');

    // Coordenadas DMS devem estar preenchidas (não vazias)
    const lat = await page.locator('.map-tooltip .tooltip-row', { hasText: 'LAT' })
                          .locator('.tooltip-value').textContent();
    const lon = await page.locator('.map-tooltip .tooltip-row', { hasText: 'LON' })
                          .locator('.tooltip-value').textContent();
    expect(lat?.trim().length).toBeGreaterThan(0);
    expect(lon?.trim().length).toBeGreaterThan(0);

    // Cursor deve estar "pointer" enquanto hover está sobre a feature
    const cursor = await page.locator('.map-container').evaluate(el => el.style.cursor);
    expect(cursor).toBe('pointer');
  });
});

test.describe('Home — proteção de rota', () => {
  test('acesso sem token redireciona para /', async ({ page }) => {
    // Não chama injectToken — simula usuário não autenticado
    await page.goto('/home');
    await expect(page).toHaveURL('/');
  });
});