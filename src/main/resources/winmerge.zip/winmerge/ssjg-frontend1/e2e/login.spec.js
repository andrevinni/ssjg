import { test, expect } from '@playwright/test'

// Helpers para não repetir código
const mockExchangeSuccess = (page) =>
  page.route('**/auth/exchange', async route => {
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({ accessToken: 'token-fake-123', expiresIn: 3600 }),
    })
  })

const mockGetAuthoritiesSuccess = (page) =>
  page.route('**/auth/getAuthorities', async route => {
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({ roles: ['USER'] }),
    })
  })

const mockGetAuthoritiesError = (page, status = 500) =>
  page.route('**/auth/getAuthorities', async route => {
    await route.fulfill({
      status,
      contentType: 'application/json',
      body: JSON.stringify({ error: 'Erro' }),
    })
  })

// -------------------------------------------------------

// Adiciona isso antes do primeiro test()
test.beforeEach(async ({ page }) => {
  await page.route('http://10.5.112.125:8081/**', route => route.abort())
})

test('exibe a página de login normalmente', async ({ page }) => {
  await page.goto('/')
  await expect(page.locator('button')).toBeVisible()
})

test('exibe mensagem de sessão expirada', async ({ page }) => {
  await page.goto('/')

  await page.evaluate(() => {
    window.history.replaceState({ usr: { expired: true } }, '')
    window.location.reload()
  })

  await expect(
    page.getByText('Sua sessão expirou. Faça login novamente.')
  ).toBeVisible()
})

test('autentica com sucesso e redireciona para /home', async ({ page }) => {
  await mockExchangeSuccess(page)
  await mockGetAuthoritiesSuccess(page)

  await page.goto('/?code=codigo-fake-123')

  await expect(page).toHaveURL('/home')
})

test('salva o token no localStorage após autenticar', async ({ page }) => {
  await mockExchangeSuccess(page)
  await mockGetAuthoritiesSuccess(page)

  await page.goto('/?code=codigo-fake-123')

  // Espera chegar em /home antes de ler o localStorage
  await page.waitForURL('/home')

  const token = await page.evaluate(() => localStorage.getItem('access_token'))
  expect(token).toBe('token-fake-123')
})

test('exibe loading enquanto aguarda autenticação', async ({ page }) => {
  // Deixa o exchange demorar
  await page.route('**/auth/exchange', async route => {
    await new Promise(r => setTimeout(r, 2000))
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({ accessToken: 'token-fake-123' }),
    })
  })

  await page.goto('/?code=codigo-fake-123')

  await expect(page.getByText('Validando acesso…')).toBeVisible()
})

test('exibe erro de acesso negado quando getAuthorities retorna 403', async ({ page }) => {
  await mockExchangeSuccess(page)
  await mockGetAuthoritiesError(page, 403)

  await page.goto('/?code=codigo-fake-123')

  await expect(
    page.getByText('Acesso negado. Você não tem permissão para acessar o sistema.')
  ).toBeVisible()
})

test('exibe erro genérico quando exchange falha', async ({ page }) => {
  await page.route('**/auth/exchange', async route => {
    await route.fulfill({
      status: 500,
      contentType: 'application/json',
      body: JSON.stringify({ error: 'Internal Server Error' }),
    })
  })

  await page.goto('/?code=codigo-fake-123')

  await expect(
    page.getByText('Erro na autenticação. Tente novamente.')
  ).toBeVisible()
})

test('limpa cookies e localStorage em caso de erro', async ({ page }) => {
  await mockExchangeSuccess(page)
  await mockGetAuthoritiesError(page, 500)

  await page.goto('/?code=codigo-fake-123')

  const token = await page.evaluate(() => localStorage.getItem('access_token'))
  expect(token).toBeNull()
})

test('autentica 2 com sucesso e redireciona para /home', async ({ page }) => {
  // Adicione isso temporariamente para ver a URL real
  page.on('request', req => {
    if (req.url().includes('auth')) console.log('REQUEST:', req.url())
  })

  await mockExchangeSuccess(page)
  await mockGetAuthoritiesSuccess(page)
  await page.goto('/?code=codigo-fake-123')
  await expect(page).toHaveURL('/home')
})