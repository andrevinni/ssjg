// tests/carimbo.spec.js

import { test, expect } from "./fixtures/auth.fixture.js";
import { HomePage }    from "./pages/HomePage.js";
import { CarimboPage } from "./pages/CarimboPage.js";
import {
  MOCK_JOGOS,
  MOCK_JOGO_ID,
  MOCK_CENARIO_ID,
} from "./mocks/jogos.mock.js";

// ── Helper: intercepta a chamada do useJogos ──────────────────────────────
// Ajuste a rota conforme o endpoint real do seu backend Spring Boot
async function mockJogosAPI(page, jogos = MOCK_JOGOS) {
  await page.route("**/api/jogos**", (route) =>
    route.fulfill({
      status: 200,
      contentType: "application/json",
      body: JSON.stringify(jogos),
    })
  );
}

test.describe("Carimbo — lista de jogos", () => {
  let homePage;
  let carimboPage;

  test.beforeEach(async ({ page }) => {
    homePage    = new HomePage(page);
    carimboPage = new CarimboPage(page);
    await mockJogosAPI(page);
    await homePage.goto();
    await homePage.clickCarimbo();
    await carimboPage.waitForLoad();
  });

  // ── Estrutura da página ────────────────────────────────────────────────

  test("exibe o card 'Adicionar Novo Jogo'", async () => {
    await expect(carimboPage.cardAddNew).toBeVisible();
  });

  test("exibe o botão de voltar para Home", async () => {
    await expect(carimboPage.backBtn).toBeVisible();
  });

  test("botão voltar navega para /home", async ({ page }) => {
    await carimboPage.clickBackToHome();
    await expect(page).toHaveURL(/\/home/);
  });

  // ── Lista de jogos ─────────────────────────────────────────────────────

  test("exibe os jogos retornados pela API", async () => {
    for (const jogo of MOCK_JOGOS) {
      const card = carimboPage.jogoCardByName(jogo.nome);
      await expect(card).toBeVisible();
    }
  });

  test("cards de jogo exibem nome, versão e data", async () => {
    const card = carimboPage.jogoCardByName("Operação Alfa");
    await expect(card).toContainText("Operação Alfa");
    await expect(card).toContainText("Versão: 1.0");
    await expect(card).toContainText("01/06/2024"); // toLocaleDateString pt-BR
  });

  test("jogos são ordenados do mais recente para o mais antigo", async () => {
    const cards = carimboPage.jogoCards;
    // Primeiro card deve ser "Operação Alfa" (2024-06-01 > 2024-05-15)
    await expect(cards.first()).toContainText("Operação Alfa");
    await expect(cards.last()).toContainText("Operação Beta");
  });

  // ── Hover: botões Editar / Excluir ─────────────────────────────────────

  test("hover em card de jogo exibe botões Editar e Excluir", async ({ page }) => {
    const wrapper = carimboPage.jogoCardByName("Operação Alfa");
    await wrapper.hover();
    await expect(page.locator(".carimbo-btn-editar")).toBeVisible();
    await expect(page.locator(".carimbo-btn-excluir")).toBeVisible();
  });

  test("botões Editar e Excluir estão desabilitados", async ({ page }) => {
    const wrapper = carimboPage.jogoCardByName("Operação Alfa");
    await wrapper.hover();
    await expect(page.locator(".carimbo-btn-editar")).toBeDisabled();
    await expect(page.locator(".carimbo-btn-excluir")).toBeDisabled();
  });

  // ── Navegação para o mapa ──────────────────────────────────────────────

  test("clique em jogo navega para /carimbo/mapa/:jogoId/:cenarioId", async ({ page }) => {
    await carimboPage.clickJogo("Operação Alfa");
    await expect(page).toHaveURL(
      new RegExp(`/carimbo/mapa/${MOCK_JOGO_ID}/${MOCK_CENARIO_ID}`)
    );
  });

  // ── Estados de loading e erro ──────────────────────────────────────────

  test("exibe mensagem de carregamento enquanto a API responde", async ({ page }) => {
    // Intercepta com delay para capturar o estado transitório
    await page.route("**/api/jogos**", async (route) => {
      await page.waitForTimeout(500);
      await route.fulfill({
        status: 200,
        contentType: "application/json",
        body: JSON.stringify(MOCK_JOGOS),
      });
    });
    await page.goto("/carimbo");
    await expect(carimboPage.loading).toBeVisible();
  });

  test("exibe mensagem de erro quando a API falha", async ({ page }) => {
    await page.route("**/api/jogos**", (route) =>
      route.fulfill({ status: 500, body: "Internal Server Error" })
    );
    await page.goto("/carimbo");
    await expect(carimboPage.errorMsg).toBeVisible();
  });

  // ── Lista vazia ────────────────────────────────────────────────────────

  test("quando não há jogos, apenas o card 'Adicionar' é exibido", async ({ page }) => {
    await page.route("**/api/jogos**", (route) =>
      route.fulfill({
        status: 200,
        contentType: "application/json",
        body: JSON.stringify([]),
      })
    );
    await page.goto("/carimbo");
    await carimboPage.waitForLoad();
    await expect(carimboPage.jogoCards).toHaveCount(0);
    await expect(carimboPage.cardAddNew).toBeVisible();
  });
});
