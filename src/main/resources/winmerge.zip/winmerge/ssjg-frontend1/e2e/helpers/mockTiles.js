// tests/e2e/helpers/mockTiles.js

const TILE_PNG_B64 = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==';

export const mockOsmTiles = (page) => {
  // Intercepta todas as requisições de tiles do OpenStreetMap
  page.route('**://tile.openstreetmap.org/**', async (route) => {
    console.log('🎯 Mockando tile OSM:', route.request().url());
    await route.fulfill({
      status: 200,
      contentType: 'image/png',
      body: Buffer.from(TILE_PNG_B64, 'base64'),
    });
  });
  
  // Também intercepta outros provedores comuns (caso use)
  page.route('**://*.tile.openstreetmap.org/**', async (route) => {
    await route.fulfill({
      status: 200,
      contentType: 'image/png',
      body: Buffer.from(TILE_PNG_B64, 'base64'),
    });
  });
};

// Função para verificar se os tiles estão sendo interceptados
export const verifyTilesLoaded = async (page, timeout = 10000) => {
  await page.waitForFunction(() => {
    const images = document.querySelectorAll('img[src*="tile.openstreetmap"]');
    return images.length > 0;
  }, { timeout }).catch(() => {
    console.log('⚠️ Nenhum tile OSM encontrado na página');
    return false;
  });
};