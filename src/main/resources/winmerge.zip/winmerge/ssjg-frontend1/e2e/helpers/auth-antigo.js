// tests/helpers/auth.js
import { expect } from '@playwright/test';

/**
 * Faz login na aplicação
 * @param {Page} page - Página do Playwright
 * @param {Object} options - Opções de login
 */
export async function login(page, options = {}) {
  const {
    cpf = '07935377707',
    password = 'M@rinha123!',
    url = '/',
    useApi = true // Tenta usar API primeiro
  } = options;

  // Opção 1: Login via API (mais rápido e confiável)
  if (useApi) {
    try {
      await loginViaApi(page, cpf, password);
      return;
    } catch (error) {
      console.log('Login via API falhou, tentando via UI...', error.message);
    }
  }

  // Opção 2: Login via UI (fallback)
  await loginViaUI(page, email, password, url);
}

/**
 * Login via API - mais rápido e confiável
 */
async function loginViaApi(page, email, password) {
  // Ajuste a URL da API conforme sua aplicação
  const response = await page.request.post('http://localhost:5173/api/auth/login', {
    data: { email, password }
  });

  if (!response.ok()) {
    throw new Error(`Falha no login via API: ${response.status()}`);
  }

  const data = await response.json();
  
  // Injeta o token no localStorage/sessionStorage
  await page.evaluate((token) => {
    localStorage.setItem('authToken', token);
    localStorage.setItem('user', JSON.stringify({ email: 'teste@exemplo.com' }));
  }, data.token);

  // Recarrega para aplicar autenticação
  await page.goto('/home');
}

/**
 * Login via UI - fallback
 */
async function loginViaUI(page, email, password, url) {
  // Navega para a página inicial primeiro
  await page.goto(url);
  
  // Aguarda e clica no botão de login (se existir)
  const loginButton = page.locator('button:has-text("Login"), a:has-text("Login"), button:has-text("Entrar")').first();
  if (await loginButton.isVisible().catch(() => false)) {
    await loginButton.click();
  } else {
    // Se não tem botão, tenta navegar diretamente
    await page.goto('/login');
  }

  // Aguarda o formulário de login estar visível
  await page.waitForLoadState('networkidle');

  // Tenta múltiplos seletores para os campos
  const emailSelectors = [
    'input[name="email"]',
    'input[type="email"]',
    'input[id="email"]',
    'input[placeholder*="email"]',
    'input[placeholder*="Email"]'
  ];

  const passwordSelectors = [
    'input[name="password"]',
    'input[type="password"]',
    'input[id="password"]',
    'input[placeholder*="senha"]',
    'input[placeholder*="Senha"]'
  ];

  // Encontra e preenche o campo de email
  let emailField = null;
  for (const selector of emailSelectors) {
    emailField = page.locator(selector).first();
    if (await emailField.isVisible().catch(() => false)) {
      await emailField.fill(email);
      break;
    }
  }

  if (!emailField) {
    throw new Error('Campo de email não encontrado');
  }

  // Encontra e preenche o campo de senha
  let passwordField = null;
  for (const selector of passwordSelectors) {
    passwordField = page.locator(selector).first();
    if (await passwordField.isVisible().catch(() => false)) {
      await passwordField.fill(password);
      break;
    }
  }

  if (!passwordField) {
    throw new Error('Campo de senha não encontrado');
  }

  // Clica no botão de submit
  const submitSelectors = [
    'button[type="submit"]',
    'button:has-text("Entrar")',
    'button:has-text("Login")',
    'input[type="submit"]'
  ];

  for (const selector of submitSelectors) {
    const submitButton = page.locator(selector).first();
    if (await submitButton.isVisible().catch(() => false)) {
      await submitButton.click();
      break;
    }
  }

  // Aguarda navegação após login
  await page.waitForURL('**/home', { timeout: 10000 });
}

/**
 * Setup de página autenticada
 */
export async function setupAuthenticatedPage(page, options = {}) {
  // Tenta login via API primeiro
  await login(page, { ...options, useApi: true });
  
  // Verifica se está autenticado
  const isAuthenticated = await checkIfAuthenticated(page);
  
  if (!isAuthenticated) {
    throw new Error('Falha ao autenticar página');
  }
}

/**
 * Verifica se a página está autenticada
 */
export async function checkIfAuthenticated(page) {
  try {
    // Verifica se está na home ou se tem elementos de usuário logado
    const url = page.url();
    if (url.includes('/home') || url.includes('/carimbo')) {
      return true;
    }

    // Verifica localStorage
    const hasToken = await page.evaluate(() => {
      return !!localStorage.getItem('authToken') || !!localStorage.getItem('token');
    });

    return hasToken;
  } catch {
    return false;
  }
}

/**
 * Logout
 */
export async function logout(page) {
  // Limpa storage
  await page.evaluate(() => {
    localStorage.clear();
    sessionStorage.clear();
  });

  // Se tem botão de logout, clica
  const logoutButton = page.locator('button:has-text("Sair"), button:has-text("Logout")').first();
  if (await logoutButton.isVisible().catch(() => false)) {
    await logoutButton.click();
  }
}