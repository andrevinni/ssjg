// tests/e2e/helpers/setupOfflineMap.js
export const setupOfflineMap = async (page) => {
  // Injeta script que substitui o source do OSM por um source vazio
  await page.addInitScript(() => {
    // Salva a referência original
    window.originalOSM = window.ol?.source?.OSM;
    
    // Substitui por um source que retorna tiles vazios
    if (window.ol?.source?.OSM) {
      window.ol.source.OSM = class MockOSM extends window.ol.source.OSM {
        constructor(options) {
          super(options);
          this.setUrl('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==');
        }
      };
    }
  });
};