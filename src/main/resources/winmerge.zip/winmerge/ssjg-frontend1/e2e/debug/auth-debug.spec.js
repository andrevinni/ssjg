// tests/debug/auth-debug.spec.js
import { test, expect } from '@playwright/test';

test('debug - verificar página de login', async ({ page }) => {
  // Navega para página inicial
  await page.goto('http://localhost:5173');
  
  // Screenshot inicial
  await page.screenshot({ path: 'debug-initial.png' });
  
  // Verifica elementos na página
  console.log('URL atual:', page.url());
  console.log('Título:', await page.title());
  
  // Lista todos os inputs
  const inputs = await page.locator('input').all();
  for (const input of inputs) {
    console.log('Input:', {
      name: await input.getAttribute('name'),
      type: await input.getAttribute('type'),
      placeholder: await input.getAttribute('placeholder')
    });
  }
  
  // Lista todos os botões
  const buttons = await page.locator('button').all();
  for (const button of buttons) {
    console.log('Button:', await button.textContent());
  }
  
  // Tenta encontrar rota de login
  const links = await page.locator('a').all();
  for (const link of links) {
    const href = await link.getAttribute('href');
    const text = await link.textContent();
    if (href?.includes('login') || text?.toLowerCase().includes('login') || text?.toLowerCase().includes('entrar')) {
      console.log('Link de login encontrado:', { href, text });
      await link.click();
      break;
    }
  }
  
  await page.waitForTimeout(2000);
  await page.screenshot({ path: 'debug-after-click.png' });
});

test('debug - verificar autenticação via localStorage', async ({ page }) => {
  await page.goto('http://localhost:5173');
  
  // Injeta token diretamente
  await page.evaluate(() => {
    localStorage.setItem('token', 'fake-token-123');
    localStorage.setItem('user', JSON.stringify({ id: 1, email: 'teste@exemplo.com' }));
  });
  
  await page.reload();
  await page.waitForTimeout(2000);
  
  console.log('URL após injeção:', page.url());
  console.log('LocalStorage:', await page.evaluate(() => localStorage));
  
  await page.screenshot({ path: 'debug-after-token-injection.png' });
});