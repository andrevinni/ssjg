// tests/e2e/mapa-com-mock.spec.js
import { test, expect } from '@playwright/test'
import { injectToken } from './helpers/auth.js';
import { mockOsmTiles } from './helpers/mockTiles.js';

test.describe('MapScreen — com mock de tiles', () => {
  test.beforeEach(async ({ page }) => {
    await injectToken(page);
    
    // 🔥 IMPORTANTE: Aplicar o mock ANTES de navegar para a página
    await mockOsmTiles(page);
    
    // Agora sim, navega para o mapa
    await page.goto('/carimbo/mapa/1/10');
  });

  test('mapa renderiza com tiles mockados', async ({ page }) => {
    // Aguarda o canvas do mapa existir
    await expect(page.locator('.map-container canvas')).toBeVisible({ timeout: 10000 });
    
    // Espera um pouco para os tiles "carregarem" (mock)
    await page.waitForTimeout(2000);
    
    // Tira screenshot para verificar
    await page.screenshot({ path: 'mapa-com-mock.png', fullPage: true });
    
    // Verifica se o mapa não está em branco (opcional)
    const canvasVisible = await page.locator('.map-container canvas').isVisible();
    expect(canvasVisible).toBe(true);
  });
});