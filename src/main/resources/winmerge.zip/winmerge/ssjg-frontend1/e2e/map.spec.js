import { test, expect } from '@playwright/test';
import { injectToken } from './helpers/auth.js';

// ─── Fixtures ──────────────────────────────────────────────────────────────────

/**
 * Cenário sem bases — ideal para testar o mapa sem dependência de
 * makeSymbolCanvas / milsymbol.
 */
const MOCK_CENARIO_VAZIO = {
  id: 10,
  nome: 'Cenário Alpha',
  bases: [],
};

/**
 * Cenário com UMA base posicionada exatamente no centro inicial da View
 * do MapGame [-43.1729, -22.9068]. Em teoria, com zoom 5, o pixel da feature
 * fica muito próximo do centro geométrico do container do mapa.
 *
 * ⚠️  O tooltip só aparecerá se makeSymbolCanvas() conseguir criar o canvas
 *     (requer milsymbol disponível no bundle). Veja o describe "Tooltip" abaixo.
 */
const MOCK_CENARIO_COM_BASE = {
  id: 10,
  nome: 'Cenário Alpha',
  bases: [
    {
      nome: 'Base Alfa',
      tipo: 'TERRESTRE',
      partido: 'AZUL',
      coordenadas: { decimal: { latitude: -22.9068, longitude: -43.1729 } },
      simbolo: { sidcExtendido: 'SFGPUCI---**---' },
    },
    {
      nome: 'Base Beta',
      tipo: 'NAVAL',
      partido: 'VERMELHO',
      coordenadas: { decimal: { latitude: -22.95, longitude: -43.2 } },
      simbolo: { sidcExtendido: 'SHGPUCI---**---' },
    },
  ],
};

// ─── Mock helpers ──────────────────────────────────────────────────────────────

const mockCenario = (page, cenario = MOCK_CENARIO_VAZIO, jogoId = 1, cenarioId = 10) =>
  page.route(`**/jogos/${jogoId}/cenarios/${cenarioId}`, async (route) => {
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({ cenario }),
    });
  });

const mockCenarioErro = (page) =>
  page.route('**/jogos/*/cenarios/*', async (route) => {
    await route.fulfill({ status: 500, body: 'Internal Server Error' });
  });

/** Para não travar o Carimbo quando navegamos de volta */
const mockJogosVazio = (page) =>
  page.route('**/jogos', async (route) => {
    if (route.request().method() !== 'GET') return route.continue();
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({ jogos: [] }),
    });
  });

/**
 * Intercepta todos os tiles do OSM e devolve um PNG 1×1 transparente.
 * Evita erros de CORS ao rodar o Playwright contra localhost.
 */
const TILE_PNG_B64 =
  'iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAIAAADTED8xAAACwUlEQVR4nO3TMQ0AMAzAsPLHMxC7h2gwesSSAeTJnPsga9YLYJEBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5D2AVNsIpO/z/xGAAAAAElFTkSuQmCC';

const mockOsmTiles = (page) =>
  page.route('https://tile.openstreetmap.org/**', async (route) => {
    await route.fulfill({
      status: 200,
      contentType: 'image/png',
      body: Buffer.from(TILE_PNG_B64, 'base64'),
    });
  });

/**
 * Utilitário: move o mouse varrendo pixels ao redor de (cx, cy)
 * até o locator ficar visível, ou esgota a lista de offsets.
 */
async function scanUntilVisible(page, locator, cx, cy, offsets) {
  for (const [dx, dy] of offsets) {
    await page.mouse.move(cx + dx, cy + dy);
    if (await locator.isVisible().catch(() => false)) return true;
  }
  return false;
}

// ─── Suite 1: estados de carregamento e erro ──────────────────────────────────

test.describe('MapScreen — loading e erro', () => {
  test.beforeEach(async ({ page }) => {
    await injectToken(page);
  });

  test('exibe loading enquanto aguarda resposta do cenário', async ({ page }) => {
    await page.route('**/jogos/1/cenarios/10', async (route) => {
      await new Promise((r) => setTimeout(r, 1500));
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({ cenario: MOCK_CENARIO_VAZIO }),
      });
    });
    await mockOsmTiles(page);
    await page.goto('/carimbo/mapa/1/10');
    await expect(page.getByText('Carregando cenário...')).toBeVisible();
  });

  test('exibe mensagem de erro e botão Voltar quando API falha', async ({ page }) => {
    await mockCenarioErro(page);
    await mockOsmTiles(page);
    await page.goto('/carimbo/mapa/1/10');
    await expect(page.locator('button', { hasText: 'Voltar' })).toBeVisible();
  });

  test('botão Voltar no estado de erro navega para /carimbo', async ({ page }) => {
    await mockCenarioErro(page);
    await mockJogosVazio(page);
    await page.goto('/carimbo/mapa/1/10');
    await page.locator('button', { hasText: 'Voltar' }).click();
    await expect(page).toHaveURL('/carimbo');
  });

  test('acesso sem token redireciona para /', async ({ page }) => {
    // Sem injectToken
    await page.goto('/carimbo/mapa/1/10');
    await expect(page).toHaveURL('/');
  });
});

// ─── Suite 2: renderização do mapa ───────────────────────────────────────────

test.describe('MapScreen — renderização do mapa', () => {
  test.beforeEach(async ({ page }) => {
    await injectToken(page);
    await mockCenario(page, MOCK_CENARIO_VAZIO);
    await mockOsmTiles(page);
    await page.goto('/carimbo/mapa/1/10');
    // Aguarda o mapa renderizar (canvas é criado pelo OL)
    await expect(page.locator('.map-container canvas')).toBeVisible({ timeout: 10_000 });
  });

  test('container do mapa é visível após carregamento', async ({ page }) => {
    await expect(page.locator('.map-container')).toBeVisible();
  });

  test('botão Voltar (⬅) está visível no mapa', async ({ page }) => {
    await expect(page.locator('.back-btn')).toBeVisible();
  });

  test('botão Voltar navega para /carimbo', async ({ page }) => {
    await mockJogosVazio(page);
    await page.locator('.back-btn').click();
    await expect(page).toHaveURL('/carimbo');
  });

  test('botão de filtro de partido está visível', async ({ page }) => {
    await expect(page.locator('.filter-toggle')).toBeVisible();
  });
});

// ─── Suite 3: FilterPartido ───────────────────────────────────────────────────

test.describe('MapScreen — FilterPartido', () => {
  test.beforeEach(async ({ page }) => {
    await injectToken(page);
    await mockCenario(page, MOCK_CENARIO_COM_BASE);
    await mockOsmTiles(page);
    await page.goto('/carimbo/mapa/1/10');
    await expect(page.locator('.filter-toggle')).toBeVisible();
  });

  test('clicar no toggle abre o dropdown com todas as opções', async ({ page }) => {
    await page.locator('.filter-toggle').click();
    await expect(page.locator('.filter-dropdown')).toBeVisible();

    const opcoes = ['Todos', 'Azul', 'Vermelho', 'Verde'];
    for (const label of opcoes) {
      await expect(
        page.locator('.filter-btn', { hasText: label })
      ).toBeVisible();
    }
  });

  test('"Todos" está marcado como active por padrão', async ({ page }) => {
    await page.locator('.filter-toggle').click();
    await expect(
      page.locator('.filter-btn', { hasText: 'Todos' })
    ).toHaveClass(/active/);
  });

  test('clicar em "Azul" fecha o dropdown e exibe indicador colorido', async ({ page }) => {
    await page.locator('.filter-toggle').click();
    await page.locator('.filter-btn', { hasText: 'Azul' }).click();

    await expect(page.locator('.filter-dropdown')).not.toBeVisible();
    await expect(page.locator('.filter-indicator')).toBeVisible();
  });

  test('indicador colorido não é exibido quando filtro é "Todos"', async ({ page }) => {
    // Ativa um filtro primeiro
    await page.locator('.filter-toggle').click();
    await page.locator('.filter-btn', { hasText: 'Azul' }).click();
    await expect(page.locator('.filter-indicator')).toBeVisible();

    // Volta para Todos
    await page.locator('.filter-toggle').click();
    await page.locator('.filter-btn', { hasText: 'Todos' }).click();
    await expect(page.locator('.filter-indicator')).not.toBeVisible();
  });

  test('selecionar "Vermelho" marca o botão como active', async ({ page }) => {
    await page.locator('.filter-toggle').click();
    await page.locator('.filter-btn', { hasText: 'Vermelho' }).click();

    // Reabre para verificar o active
    await page.locator('.filter-toggle').click();
    await expect(
      page.locator('.filter-btn', { hasText: 'Vermelho' })
    ).toHaveClass(/active/);
    await expect(
      page.locator('.filter-btn', { hasText: 'Todos' })
    ).not.toHaveClass(/active/);
  });

  test('clicar novamente no toggle fecha o dropdown', async ({ page }) => {
    await page.locator('.filter-toggle').click();
    await expect(page.locator('.filter-dropdown')).toBeVisible();

    await page.locator('.filter-toggle').click();
    await expect(page.locator('.filter-dropdown')).not.toBeVisible();
  });
});

// ─── Suite 4: CoordDisplay ───────────────────────────────────────────────────

test.describe('MapScreen — CoordDisplay', () => {
  test.beforeEach(async ({ page }) => {
    await injectToken(page);
    await mockCenario(page, MOCK_CENARIO_VAZIO);
    await mockOsmTiles(page);
    await page.goto('/carimbo/mapa/1/10');
    await expect(page.locator('.map-container canvas')).toBeVisible({ timeout: 10_000 });
  });

  test('CoordDisplay não está no DOM antes de qualquer movimento do mouse', async ({ page }) => {
    // O componente retorna null quando coords é null
    await expect(page.locator('.coord-display')).not.toBeVisible();
  });

  test('CoordDisplay aparece ao mover o mouse sobre o mapa', async ({ page }) => {
    const box = await page.locator('.map-container').boundingBox();
    await page.mouse.move(box.x + box.width / 2, box.y + box.height / 2);

    await expect(page.locator('.coord-display')).toBeVisible({ timeout: 3_000 });
    await expect(page.locator('.coord-label', { hasText: 'LAT' }).first()).toBeVisible();
    await expect(page.locator('.coord-label', { hasText: 'LON' }).first()).toBeVisible();
  });

  test('coordenadas exibidas mudam ao mover o mouse lateralmente', async ({ page }) => {
    const box = await page.locator('.map-container').boundingBox();
    const cx = box.x + box.width / 2;
    const cy = box.y + box.height / 2;

    await page.mouse.move(cx, cy);
    await expect(page.locator('.coord-display')).toBeVisible({ timeout: 3_000 });
    const lon1 = await page
      .locator('.coord-block')
      .nth(1)
      .locator('.coord-value')
      .textContent();

    await page.mouse.move(cx + 80, cy);
    const lon2 = await page
      .locator('.coord-block')
      .nth(1)
      .locator('.coord-value')
      .textContent();

    expect(lon1).not.toBe(lon2);
  });
});

// ─── Suite 5: MapTooltip (hover sobre feature) ───────────────────────────────

/**
 * ⚠️  DEPENDÊNCIA DE CANVAS / MILSYMBOL
 *
 * O tooltip só é exibido se plotBases() adicionar a feature com sucesso, o que
 * exige que makeSymbolCanvas() retorne um HTMLCanvasElement válido.
 * Em ambientes headless isso depende do milsymbol e da disponibilidade de canvas.
 *
 * Se esses testes forem instáveis em CI, adicione:
 *   test.skip(process.env.CI === 'true', 'requer canvas/milsymbol')
 * ou mock de makeSymbolCanvas via page.addInitScript.
 */
test.describe('MapScreen — MapTooltip', () => {
  // Offsets (dx, dy) a varrer ao redor do centro para encontrar a feature
  const SCAN_OFFSETS = [
    [0, 0], [-10, 0], [10, 0], [0, -10], [0, 10],
    [-20, 0], [20, 0], [0, -20], [0, 20],
    [-15, -15], [15, 15], [-15, 15], [15, -15],
  ];

  test.beforeEach(async ({ page }) => {
    await injectToken(page);
    await mockCenario(page, MOCK_CENARIO_COM_BASE);
    await mockOsmTiles(page);
    await page.goto('/carimbo/mapa/1/10');
    await expect(page.locator('.map-container canvas')).toBeVisible({ timeout: 10_000 });
    // Dá tempo ao OL de renderizar as features no canvas
    await page.waitForTimeout(500);
  });

  test('tooltip aparece ao passar o mouse sobre uma base no mapa', async ({ page }) => {
    const box = await page.locator('.map-container').boundingBox();
    const cx = box.x + box.width / 2;
    const cy = box.y + box.height / 2;

    const found = await scanUntilVisible(
      page,
      page.locator('.map-tooltip'),
      cx, cy,
      SCAN_OFFSETS
    );

    expect(found, 'Tooltip não apareceu — verifique makeSymbolCanvas em ambiente de teste').toBe(true);
    await expect(page.locator('.map-tooltip')).toBeVisible();
  });

  test('tooltip exibe nome, tipo e partido corretos da base', async ({ page }) => {
    const box = await page.locator('.map-container').boundingBox();
    const cx = box.x + box.width / 2;
    const cy = box.y + box.height / 2;

    await scanUntilVisible(page, page.locator('.map-tooltip'), cx, cy, SCAN_OFFSETS);

    await expect(page.locator('.tooltip-nome')).toHaveText('Base Alfa');
    await expect(
      page.locator('.tooltip-row', { hasText: 'TIPO' }).locator('.tooltip-value')
    ).toHaveText('TERRESTRE');
    await expect(
      page.locator('.tooltip-row', { hasText: 'PARTIDO' }).locator('.tooltip-value')
    ).toHaveText('AZUL');
  });

  test('tooltip exibe coordenadas em formato DMS', async ({ page }) => {
    const box = await page.locator('.map-container').boundingBox();
    const cx = box.x + box.width / 2;
    const cy = box.y + box.height / 2;

    await scanUntilVisible(page, page.locator('.map-tooltip'), cx, cy, SCAN_OFFSETS);

    // Verifica que os campos LAT e LON do tooltip não estão vazios
    const latValue = await page
      .locator('.map-tooltip .tooltip-row', { hasText: 'LAT' })
      .locator('.tooltip-value')
      .textContent();
    const lonValue = await page
      .locator('.map-tooltip .tooltip-row', { hasText: 'LON' })
      .locator('.tooltip-value')
      .textContent();

    expect(latValue?.trim().length).toBeGreaterThan(0);
    expect(lonValue?.trim().length).toBeGreaterThan(0);
  });

  test('tooltip desaparece ao mover o mouse para área sem feature', async ({ page }) => {
    const box = await page.locator('.map-container').boundingBox();
    const cx = box.x + box.width / 2;
    const cy = box.y + box.height / 2;

    // Localiza a feature
    await scanUntilVisible(page, page.locator('.map-tooltip'), cx, cy, SCAN_OFFSETS);
    await expect(page.locator('.map-tooltip')).toBeVisible();

    // Move para o canto superior esquerdo — longe de qualquer feature
    await page.mouse.move(box.x + 15, box.y + 15);
    await expect(page.locator('.map-tooltip')).not.toBeVisible({ timeout: 2_000 });
  });

  test('cursor muda para "pointer" sobre feature e volta ao normal fora dela', async ({ page }) => {
    const box = await page.locator('.map-container').boundingBox();
    const cx = box.x + box.width / 2;
    const cy = box.y + box.height / 2;

    await scanUntilVisible(page, page.locator('.map-tooltip'), cx, cy, SCAN_OFFSETS);

    const cursorSobreFeature = await page
      .locator('.map-container')
      .evaluate((el) => el.style.cursor);
    expect(cursorSobreFeature).toBe('pointer');

    // Move para área limpa
    await page.mouse.move(box.x + 15, box.y + 15);
    const cursorForaFeature = await page
      .locator('.map-container')
      .evaluate((el) => el.style.cursor);
    expect(cursorForaFeature).toBe('');
  });
});
