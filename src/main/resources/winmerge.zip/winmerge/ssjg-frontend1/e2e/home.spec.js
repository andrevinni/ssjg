import { test, expect } from '@playwright/test';
import { injectToken } from './helpers/auth.js';

// ─── Mock helpers ──────────────────────────────────────────────────────────────

/**
 * Jogo existente conforme observado no DOM real:
 *   nome: "Jogo-SSJG", versao: "1.0", data: 10/03/2026
 */
const MOCK_JOGO_EXISTENTE = {
  id: 1,
  nome: 'Jogo-SSJG',
  versao: '1.0',
  dataCriacao: '2026-03-10T00:00:00.000Z',
  cenarios: [{ id: 1, nome: 'Cenário demo' }],
};

const mockJogosVazio = (page) =>
  page.route('**/jogos', async (route) => {
    if (route.request().method() !== 'GET') return route.continue();
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({ jogos: [] }),
    });
  });

/**
 * Mock com um jogo já criado — representa o estado real da aplicação
 * onde "Jogo-SSJG" já existe no backend.
 */
const mockJogosComUmJogo = (page) =>
  page.route('**/jogos', async (route) => {
    if (route.request().method() !== 'GET') return route.continue();
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({ jogos: [MOCK_JOGO_EXISTENTE] }),
    });
  });

// ─── Testes ────────────────────────────────────────────────────────────────────

test.describe('Home — renderização dos cards', () => {
      test.beforeEach(async ({ page }) => {
        await injectToken(page);
        await page.goto('/home');
      });

      test('exibe os três cards: CARIMBÓ, AZUVER e MAHJID', async ({ page }) => {
        await expect(page.locator('.novo-exercicio-card', { hasText: 'CARIMBÓ' })).toBeVisible();
        await expect(page.locator('.novo-exercicio-card', { hasText: 'AZUVER' })).toBeVisible();
        await expect(page.locator('.novo-exercicio-card', { hasText: 'MAHJID' })).toBeVisible();
      });

      test('AZUVER e MAHJID possuem classe CSS "disabled"', async ({ page }) => {
        await expect(page.locator('.novo-exercicio-card', { hasText: 'AZUVER' })).toHaveClass(/disabled/);
        await expect(page.locator('.novo-exercicio-card', { hasText: 'MAHJID' })).toHaveClass(/disabled/);
      });

      test('CARIMBÓ não possui classe CSS "disabled"', async ({ page }) => {
        await expect(
          page.locator('.novo-exercicio-card', { hasText: 'CARIMBÓ' })
        ).not.toHaveClass(/disabled/);
      });
});

test.describe('Home — interação com cards', () => {
      test.beforeEach(async ({ page }) => {
        await injectToken(page);
      });

      test('clicar em AZUVER (disabled) não navega nem abre modal', async ({ page }) => {
        await page.goto('/home');
        const card = page.locator('.novo-exercicio-card', { hasText: 'AZUVER' });
        
        // Verifica propriedades que impedem interação
        await expect(card).toHaveClass(/disabled/);
        
        // Verifica que não tem atributo href (se for <a>)
        const href = await card.getAttribute('href');
        expect(href).toBeNull();
        
        // Verifica CSS que impede clique
        const pointerEvents = await card.evaluate(el => 
          window.getComputedStyle(el).pointerEvents
        );
        expect(pointerEvents).toBe('none');
      });

      test('clicar em MAHJID (disabled) não navega nem abre modal', async ({ page }) => {
        await page.goto('/home');
        const card = page.locator('.novo-exercicio-card', { hasText: 'MAHJID' });
        
        // Verifica propriedades que impedem interação
        await expect(card).toHaveClass(/disabled/);
        
        // Verifica que não tem atributo href (se for <a>)
        const href = await card.getAttribute('href');
        expect(href).toBeNull();
        
        // Verifica CSS que impede clique
        const pointerEvents = await card.evaluate(el => 
          window.getComputedStyle(el).pointerEvents
        );
        expect(pointerEvents).toBe('none');
      });

      test('clicar em CARIMBÓ navega para /carimbo', async ({ page }) => {
        await mockJogosVazio(page);
        await page.goto('/home');
        await page.locator('.novo-exercicio-card', { hasText: 'CARIMBÓ' }).click();
        await expect(page).toHaveURL('/carimbo');
      });

      test('em carimbo aparecem o card "Adicionar Novo Jogo" e o card do jogo existente', async ({ page }) => {
        // Simula o estado real: backend já tem "Jogo-SSJG" cadastrado
        await mockJogosComUmJogo(page);

        await page.goto('/home');
        await page.locator('.novo-exercicio-card', { hasText: 'CARIMBÓ' }).click();
        await expect(page).toHaveURL('/carimbo');

        // ── Card 1: ação de adicionar ──────────────────────────────────────────
        await expect(
          page.locator('.novo-exercicio-card', { hasText: 'Adicionar Novo Jogo' })
        ).toBeVisible();

        // ── Card 2: jogo existente com seus dados ──────────────────────────────
        const cardJogo = page.locator('.carimbo-card-wrapper');
        await expect(cardJogo).toHaveCount(1);

        await expect(cardJogo.locator('.card-label').getByText('Jogo-SSJG')).toBeVisible();
        await expect(cardJogo.locator('.card-label').getByText('Versão: 1.0')).toBeVisible();
        await expect(cardJogo.locator('.card-label').getByText('Data: 09/03/2026')).toBeVisible();

        // ── Total: 2 cards .novo-exercicio-card visíveis ───────────────────────
        await expect(page.locator('.novo-exercicio-card')).toHaveCount(2);
      });

      test('clicar no card do jogo existente navega para a tela do mapa', async ({ page }) => {
        await mockJogosComUmJogo(page);

        // Mock do cenário (MapScreen)
        await page.route('**/jogos/1/cenarios/1', async (route) => {
          await route.fulfill({
            status: 200,
            contentType: 'application/json',
            body: JSON.stringify({ cenario: { id: 1, nome: 'Cenário demo', bases: [] } }),
          });
        });

        // ── Intercepta tiles do OSM ──────────────────────────────────────────────
        // O tile.openstreetmap.org bloqueia requisições vindas de localhost (CORS).
        // Devolvemos um PNG 1×1 transparente: o canvas do OL renderiza normalmente
        // e o teste não depende de rede externa.
        const TILE_PNG_B64 =
          'iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAIAAADTED8xAAACwUlEQVR4nO3TMQ0AMAzAsPLHMxC7h2gwesSSAeTJnPsga9YLYJEBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5D2AVNsIpO/z/xGAAAAAElFTkSuQmCC';
        const tileBody = Buffer.from(TILE_PNG_B64, 'base64');

        await page.route('https://tile.openstreetmap.org/**', async (route) => {
          await route.fulfill({
            status: 200,
            contentType: 'image/png',
            body: tileBody,
          });
        });

        await page.goto('/home');
        await page.locator('.novo-exercicio-card', { hasText: 'CARIMBÓ' }).click();
        await expect(page).toHaveURL('/carimbo');

        // Clica no card do jogo (dentro do .carimbo-card-wrapper)
        await page.locator('.carimbo-card-wrapper').click();

        // handleCardClick → navigate(`/carimbo/mapa/${jogo.id}/${primeiroCenario.id}`)
        await expect(page).toHaveURL('/carimbo/mapa/1/1');

        // Aguarda o MapScreen resolver o useCenario (texto de loading some)
        await expect(page.getByText('Carregando cenário...')).not.toBeVisible({ timeout: 5_000 });

        // Aguarda o OpenLayers injetar o <canvas> dentro de .map-container
        await expect(page.locator('.map-container canvas')).toBeVisible({ timeout: 10_000 });

        // Confirma os demais elementos da UI do mapa
        await expect(page.locator('.back-btn')).toBeVisible();
        await expect(page.locator('.filter-toggle')).toBeVisible();
      });
});

test.describe('Home — proteção de rota', () => {
  test('acesso sem token redireciona para /', async ({ page }) => {
    // Não chama injectToken — simula usuário não autenticado
    await page.goto('/home');
    await expect(page).toHaveURL('/');
  });
});