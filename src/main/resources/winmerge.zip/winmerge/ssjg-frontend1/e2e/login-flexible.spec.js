// tests/e2e/login-flexible.spec.js
import { test, expect } from '@playwright/test'
import dotenv from 'dotenv'
import path from 'path'

// Carrega o arquivo .env da raiz do projeto
dotenv.config({ path: path.resolve(process.cwd(), '.env') })

// DEBUG: Verifica se as variáveis foram carregadas
console.log('🔍 Variáveis de ambiente carregadas:')
console.log('VITE_APP_TEST_USER:', process.env.VITE_APP_TEST_USER ? '✅' : '❌')
console.log('VITE_APP_TEST_PASSWORD:', process.env.VITE_APP_TEST_PASSWORD ? '✅' : '❌')
console.log('VITE_APP_TEST_CPF:', process.env.VITE_APP_TEST_CPF ? '✅' : '❌')

const TIPOS = {
  '1': { label: 'NIP', varName: 'VITE_APP_TEST_NIP' },
  '2': { label: 'RG', varName: 'VITE_APP_TEST_RG' },
  '3': { label: 'CPF', varName: 'VITE_APP_TEST_CPF' },
  '4': { label: 'CNH', varName: 'VITE_APP_TEST_CNH' },
  '5': { label: 'PASSAPORTE', varName: 'VITE_APP_TEST_PASSAPORTE' },
  'e': { label: 'E-mail', varName: 'VITE_APP_TEST_USER' }
}

test('login flexível', async ({ page }) => {
  const tipoEscolhido = process.env.TIPO_ID || 'e'
  const tipo = TIPOS[tipoEscolhido]
  
  if (!tipo) {
    throw new Error(`Tipo inválido: ${tipoEscolhido}`)
  }
  
  // Pega o identificador da variável específica do tipo
  let identificador = process.env.VALOR_ID || process.env[tipo.varName]
  
  // Fallback para o usuário padrão
  if (!identificador) {
    identificador = process.env.VITE_APP_TEST_USER
  }
  
  const senha = process.env.SENHA || process.env.VITE_APP_TEST_PASSWORD
  
  console.log(`\n🔐 Tipo: ${tipo.label}`)
  console.log(`📝 Identificador: ${identificador}`)
  
  // Se ainda não tem identificador, falha com mensagem clara
  if (!identificador) {
    throw new Error(`❌ Identificador não encontrado! Configure a variável ${tipo.varName} ou VITE_APP_TEST_USER no .env`)
  }
  
  if (!senha) {
    throw new Error('❌ Senha não encontrada! Configure VITE_APP_TEST_PASSWORD no .env')
  }
  
  await page.goto('http://localhost:5173')
  await page.waitForURL(/sso\./, { timeout: 10_000 })
  
  await page.selectOption('select[name="cdTipoId"]', tipoEscolhido)
  await page.fill('input[name="nmId"]', identificador)
  await page.fill('input[name="password"]', senha)
  
  await page.click('#kc-login')
  await page.waitForURL('**/home', { timeout: 15_000 })
  
  console.log('✅ Login realizado!')
  await expect(page).toHaveURL('/home')
})