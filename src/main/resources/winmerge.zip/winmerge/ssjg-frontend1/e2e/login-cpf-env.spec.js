// tests/e2e/login-cpf-env.spec.js
import { test, expect } from '@playwright/test'
import { injectToken } from './helpers/auth.js';
import dotenv from 'dotenv'
import path from 'path'

// Carrega as variáveis do arquivo .env
dotenv.config({ path: path.resolve(process.cwd(), '.env') })

// Configura timeout global maior para todos os testes
test.describe.configure({ timeout: 120000 }) // 2 minutos

// Função auxiliar para pausa (mais legível)
const aguardar = (ms) => new Promise(resolve => setTimeout(resolve, ms))

// Configuração que roda antes de cada teste
test.beforeEach(async ({ page }) => {
  // Adiciona slow motion para este teste específico
  await page.context().setDefaultNavigationTimeout(60000)
})

test('login com CPF usando .env', async ({ page }) => {
  // Pega as variáveis do .env
  const cpf = process.env.VITE_APP_TEST_CPF
  const senha = process.env.VITE_APP_TEST_PASSWORD
  
  // Verifica se as variáveis existem
  if (!cpf || !senha) {
    throw new Error(`
      ❌ Variáveis não encontradas!
      Verifique se o arquivo .env existe e contém:
      VITE_APP_TEST_CPF=seu-cpf-aqui
      VITE_APP_TEST_PASSWORD=sua-senha-aqui
    `)
  }
  
  console.log(`\n🔐 Testando login com CPF: ${cpf}`)
  
  await page.goto('http://localhost:5173')
  await aguardar(2000) // Pausa de 2 segundos após navegar
  
  await page.waitForURL(/sso\./, { timeout: 10000 })
  await aguardar(1500) // Pausa para garantir carregamento do formulário
  
  // Seleciona CPF (valor '3' no select)
  await page.selectOption('select[name="cdTipoId"]', '3')
  await aguardar(500)
  
  // Preenche usando as variáveis do .env
  await page.fill('input[name="nmId"]', cpf)
  await aguardar(500)
  
  await page.fill('input[name="password"]', senha)
  await aguardar(500)
  
  await page.click('#kc-login')
  await aguardar(3000) // Pausa maior após clique para garantir processamento
  
  await page.waitForURL('**/home', { timeout: 15000 })
  await aguardar(2000) // Pausa final para ver resultado
  
  await expect(page).toHaveURL('/home')
  console.log('✅ Login com CPF realizado com sucesso!')
})

// ─── Fixtures ──────────────────────────────────────────────────────────────────

/**
 * Cenário sem bases — ideal para testar o mapa sem dependência de
 * makeSymbolCanvas / milsymbol.
 */
const MOCK_CENARIO_VAZIO = {
  id: 10,
  nome: 'Cenário Alpha',
  bases: [],
};

/**
 * Cenário com UMA base posicionada exatamente no centro inicial da View
 * do MapGame [-43.1729, -22.9068]. Em teoria, com zoom 5, o pixel da feature
 * fica muito próximo do centro geométrico do container do mapa.
 *
 * ⚠️  O tooltip só aparecerá se makeSymbolCanvas() conseguir criar o canvas
 *     (requer milsymbol disponível no bundle). Veja o describe "Tooltip" abaixo.
 */
const MOCK_CENARIO_COM_BASE = {
  id: 10,
  nome: 'Cenário Alpha',
  bases: [
    {
      nome: 'Base Alfa',
      tipo: 'TERRESTRE',
      partido: 'AZUL',
      coordenadas: { decimal: { latitude: -22.9068, longitude: -43.1729 } },
      simbolo: { sidcExtendido: 'SFGPUCI---**---' },
    },
    {
      nome: 'Base Beta',
      tipo: 'NAVAL',
      partido: 'VERMELHO',
      coordenadas: { decimal: { latitude: -22.95, longitude: -43.2 } },
      simbolo: { sidcExtendido: 'SHGPUCI---**---' },
    },
  ],
};

// ─── Mock helpers ──────────────────────────────────────────────────────────────

const mockCenario = (page, cenario = MOCK_CENARIO_VAZIO, jogoId = 1, cenarioId = 10) => {
  // URL exata que seu frontend está chamando
  const url = `http://10.5.112.125:8081/jogos/${jogoId}/cenarios/${cenarioId}`;
  
  return page.route(url, async (route) => {
    console.log(`🎯 Mockando cenário: ${url}`);
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({ cenario }),
    });
  });
};

// Versão mais flexível que pega qualquer padrão
const mockCenarioFlexivel = (page, cenario = MOCK_CENARIO_VAZIO) => {
  // Intercepta qualquer requisição que contenha '/jogos/*/cenarios/*'
  return page.route(/\/jogos\/\d+\/cenarios\/\d+$/, async (route) => {
    console.log(`🎯 Mockando cenário: ${route.request().url()}`);
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({ cenario }),
    });
  });
};

const mockCenarioErro = (page) =>
  page.route('**/jogos/*/cenarios/*', async (route) => {
    await aguardar(500)
    await route.fulfill({ status: 500, body: 'Internal Server Error' });
  });

/** Para não travar o Carimbo quando navegamos de volta */
const mockJogosVazio = (page) =>
  page.route('**/jogos', async (route) => {
    if (route.request().method() !== 'GET') return route.continue();
    await aguardar(300)
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({ jogos: [] }),
    });
  });

/**
 * Intercepta todos os tiles do OSM e devolve um PNG 1×1 transparente.
 * Evita erros de CORS ao rodar o Playwright contra localhost.
 */
const TILE_PNG_B64 =
  'iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAIAAADTED8xAAACwUlEQVR4nO3TMQ0AMAzAsPLHMxC7h2gwesSSAeTJnPsga9YLYJEBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5D2AVNsIpO/z/xGAAAAAElFTkSuQmCC';

const mockOsmTiles = (page) =>
  page.route('https://tile.openstreetmap.org/**', async (route) => {
    await aguardar(100)
    await route.fulfill({
      status: 200,
      contentType: 'image/png',
      body: Buffer.from(TILE_PNG_B64, 'base64'),
    });
  });

/**
 * Utilitário: move o mouse varrendo pixels ao redor de (cx, cy)
 * até o locator ficar visível, ou esgota a lista de offsets.
 */
async function scanUntilVisible(page, locator, cx, cy, offsets) {
  for (const [dx, dy] of offsets) {
    await page.mouse.move(cx + dx, cy + dy);
    await aguardar(300) // Pausa entre movimentos
    if (await locator.isVisible().catch(() => false)) return true;
  }
  return false;
}

// ─── Suite 1: estados de carregamento e erro ──────────────────────────────────

test.describe('MapScreen — loading e erro', () => {
  test.beforeEach(async ({ page }) => {
    await injectToken(page);
  });

  test('exibe loading enquanto aguarda resposta do cenário', async ({ page }) => {
    await page.route('**/jogos/1/cenarios/10', async (route) => {
      await aguardar(1500);
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({ cenario: MOCK_CENARIO_VAZIO }),
      });
    });
    await mockOsmTiles(page);
    await page.goto('/carimbo/mapa/1/10');
    await aguardar(500)
    await expect(page.getByText('Carregando cenário...')).toBeVisible();
  });

  test('exibe mensagem de erro e botão Voltar quando API falha', async ({ page }) => {
    await mockCenarioErro(page);
    await mockOsmTiles(page);
    await page.goto('/carimbo/mapa/1/10');
    await aguardar(1000)
    await expect(page.locator('button', { hasText: 'Voltar' })).toBeVisible();
  });

  test('botão Voltar no estado de erro navega para /carimbo', async ({ page }) => {
    await mockCenarioErro(page);
    await mockJogosVazio(page);
    await page.goto('/carimbo/mapa/1/10');
    await aguardar(1000)
    await page.locator('button', { hasText: 'Voltar' }).click();
    await aguardar(1000)
    await expect(page).toHaveURL('/carimbo');
  });

  test('acesso sem token redireciona para /', async ({ page }) => {
    // Sem injectToken
    await page.goto('/carimbo/mapa/1/10');
    await aguardar(1000)
    await expect(page).toHaveURL('/');
  });
});

// ─── Suite 2: renderização do mapa ───────────────────────────────────────────

test.describe('MapScreen — renderização do mapa', () => {
  // Depois
  test.beforeEach(async ({ page }) => {
    await injectToken(page);
    await mockCenarioFlexivel(page, MOCK_CENARIO_VAZIO); // ← Agora funciona
    await mockOsmTiles(page);
    await page.goto('/carimbo/mapa/1/10');
  });

  test('container do mapa é visível após carregamento', async ({ page }) => {
    await aguardar(1000)
    await expect(page.locator('.map-container')).toBeVisible();
  });

  test('botão Voltar (⬅) está visível no mapa', async ({ page }) => {
    await aguardar(500)
    await expect(page.locator('.back-btn')).toBeVisible();
  });

  test('botão Voltar navega para /carimbo', async ({ page }) => {
    await mockJogosVazio(page);
    await aguardar(500)
    await page.locator('.back-btn').click();
    await aguardar(1000)
    await expect(page).toHaveURL('/carimbo');
  });

  test('botão de filtro de partido está visível', async ({ page }) => {
    await aguardar(500)
    await expect(page.locator('.filter-toggle')).toBeVisible();
  });
});

// ─── Suite 3: FilterPartido ───────────────────────────────────────────────────

test.describe('MapScreen — FilterPartido', () => {
  // Depois
  test.beforeEach(async ({ page }) => {
    await injectToken(page);
    await mockCenarioFlexivel(page, MOCK_CENARIO_VAZIO); // ← Agora funciona
    await mockOsmTiles(page);
    await page.goto('/carimbo/mapa/1/10');
  });

  test('clicar no toggle abre o dropdown com todas as opções', async ({ page }) => {
    await page.locator('.filter-toggle').click();
    await aguardar(500)
    await expect(page.locator('.filter-dropdown')).toBeVisible();

    const opcoes = ['Todos', 'Azul', 'Vermelho', 'Verde'];
    for (const label of opcoes) {
      await expect(
        page.locator('.filter-btn', { hasText: label })
      ).toBeVisible();
    }
  });

  test('"Todos" está marcado como active por padrão', async ({ page }) => {
    await page.locator('.filter-toggle').click();
    await aguardar(300)
    await expect(
      page.locator('.filter-btn', { hasText: 'Todos' })
    ).toHaveClass(/active/);
  });

  test('clicar em "Azul" fecha o dropdown e exibe indicador colorido', async ({ page }) => {
    await page.locator('.filter-toggle').click();
    await aguardar(300)
    await page.locator('.filter-btn', { hasText: 'Azul' }).click();
    await aguardar(500)

    await expect(page.locator('.filter-dropdown')).not.toBeVisible();
    await expect(page.locator('.filter-indicator')).toBeVisible();
  });

  test('indicador colorido não é exibido quando filtro é "Todos"', async ({ page }) => {
    // Ativa um filtro primeiro
    await page.locator('.filter-toggle').click();
    await aguardar(300)
    await page.locator('.filter-btn', { hasText: 'Azul' }).click();
    await aguardar(500)
    await expect(page.locator('.filter-indicator')).toBeVisible();

    // Volta para Todos
    await page.locator('.filter-toggle').click();
    await aguardar(300)
    await page.locator('.filter-btn', { hasText: 'Todos' }).click();
    await aguardar(500)
    await expect(page.locator('.filter-indicator')).not.toBeVisible();
  });

  test('selecionar "Vermelho" marca o botão como active', async ({ page }) => {
    await page.locator('.filter-toggle').click();
    await aguardar(300)
    await page.locator('.filter-btn', { hasText: 'Vermelho' }).click();
    await aguardar(500)

    // Reabre para verificar o active
    await page.locator('.filter-toggle').click();
    await aguardar(300)
    await expect(
      page.locator('.filter-btn', { hasText: 'Vermelho' })
    ).toHaveClass(/active/);
    await expect(
      page.locator('.filter-btn', { hasText: 'Todos' })
    ).not.toHaveClass(/active/);
  });

  test('clicar novamente no toggle fecha o dropdown', async ({ page }) => {
    await page.locator('.filter-toggle').click();
    await aguardar(300)
    await expect(page.locator('.filter-dropdown')).toBeVisible();

    await page.locator('.filter-toggle').click();
    await aguardar(300)
    await expect(page.locator('.filter-dropdown')).not.toBeVisible();
  });
});

// ─── Suite 4: CoordDisplay ───────────────────────────────────────────────────

test.describe('MapScreen — CoordDisplay', () => {
  // Depois
  test.beforeEach(async ({ page }) => {
    await injectToken(page);
    await mockCenarioFlexivel(page, MOCK_CENARIO_VAZIO); // ← Agora funciona
    await mockOsmTiles(page);
    await page.goto('/carimbo/mapa/1/10');
  });

  test('CoordDisplay não está no DOM antes de qualquer movimento do mouse', async ({ page }) => {
    await aguardar(500)
    // O componente retorna null quando coords é null
    await expect(page.locator('.coord-display')).not.toBeVisible();
  });

  test('CoordDisplay aparece ao mover o mouse sobre o mapa', async ({ page }) => {
    const box = await page.locator('.map-container').boundingBox();
    await page.mouse.move(box.x + box.width / 2, box.y + box.height / 2);
    await aguardar(500)

    await expect(page.locator('.coord-display')).toBeVisible({ timeout: 5000 });
    await expect(page.locator('.coord-label', { hasText: 'LAT' }).first()).toBeVisible();
    await expect(page.locator('.coord-label', { hasText: 'LON' }).first()).toBeVisible();
  });

  test('coordenadas exibidas mudam ao mover o mouse lateralmente', async ({ page }) => {
    const box = await page.locator('.map-container').boundingBox();
    const cx = box.x + box.width / 2;
    const cy = box.y + box.height / 2;

    await page.mouse.move(cx, cy);
    await aguardar(500)
    await expect(page.locator('.coord-display')).toBeVisible({ timeout: 5000 });
    const lon1 = await page
      .locator('.coord-block')
      .nth(1)
      .locator('.coord-value')
      .textContent();

    await page.mouse.move(cx + 80, cy);
    await aguardar(500)
    const lon2 = await page
      .locator('.coord-block')
      .nth(1)
      .locator('.coord-value')
      .textContent();

    expect(lon1).not.toBe(lon2);
  });
});

// ─── Suite 5: MapTooltip (hover sobre feature) ───────────────────────────────

/**
 * ⚠️  DEPENDÊNCIA DE CANVAS / MILSYMBOL
 *
 * O tooltip só é exibido se plotBases() adicionar a feature com sucesso, o que
 * exige que makeSymbolCanvas() retorne um HTMLCanvasElement válido.
 * Em ambientes headless isso depende do milsymbol e da disponibilidade de canvas.
 *
 * Se esses testes forem instáveis em CI, adicione:
 *   test.skip(process.env.CI === 'true', 'requer canvas/milsymbol')
 * ou mock de makeSymbolCanvas via page.addInitScript.
 */
test.describe('MapScreen — MapTooltip', () => {
  // Offsets (dx, dy) a varrer ao redor do centro para encontrar a feature
  const SCAN_OFFSETS = [
    [0, 0], [-10, 0], [10, 0], [0, -10], [0, 10],
    [-20, 0], [20, 0], [0, -20], [0, 20],
    [-15, -15], [15, 15], [-15, 15], [15, -15],
  ];

  // Depois
  test.beforeEach(async ({ page }) => {
    await injectToken(page);
    await mockCenarioFlexivel(page, MOCK_CENARIO_VAZIO); // ← Agora funciona
    await mockOsmTiles(page);
    await page.goto('/carimbo/mapa/1/10');
  });

  test('tooltip aparece ao passar o mouse sobre uma base no mapa', async ({ page }) => {
    const box = await page.locator('.map-container').boundingBox();
    const cx = box.x + box.width / 2;
    const cy = box.y + box.height / 2;

    const found = await scanUntilVisible(
      page,
      page.locator('.map-tooltip'),
      cx, cy,
      SCAN_OFFSETS
    );

    expect(found, 'Tooltip não apareceu — verifique makeSymbolCanvas em ambiente de teste').toBe(true);
    await aguardar(500)
    await expect(page.locator('.map-tooltip')).toBeVisible();
  });

  test('tooltip exibe nome, tipo e partido corretos da base', async ({ page }) => {
    const box = await page.locator('.map-container').boundingBox();
    const cx = box.x + box.width / 2;
    const cy = box.y + box.height / 2;

    await scanUntilVisible(page, page.locator('.map-tooltip'), cx, cy, SCAN_OFFSETS);
    await aguardar(500)

    await expect(page.locator('.tooltip-nome')).toHaveText('Base Alfa');
    await expect(
      page.locator('.tooltip-row', { hasText: 'TIPO' }).locator('.tooltip-value')
    ).toHaveText('TERRESTRE');
    await expect(
      page.locator('.tooltip-row', { hasText: 'PARTIDO' }).locator('.tooltip-value')
    ).toHaveText('AZUL');
  });

  test('tooltip exibe coordenadas em formato DMS', async ({ page }) => {
    const box = await page.locator('.map-container').boundingBox();
    const cx = box.x + box.width / 2;
    const cy = box.y + box.height / 2;

    await scanUntilVisible(page, page.locator('.map-tooltip'), cx, cy, SCAN_OFFSETS);
    await aguardar(500)

    // Verifica que os campos LAT e LON do tooltip não estão vazios
    const latValue = await page
      .locator('.map-tooltip .tooltip-row', { hasText: 'LAT' })
      .locator('.tooltip-value')
      .textContent();
    const lonValue = await page
      .locator('.map-tooltip .tooltip-row', { hasText: 'LON' })
      .locator('.tooltip-value')
      .textContent();

    expect(latValue?.trim().length).toBeGreaterThan(0);
    expect(lonValue?.trim().length).toBeGreaterThan(0);
  });

  test('tooltip desaparece ao mover o mouse para área sem feature', async ({ page }) => {
    const box = await page.locator('.map-container').boundingBox();
    const cx = box.x + box.width / 2;
    const cy = box.y + box.height / 2;

    // Localiza a feature
    await scanUntilVisible(page, page.locator('.map-tooltip'), cx, cy, SCAN_OFFSETS);
    await aguardar(500)
    await expect(page.locator('.map-tooltip')).toBeVisible();

    // Move para o canto superior esquerdo — longe de qualquer feature
    await page.mouse.move(box.x + 15, box.y + 15);
    await aguardar(1000)
    await expect(page.locator('.map-tooltip')).not.toBeVisible({ timeout: 3000 });
  });

  test('cursor muda para "pointer" sobre feature e volta ao normal fora dela', async ({ page }) => {
    const box = await page.locator('.map-container').boundingBox();
    const cx = box.x + box.width / 2;
    const cy = box.y + box.height / 2;

    await scanUntilVisible(page, page.locator('.map-tooltip'), cx, cy, SCAN_OFFSETS);
    await aguardar(500)

    const cursorSobreFeature = await page
      .locator('.map-container')
      .evaluate((el) => el.style.cursor);
    expect(cursorSobreFeature).toBe('pointer');

    // Move para área limpa
    await page.mouse.move(box.x + 15, box.y + 15);
    await aguardar(500)
    const cursorForaFeature = await page
      .locator('.map-container')
      .evaluate((el) => el.style.cursor);
    expect(cursorForaFeature).toBe('');
  });

  test('debug - verificar interceptação de tiles', async ({ page }) => {
    // Listener para ver todas as requisições
    page.on('request', request => {
      if (request.url().includes('tile.openstreetmap')) {
        console.log('🌍 Tile requisitado:', request.url());
      }
    });
    
    // Listener para ver respostas mockadas
    page.on('response', response => {
      if (response.url().includes('tile.openstreetmap')) {
        console.log('✅ Tile respondido:', response.status(), response.url());
      }
    });
    
    await injectToken(page);
    await mockOsmTiles(page);
    await page.goto('/carimbo/mapa/1/10');
    
    await page.waitForTimeout(5000);
    
    // Verifica se houve requisições de tile
    const tilesRequested = await page.evaluate(() => {
      return performance.getEntriesByType('resource')
        .filter(r => r.name.includes('tile.openstreetmap'))
        .length;
    });
    
    console.log(`📊 Total de tiles requisitados: ${tilesRequested}`);
    
    if (tilesRequested === 0) {
      console.log('⚠️ Nenhum tile foi requisitado - o mapa pode não estar tentando carregar tiles');
    } else {
      console.log('✅ Tiles estão sendo requisitados e mockados');
    }
  });  

  // Adicione este teste ao seu arquivo
  test('debug - visualizar mapa renderizado', async ({ page }) => {
    await injectToken(page);
    await mockCenario(page, MOCK_CENARIO_COM_BASE);
    await mockOsmTiles(page);
    
    await page.goto('/carimbo/mapa/1/10');
    
    // Aguarda o canvas do mapa
    await expect(page.locator('.map-container canvas')).toBeVisible({ timeout: 10000 });
    
    // Aguarda um pouco para renderização completa
    await page.waitForTimeout(3000);
    
    // Tira screenshot para ver o que está aparecendo
    await page.screenshot({ path: 'mapa-estado-atual.png', fullPage: true });
    
    // Verifica se o canvas tem conteúdo (não está preto/branco)
    const canvasTemConteudo = await page.evaluate(() => {
      const canvas = document.querySelector('.map-container canvas');
      if (!canvas) return false;
      
      const ctx = canvas.getContext('2d');
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      
      // Verifica se há pixels que não são cinza claro (255,255,255) ou preto (0,0,0)
      for (let i = 0; i < imageData.data.length; i += 4) {
        const r = imageData.data[i];
        const g = imageData.data[i+1];
        const b = imageData.data[i+2];
        
        // Se encontrar um pixel que não é branco (255,255,255) nem preto (0,0,0)
        if (!(r === 255 && g === 255 && b === 255) && !(r === 0 && g === 0 && b === 0)) {
          return true; // Tem conteúdo real
        }
      }
      return false; // Canvas vazio/branco/preto
    });
    
    console.log('Canvas tem conteúdo?', canvasTemConteudo);
    
    // Verifica se as bases foram plotadas
    const basesPlotadas = await page.evaluate(() => {
      // Verifica se há features no vetor source
      // Isso depende de como seu plotBases funciona
      return window.vectorSourceRef?.current?.getFeatures()?.length || 0;
    });
    
    console.log('Bases plotadas:', basesPlotadas);
    
    // Verifica se há erros no console relacionados ao milsymbol
    const consoleErrors = await page.evaluate(() => {
      return window.consoleErrors || [];
    });
    
    console.log('Erros no console:', consoleErrors);
  });

  test('debug - plotBases nao esta plotando', async ({ page }) => {
    await injectToken(page);
    await mockCenario(page, MOCK_CENARIO_COM_BASE);
    await mockOsmTiles(page);
    
    // Monitora chamadas do plotBases
    await page.addInitScript(() => {
      window.plotBasesCalls = [];
      const originalConsole = console.log;
      console.log = (...args) => {
        if (args[0]?.includes('plotBases')) {
          window.plotBasesCalls.push(args);
        }
        originalConsole.apply(console, args);
      };
    });
    
    await page.goto('/carimbo/mapa/1/10');
    await page.waitForTimeout(3000);
    
    // Verifica se as bases foram recebidas
    const cenarioBases = await page.evaluate(() => {
      return window.cenario?.bases || [];
    });
    
    console.log('Bases no cenário:', JSON.stringify(cenarioBases, null, 2));
    
    // Verifica se o vectorSource tem features
    const vectorFeatures = await page.evaluate(() => {
      if (!window.vectorSourceRef?.current) return 0;
      return window.vectorSourceRef.current.getFeatures().length;
    });
    
    console.log('Features no VectorSource:', vectorFeatures);
    
    // Verifica se o plotBases foi chamado
    const plotCalls = await page.evaluate(() => window.plotBasesCalls || []);
    console.log('Chamadas do plotBases:', plotCalls.length);
    
    // Verifica o filtro de partido
    const partidoFiltro = await page.evaluate(() => window.partidoFiltro);
    console.log('Filtro de partido atual:', partidoFiltro);
    
    // Tenta forçar o plot novamente
    await page.evaluate(() => {
      if (window.forcePlotBases) {
        window.forcePlotBases();
      }
    });
    
    await page.waitForTimeout(1000);
    
    const vectorFeaturesAfter = await page.evaluate(() => {
      if (!window.vectorSourceRef?.current) return 0;
      return window.vectorSourceRef.current.getFeatures().length;
    });
    
    console.log('Features depois de forçar:', vectorFeaturesAfter);
    
    // Screenshot para ver o mapa sem as bases
    await page.screenshot({ path: 'mapa-sem-bases.png', fullPage: true });
  });

  test('debug - plotBases corrigido com URL correta', async ({ page }) => {
    await injectToken(page);
    
    // Usa o mock com a URL correta
    await mockCenario(page, MOCK_CENARIO_COM_BASE);
    await mockOsmTiles(page);
    
    await page.goto('/carimbo/mapa/1/10');
    await page.waitForTimeout(3000);
    
    // Verifica se o cenário foi carregado
    const cenario = await page.evaluate(() => window.cenario);
    console.log('✅ Cenário carregado:', cenario ? `com ${cenario.bases?.length || 0} bases` : 'NÃO CARREGADO');
    
    if (cenario?.bases) {
      console.log('Bases encontradas:', cenario.bases.map(b => b.nome));
    }
    
    // Verifica features no mapa
    const features = await page.evaluate(() => {
      if (!window.vectorSourceRef?.current) return 0;
      return window.vectorSourceRef.current.getFeatures().length;
    });
    
    console.log('Features no VectorSource:', features);
    
    // Se ainda não tiver features, tenta forçar
    if (features === 0 && cenario?.bases?.length > 0) {
      console.log('⚠️ Forçando plotBases manualmente...');
      await page.evaluate(() => {
        if (window.plotBases && window.vectorSourceRef.current && window.cenario?.bases) {
          window.plotBases(window.vectorSourceRef.current, window.cenario.bases);
          if (window.map) window.map.render();
        }
      });
      await page.waitForTimeout(1000);
      
      const featuresAfter = await page.evaluate(() => {
        return window.vectorSourceRef?.current?.getFeatures().length || 0;
      });
      console.log('Features após força:', featuresAfter);
    }
    
    await page.screenshot({ path: 'mapa-com-bases-corrigido.png', fullPage: true });
  });

  test('debug - verificar requisição do cenário', async ({ page }) => {
    await injectToken(page);
    
    // Monitora TODAS as requisições
    page.on('request', request => {
      if (request.url().includes('cenarios')) {
        console.log('🔍 Requisição de cenário detectada:', request.url());
        console.log('   Método:', request.method());
      }
    });
    
    page.on('response', response => {
      if (response.url().includes('cenarios')) {
        console.log('📦 Resposta do cenário:', response.status());
      }
    });
    
    await mockOsmTiles(page);
    await page.goto('/carimbo/mapa/1/10');
    
    await page.waitForTimeout(3000);
    
    // Verifica o que foi carregado
    const cenarioCarregado = await page.evaluate(() => {
      return window.cenario;
    });
    
    console.log('Cenário carregado no frontend:', cenarioCarregado);
  });

  test('validar que o mock está funcionando', async ({ page }) => {
    await injectToken(page);
    await setupMocks(page, MOCK_CENARIO_COM_BASE);
    
    // Monitora as requisições
    page.on('request', request => {
      if (request.url().includes('cenarios')) {
        console.log('📡 Requisição:', request.url());
      }
    });
    
    page.on('response', response => {
      if (response.url().includes('cenarios')) {
        console.log('📦 Resposta:', response.status(), response.url());
      }
    });
    
    await page.goto('/carimbo/mapa/1/10');
    await page.waitForTimeout(2000);
    
    // Verifica se o cenário chegou no frontend
    const cenario = await page.evaluate(() => window.cenario);
    console.log('Cenário no frontend:', cenario ? `✅ ${cenario.bases?.length} bases` : '❌ undefined');
    
    expect(cenario).toBeDefined();
    expect(cenario.bases.length).toBe(2); // MOCK_CENARIO_COM_BASE tem 2 bases
  });

  test('comparar com navegador real', async ({ page }) => {
    await injectToken(page);
    await setupMocks(page, MOCK_CENARIO_COM_BASE);
    await mockOsmTiles(page);
    
    // Salva o HTML antes da navegação
    await page.goto('/carimbo/mapa/1/10');
    await page.waitForTimeout(5000);
    
    // 1. Verifica se os dados chegaram
    const dados = await page.evaluate(() => {
      return {
        cenarioRecebido: !!window.cenario,
        qtdBases: window.cenario?.bases?.length || 0,
        vectorSourceFeatures: window.vectorSourceRef?.current?.getFeatures().length || 0,
        plotBasesExiste: typeof window.plotBases === 'function',
        mapaInicializado: !!window.map
      };
    });
    
    console.log('📊 Status no Playwright:', dados);
    
    // 2. Verifica os nomes das bases que deveriam aparecer
    const nomesBases = await page.evaluate(() => {
      if (!window.cenario?.bases) return [];
      return window.cenario.bases.map(b => b.nome);
    });
    
    console.log('🏷️ Bases que deveriam estar no mapa:', nomesBases);
    
    // 3. Verifica se há elementos de texto no mapa
    const textosMapa = await page.evaluate(() => {
      const canvas = document.querySelector('.map-container canvas');
      if (!canvas) return [];
      
      // Procura por texto renderizado no canvas (difícil)
      // Alternativa: verifica se há elementos SVG/HTML sobrepostos
      const textElements = Array.from(document.querySelectorAll('.ol-layer canvas, .ol-overlaycontainer-stopevent *'))
        .map(el => el.textContent)
        .filter(t => t && t.trim().length > 0);
      
      return textElements;
    });
    
    console.log('📝 Textos encontrados no mapa:', textosMapa);
    
    // 4. Screenshot para comparar
    await page.screenshot({ path: 'playwright-mapa-sem-bases.png', fullPage: true });
  });


  test('forçar plotBases manualmente', async ({ page }) => {
    await injectToken(page);
    await setupMocks(page, MOCK_CENARIO_COM_BASE);
    await mockOsmTiles(page);
    
    await page.goto('/carimbo/mapa/1/10');
    await page.waitForTimeout(3000);
    
    // Verifica estado inicial
    let features = await page.evaluate(() => 
      window.vectorSourceRef?.current?.getFeatures().length || 0
    );
    console.log('Features antes:', features);
    
    // Força o plotBases com as bases do cenário
    const resultado = await page.evaluate(() => {
      try {
        const source = window.vectorSourceRef.current;
        const bases = window.cenario?.bases;
        
        if (!source) return { error: 'source nao encontrado' };
        if (!bases) return { error: 'bases nao encontradas', cenario: !!window.cenario };
        if (typeof window.plotBases !== 'function') return { error: 'plotBases nao é funcao' };
        
        console.log('Chamando plotBases com', bases.length, 'bases');
        window.plotBases(source, bases);
        window.map?.render();
        
        return { success: true, features: source.getFeatures().length };
      } catch (err) {
        return { error: err.message, stack: err.stack };
      }
    });
    
    console.log('Resultado força manual:', resultado);
    
    await page.waitForTimeout(1000);
    
    features = await page.evaluate(() => 
      window.vectorSourceRef?.current?.getFeatures().length || 0
    );
    console.log('Features depois:', features);
    
    await page.screenshot({ path: 'playwright-bases-forcadas.png', fullPage: true });
  });

  test('usar plotBases customizado', async ({ page }) => {
    await injectToken(page);
    await setupMocks(page, MOCK_CENARIO_COM_BASE);
    await mockOsmTiles(page);
    
    // Injeta uma versão customizada do plotBases antes do app carregar
    await page.addInitScript(() => {
      window.customPlotBases = (source, bases) => {
        if (!source || !bases) return;
        
        console.log('🎨 CustomPlotBases:', bases.length);
        
        bases.forEach(base => {
          const { latitude, longitude } = base.coordenadas.decimal;
          
          // Cria feature com ponto
          const feature = new window.ol.Feature({
            geometry: new window.ol.geom.Point(
              window.ol.proj.fromLonLat([longitude, latitude])
            ),
            nome: base.nome,
            tipo: base.tipo,
            partido: base.partido
          });
          
          // Estilo com texto
          feature.setStyle(new window.ol.style.Style({
            image: new window.ol.style.Circle({
              radius: 6,
              fill: new window.ol.style.Fill({ color: '#FF0000' }),
              stroke: new window.ol.style.Stroke({ color: '#FFFFFF', width: 2 })
            }),
            text: new window.ol.style.Text({
              text: base.nome,
              offsetY: -15,
              fill: new window.ol.style.Fill({ color: '#000000' }),
              stroke: new window.ol.style.Stroke({ color: '#FFFFFF', width: 2 }),
              font: '12px Arial'
            })
          }));
          
          source.addFeature(feature);
        });
      };
    });
    
    await page.goto('/carimbo/mapa/1/10');
    await page.waitForTimeout(3000);
    
    // Executa o plot customizado
    await page.evaluate(() => {
      if (window.vectorSourceRef?.current && window.cenario?.bases) {
        window.customPlotBases(window.vectorSourceRef.current, window.cenario.bases);
        window.map?.render();
      }
    });
    
    await page.waitForTimeout(1000);
    
    // Verifica se funcionou
    const features = await page.evaluate(() => 
      window.vectorSourceRef?.current?.getFeatures().length || 0
    );
    
    console.log('Features plotadas pelo custom:', features);
    
    await page.screenshot({ path: 'playwright-custom-bases.png', fullPage: true });
  });  

});