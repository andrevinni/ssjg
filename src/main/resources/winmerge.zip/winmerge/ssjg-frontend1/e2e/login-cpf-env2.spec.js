// tests/e2e/login-cpf-env.spec.js - versão completa e funcional

import { test, expect } from '@playwright/test'
import { injectToken } from './helpers/auth.js';
import dotenv from 'dotenv'
import path from 'path'

dotenv.config({ path: path.resolve(process.cwd(), '.env') })

// ─── Dados Mock ──────────────────────────────────────────────────

const MOCK_CENARIO_COM_BASE = {
  id: 10,
  nome: 'Cenário Alpha',
  bases: [
    {
      nome: 'Porto Velho',
      tipo: 'TERRESTRE',
      partido: 'AZUL',
      coordenadas: { decimal: { latitude: -8.7619, longitude: -63.9038 } },
      simbolo: { sidcExtendido: 'SFGPUCI---**---' },
    },
    {
      nome: 'Rio Branco',
      tipo: 'TERRESTRE',
      partido: 'AZUL',
      coordenadas: { decimal: { latitude: -9.9747, longitude: -67.81 } },
      simbolo: { sidcExtendido: 'SFGPUCI---**---' },
    },
    {
      nome: 'Cuiabá',
      tipo: 'TERRESTRE',
      partido: 'VERMELHO',
      coordenadas: { decimal: { latitude: -15.5989, longitude: -56.0949 } },
      simbolo: { sidcExtendido: 'SFGPUCI---**---' },
    },
    {
      nome: 'Belo Horizonte',
      tipo: 'TERRESTRE',
      partido: 'VERDE',
      coordenadas: { decimal: { latitude: -19.9245, longitude: -43.9352 } },
      simbolo: { sidcExtendido: 'SFGPUCI---**---' },
    },
    {
      nome: 'La Paz',
      tipo: 'TERRESTRE',
      partido: 'VERMELHO',
      coordenadas: { decimal: { latitude: -16.5, longitude: -68.15 } },
      simbolo: { sidcExtendido: 'SFGPUCI---**---' },
    }
  ],
};

// ─── Funções de Mock ──────────────────────────────────────────────────

const mockCenario = (page, cenario = MOCK_CENARIO_COM_BASE) => {
  // Intercepta a URL exata do backend
  return page.route('**/jogos/*/cenarios/*', async (route) => {
    console.log(`🎯 Mockando cenário: ${route.request().url()}`);
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({ cenario }),
    });
  });
};

const TILE_PNG_B64 = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==';

const mockOsmTiles = (page) => {
  return page.route('**://tile.openstreetmap.org/**', async (route) => {
    await route.fulfill({
      status: 200,
      contentType: 'image/png',
      body: Buffer.from(TILE_PNG_B64, 'base64'),
    });
  });
};

const setupMocks = async (page, cenario = MOCK_CENARIO_COM_BASE) => {
  await mockCenario(page, cenario);
  await mockOsmTiles(page);
};

// ─── Teste: comparar com navegador real ──────────────────────────────────

test('comparar com navegador real', async ({ page }) => {
  await injectToken(page);
  await setupMocks(page, MOCK_CENARIO_COM_BASE);
  
  // Monitora as requisições
  page.on('request', request => {
    if (request.url().includes('cenarios')) {
      console.log('📡 Requisição:', request.url());
    }
  });
  
  await page.goto('/carimbo/mapa/1/10');
  await page.waitForTimeout(5000);
  
  // 1. Verifica se os dados chegaram
  const dados = await page.evaluate(() => {
    return {
      cenarioRecebido: !!window.cenario,
      qtdBases: window.cenario?.bases?.length || 0,
      vectorSourceFeatures: window.vectorSourceRef?.current?.getFeatures().length || 0,
      plotBasesExiste: typeof window.plotBases === 'function',
      mapaInicializado: !!window.map
    };
  });
  
  console.log('📊 Status no Playwright:', dados);
  
  // 2. Verifica os nomes das bases que deveriam aparecer
  const nomesBases = await page.evaluate(() => {
    if (!window.cenario?.bases) return [];
    return window.cenario.bases.map(b => b.nome);
  });
  
  console.log('🏷️ Bases que deveriam estar no mapa:', nomesBases);
  
  // 3. Tenta forçar o plotBases manualmente
  if (dados.vectorSourceFeatures === 0 && dados.qtdBases > 0) {
    console.log('⚠️ Nenhuma feature encontrada. Forçando plotBases...');
    
    const resultado = await page.evaluate(() => {
      try {
        const source = window.vectorSourceRef?.current;
        const bases = window.cenario?.bases;
        
        if (!source) return { error: 'source nao encontrado' };
        if (!bases) return { error: 'bases nao encontradas' };
        
        // Tenta chamar plotBases se existir
        if (typeof window.plotBases === 'function') {
          window.plotBases(source, bases);
        } else {
          // Fallback: cria features manualmente
          bases.forEach(base => {
            const { latitude, longitude } = base.coordenadas.decimal;
            const feature = new window.ol.Feature({
              geometry: new window.ol.geom.Point(
                window.ol.proj.fromLonLat([longitude, latitude])
              ),
              nome: base.nome,
              tipo: base.tipo,
              partido: base.partido
            });
            source.addFeature(feature);
          });
        }
        
        window.map?.render();
        return { success: true, features: source.getFeatures().length };
      } catch (err) {
        return { error: err.message };
      }
    });
    
    console.log('Resultado força manual:', resultado);
    
    await page.waitForTimeout(1000);
    
    const featuresAfter = await page.evaluate(() => 
      window.vectorSourceRef?.current?.getFeatures().length || 0
    );
    console.log('Features após força:', featuresAfter);
  }
  
  // 4. Screenshot final
  await page.screenshot({ path: 'playwright-mapa-final.png', fullPage: true });
  
  // 5. Verifica se há texto no mapa
  const temTexto = await page.evaluate(() => {
    // Procura por texto na página (não no canvas)
    const textos = Array.from(document.querySelectorAll('*'))
      .filter(el => el.textContent && el.textContent.match(/Porto|Velho|Cuiabá|Belo/))
      .map(el => el.textContent);
    return textos.length > 0;
  });
  
  console.log('📝 Textos das cidades encontrados?', temTexto);
  
  // 6. Verifica se as bases estão visíveis (canvas tem diferença de cor)
  const canvasTemConteudo = await page.evaluate(() => {
    const canvas = document.querySelector('.map-container canvas');
    if (!canvas) return false;
    
    const ctx = canvas.getContext('2d');
    const imageData = ctx.getImageData(0, 0, Math.min(canvas.width, 100), Math.min(canvas.height, 100));
    
    // Verifica se há pixels não brancos/cinza
    for (let i = 0; i < imageData.data.length; i += 100) {
      const r = imageData.data[i];
      const g = imageData.data[i+1];
      const b = imageData.data[i+2];
      if (r !== 255 || g !== 255 || b !== 255) {
        return true;
      }
    }
    return false;
  });
  
  console.log('🎨 Canvas tem conteúdo visível?', canvasTemConteudo);
});