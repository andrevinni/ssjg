import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import svgr from 'vite-plugin-svgr';

export default defineConfig({
  plugins: [react(), 
    svgr({ include: "**/*.svg?react"}),
  ],
    server: {
    fs: {
      strict: true,
    },
  },
    proxy: {
      '/ssjg-auth': {
        target: 'http://10.5.112.125:8082',
        changeOrigin: true,
        secure: false,
      }
    },  
  build: {
    outDir: "dist",
  },
  preview: {
    port: 4173,
    strictPort: true,
    historyApiFallback: true,
  },
});