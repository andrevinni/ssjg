import React from "react";
import "./InfoBoard.scss";

export const InfoBoard = () => {
  const notices = [
    "Os botões indisponíveis no momento ainda estão em desenvolvimento.",
  ];

  return (
    <div className="notice-board">
      <h2 className="notice-title">📢   Quadro de  Avisos</h2>
      <ul className="notice-list">
        {notices.map((notice, index) => (
          <li key={index} className="notice-item">
            {notice}
          </li>
        ))}
      </ul>
    </div>
  );
};
