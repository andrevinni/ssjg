import { useState } from "react";
import "./FilterPartido.scss";

const PARTIDOS_FILTRO = [
  { valor: "TODOS",    label: "Todos",    cor: "#888888" },
  { valor: "AZUL",     label: "Azul",     cor: "#0dcaf0" },
  { valor: "VERMELHO", label: "Vermelho", cor: "#d94a4a" },
  { valor: "VERDE",    label: "Verde",    cor: "#4aaa4a" },
  
];

export function FilterPartido({ partidoAtivo, onChange }) {
  const [aberto, setAberto] = useState(false);

  const ativo = PARTIDOS_FILTRO.find((p) => p.valor === partidoAtivo);

  return (
    <div className="filter-wrapper">
      <button
        className="filter-toggle"
        onClick={() => setAberto((p) => !p)}
        title="Filtrar por partido"
      >
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
          <polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3" />
        </svg>
        {partidoAtivo !== "TODOS" && (
          <span className="filter-indicator" style={{ background: ativo?.cor }} />
        )}
      </button>

      {/* dropdown com os partidos */}
      {aberto && (
        <div className="filter-dropdown">
          {PARTIDOS_FILTRO.map(({ valor, label, cor }) => (
            <button
              key={valor}
              className={`filter-btn ${partidoAtivo === valor ? "active" : ""}`}
              style={{ "--partido-cor": cor }}
              onClick={() => { onChange(valor); setAberto(false); }}
            >
              <span className="filter-dot" />
              {label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}