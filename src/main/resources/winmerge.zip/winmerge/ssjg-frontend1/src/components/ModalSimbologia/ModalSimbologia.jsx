import { useEffect, useState } from "react";
import {getDimensoes, getSimbologiaPorDimensao } from "../../api/simbologia";
import "./ModalSimbologia.scss";
import { SymbolItem } from '../../components/SymbolItem/SymbolItem.jsx';
import { showSidc } from "../../utils/showSidc";
import CustomSelect from "../DropdownSimbol/CustomSelect.jsx";
import {SIDC_PADRAO } from "../../utils/sidcPadrao.jsx";
import { buildSidc } from "../../utils/buildSidc.jsx";
import { resetModalSimbologia } from "../../utils/resetModalSimbologia.jsx";
import { buildPayloadSimbolo } from "../../utils/buildPayloadSimbolo.jsx";
import { salvarSimbolo } from "../../api/simbologia";
import { atualizarSimbolo } from "../../api/simbologia";
import Loading from "../../components/Loading/Loading.jsx";
import { parseSdic } from "../../utils/parseSdic.jsx";

export default function ModalSimbologia({ open, onClose, onSaveSuccess, showToast, simbolo, isEdit }) {
  const [dimensoes, setDimensoes] = useState([]);
  const [selectedDimensao, setSelectedDimensao] = useState("");

  const [iconeCentral, setIconeCentral] = useState("");
  const [mod1, setMod1] = useState(null);
  const [mod2, setMod2] = useState(null);

  const [nomeSimbolo, setNomeSimbolo] = useState("");
  const [iconesCentrais, setIconesCentrais] = useState([]);
  const [primeirosMods, setPrimeirosMods] = useState([]);
  const [segundosMods, setSegundosMods] = useState([]);
  const [sidc, setSidc] = useState(showSidc(SIDC_PADRAO));

  const [extensoes, setExtensoes] = useState({
  iconeCentral: 0,
  mod1: 0,
  mod2: 0
  });
  const [loading, setLoading] = useState(false);
  const [parsedSidc, setParsedSidc] = useState(null);

  useEffect(() => {
    async function load() {
      const lista = await getDimensoes();

       const listaComSidcFinal = lista.map(item => ({
        ...item,
        sidcFinal: item.sidcFinal ?? showSidc(item.sidc)
      }));
      setDimensoes(listaComSidcFinal);
    }
    load();
  }, []);

  
  const dimSelecionada = dimensoes.find(d => d.dimensao === selectedDimensao);

  // Monta SIDC final
 useEffect(() => {

   if (!dimSelecionada) return;

  const base = dimSelecionada?.sidc ?? SIDC_PADRAO;

  const identExtensaoFinal = calcularExtensaoFinal(extensoes);

  const novoSidcObj = {
    ...base,
    iconeCentral: iconeCentral !== "" ? iconeCentral : base.iconeCentral,
    primeiroModificador: mod1 != null ? mod1.split("-")[0] : base.primeiroModificador,
    segundoModificador: mod2 != null ? mod2.split("-")[0] : base.segundoModificador,
    identExtensao: identExtensaoFinal
  };

  setSidc(showSidc(novoSidcObj));

}, [iconeCentral, mod1, mod2, extensoes, dimSelecionada]);

useEffect(() => {
  if (!simbolo || !open) return;

  setNomeSimbolo(simbolo.nome);
  setSelectedDimensao(simbolo.dimensao);

  const parsed = parseSdic(simbolo.sidcFinal);
  setParsedSidc(parsed);
  setIconeCentral(parsed.iconeCentral);

  setSidc(simbolo.sidcFinal);
}, [simbolo, open]);

useEffect(() => {

  if (!selectedDimensao) return;

  async function loadSimbologia() {
    try {
      const data = await getSimbologiaPorDimensao(selectedDimensao);
      
      // Atualiza as listas primeiro
      setIconesCentrais(data.iconeCentral || []);
      setPrimeirosMods(data.primeiroModificador || []);
      setSegundosMods(data.segundoModificador || []);

     
 if (isEdit && parsedSidc && data) {
  const pModCod = String(parsedSidc.primeiroModificador);
  const sModCod = String(parsedSidc.segundoModificador);
  const iCentCod = String(parsedSidc.iconeCentral);
  
  const extensaoTotalStr = String(parsedSidc.identExtensao);

  // Ícone Central
  const iconeObj = data.iconeCentral.find(i => String(i.codigo) === iCentCod);

  //Modificador 1
  const mod1ObjFinal = data.primeiroModificador.find(m => 
    String(m.codigo) === pModCod && 
    (Number(m.identExtensao) === 0 
      ? true 
      : extensaoTotalStr.includes(String(Number(m.identExtensao))))
  );

  //Modificador 2
  const mod2ObjFinal = data.segundoModificador.find(m => 
    String(m.codigo) === sModCod && 
    (Number(m.identExtensao) === 0 
      ? true 
      : extensaoTotalStr.includes(String(Number(m.identExtensao))))
  );

  // Atualização dos Estados
  if (mod1ObjFinal) setMod1(`${mod1ObjFinal.codigo}-${mod1ObjFinal.identExtensao}`);
  if (mod2ObjFinal) setMod2(`${mod2ObjFinal.codigo}-${mod2ObjFinal.identExtensao}`);
  if (iconeObj) setIconeCentral(iconeObj.codigo);

  setExtensoes({
    iconeCentral: Number(iconeObj?.identExtensao || 0),
    mod1: Number(mod1ObjFinal?.identExtensao || 0),
    mod2: Number(mod2ObjFinal?.identExtensao || 0)
  });

  } else if (!isEdit) {
        // Reset para modo criação
        setIconeCentral("");
        setMod1(null);
        setMod2(null);
        setExtensoes({ iconeCentral: 0, mod1: 0, mod2: 0 });
      }
    } catch (error) {
      console.error("Erro ao carregar simbologia:", error);
    }
  }

  loadSimbologia();
  
}, [selectedDimensao, parsedSidc, isEdit]);


  if (!open) return null;

 const itemPreview = {
  sidcFinal: sidc
 };

 const resetModal = ()=>{
 resetModalSimbologia({
  setSelectedDimensao,
  setIconeCentral,
  setMod1,
  setMod2,
  setIconesCentrais,
  setPrimeirosMods,
  setSegundosMods,
  setSidc,
  setExtensoes
 });
  setNomeSimbolo("");
 }

 function calcularExtensaoFinal(ext) {
  return (
    ext.iconeCentral +
    ext.mod1 +
    ext.mod2
  ).toString().padStart(7, "0");
}



const handleSave = async () => {
  try {
    if (!nomeSimbolo || !selectedDimensao) {
      showToast?.("error", "Preencha os campos obrigatórios");
      return;
    }

    setLoading(true);

    const payload = buildPayloadSimbolo({
      nome: nomeSimbolo,
      dimensao: selectedDimensao,
      sidc,
      extensoes
    });

    let response;

    if (isEdit) {
      response = await atualizarSimbolo(simbolo.id, payload);
      showToast?.("success", "Atualizado com sucesso!");
    } else {
      response = await salvarSimbolo(payload);
      showToast?.("success", "Salvo com sucesso!");
    }

    onSaveSuccess?.({
      ...response,
      sidcFinal: sidc
    });

    resetModal();
    onClose();

  } catch (error) {
    console.error(error);
    showToast?.("error", "Erro ao salvar símbolo");
  } finally {
    setLoading(false);
  }
};

  return (
    <div className="modal-overlay">
      {loading && <Loading message="Salvando símbolo..." fullScreen />}
      <div className="modal-box">

        <div className="modal-header">
          <h2> {isEdit ? "EDITAR - SÍMBOLOS" : "CADASTRAR - SÍMBOLOS"}</h2>
          <button className="close-btn" onClick={()=>{resetModal(), onClose()}}>✖</button>
        </div>

        <div className="modal-grid">

          <div className="form-area">
            <input
              className="modal-input"
              placeholder="Nome *"
              value={nomeSimbolo}
              onChange={(e) => setNomeSimbolo(e.target.value)}
            />
         <div className="field-container">
           <legend>Dimensão *</legend>
           <CustomSelect
           items={dimensoes}
           selected={selectedDimensao}
           onChange={(value) => setSelectedDimensao(value)}
           getSidc={item => item.sidcFinal}
           />
          </div>   
          <div className="field-container">
           <legend>Icone Central</legend>
           <CustomSelect
             items={iconesCentrais}
             selected={iconeCentral}
             onChange={(codigo) => {
                const item = iconesCentrais.find(i => i.codigo === codigo);
                setIconeCentral(codigo);
                setExtensoes(prev => ({
                 ...prev,
                iconeCentral: Number(item?.identExtensao || 0)
               }));
              }}
             getKey={item => item.codigo}
             getLabel={item => item.nome}
             getSidc={item =>
             buildSidc({
              base: dimSelecionada?.sidc ?? SIDC_PADRAO,
              iconeCentral: item.codigo
             })
             }
           />

          </div>
          <div className="field-container">
           <legend>Primeiro Modificador</legend>
           <CustomSelect
           items={primeirosMods}
           selected={mod1}
          
          onChange={(key) => {
            const item = primeirosMods.find(i => `${i.codigo}-${i.identExtensao}` === key);
            setMod1(key);
            if (item) {
             setExtensoes(prev => ({
             ...prev,
             mod1: Number(item.identExtensao)
             }));
            }
          }}
          getKey={item => `${item.codigo}-${item.identExtensao}`}
          getLabel={item => item.nome}
          getSidc={item =>
          buildSidc({
           base: dimSelecionada?.sidc ?? SIDC_PADRAO,
           primeiroModificador: item.codigo,
           identExtensao: item.identExtensao
         })
         }
        />
            </div>

           <div className="field-container">
           <legend>Segundo Modificador</legend>
            <CustomSelect
             items={segundosMods}
             selected={mod2}
             onChange={(key) => {
              const item = segundosMods.find(
              i => `${i.codigo}-${i.identExtensao}` === key
              );
             setMod2(key);
             setExtensoes(prev => ({
             ...prev,
             mod2: Number(item?.identExtensao || 0)
             }));
             }}
              getKey={item => `${item.codigo}-${item.identExtensao}`}
              getLabel={item => item.nome}
              getSidc={item =>
               buildSidc({
                base: dimSelecionada?.sidc ?? SIDC_PADRAO,
                segundoModificador: item.codigo,
                identExtensao: item.identExtensao
             })
             }
             />

            </div>

            <div className="btn-row">
              <button className="btn-outline" onClick={onClose}>Fechar</button>
              <button className="btn-primary" onClick={handleSave}>{isEdit ? "Atualizar" : "Salvar"}</button>
            </div>
          </div>

          {/* PREVIEW */}
          <div className="symbol-box">
           <SymbolItem item={itemPreview} />
           <span className="sidc-text">{sidc}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
