import { useEffect, useRef, useState } from "react";
import 'ol/ol.css';
import { Map, View } from 'ol';
import TileLayer from 'ol/layer/Tile';
import OSM from 'ol/source/OSM';
import VectorLayer from 'ol/layer/Vector';
import VectorSource from 'ol/source/Vector';
import { fromLonLat, toLonLat } from 'ol/proj';              // 1️⃣ adiciona toLonLat
import { useNavigate } from "react-router-dom";
import { useMouseCoords } from "../../hooks/useMouseCoords";
import { plotBases } from "../../utils/plotBases";
import { CoordDisplay } from "../CoordDisplay/CoordDisplay";
import { FilterPartido } from "../FilterPartido/FilterPartido";
import { MapTooltip } from "../MapTooltip/MapTooltip";        // 2️⃣ importa MapTooltip
import { formatDMS, decimalToDMS } from "../../utils/decimalToDms"; // 3️⃣ importa conversão
import ModalMeios from "../ModalMeios/ModalMeios";
import "./MapGame.scss";

export const MapGame = ({ cenario }) => {
  const navigate = useNavigate();
  const mapRef = useRef(null);
  const vectorSourceRef = useRef(new VectorSource());
  const [map, setMap] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [partidoFiltro, setPartidoFiltro] = useState("TODOS");
  const [tooltip, setTooltip] = useState(null);              // 4️⃣ estado do tooltip
  const mouseCoords = useMouseCoords(map);

  // ── Inicializa o mapa ──────────────────────────────────────────────────
  useEffect(() => {
    if (!mapRef.current) return;
    const mapInstance = new Map({
      target: mapRef.current,
      layers: [
        new TileLayer({ source: new OSM() }),
        new VectorLayer({ source: vectorSourceRef.current }),
      ],
      view: new View({
        center: fromLonLat([-43.1729, -22.9068]),
        zoom: 5,
      }),
      controls: [],
    });

    // 5️⃣ detecta hover sobre feature e exibe tooltip
    mapInstance.on("pointermove", (evt) => {
      const feature = mapInstance.forEachFeatureAtPixel(evt.pixel, (f) => f);
      if (feature) {
        const [lon, lat] = toLonLat(feature.getGeometry().getCoordinates());
        setTooltip({
          position: { x: evt.pixel[0], y: evt.pixel[1] },
          info: {
            nome:    feature.get("nome"),
            tipo:    feature.get("tipo"),
            partido: feature.get("partido"),
            lat:     formatDMS(decimalToDMS(lat, true)),
            lon:     formatDMS(decimalToDMS(lon, false)),
          },
        });
        mapInstance.getTargetElement().style.cursor = "pointer";
      } else {
        setTooltip(null);
        mapInstance.getTargetElement().style.cursor = "";
      }
    });

    setMap(mapInstance);
    return () => mapInstance.setTarget(null);
  }, []);

  // ── Plotar bases no Mapa ───────────────────────────────────────────────
  useEffect(() => {
    const bases = cenario?.bases;
    if (!map || !bases?.length) return;
    const basesFiltradas = partidoFiltro === "TODOS"
      ? bases
      : bases.filter((b) => b.partido?.toUpperCase() === partidoFiltro);
    plotBases(vectorSourceRef.current, basesFiltradas);
  }, [map, cenario, partidoFiltro]);

  return (
    <div className="map-wrapper">
      <div ref={mapRef} className="map-container" />

      <button className="back-btn" onClick={() => navigate("/carimbo")} title="Voltar para Carimbo">
        ⬅
      </button>

      <FilterPartido partidoAtivo={partidoFiltro} onChange={setPartidoFiltro} />

      <CoordDisplay coords={mouseCoords} />

      {/* 6️⃣ renderiza o tooltip */}
      <MapTooltip info={tooltip?.info} position={tooltip?.position} />

      {showModal && (
        <ModalMeios map={map} onClose={() => setShowModal(false)} />
      )}
    </div>
  );
};