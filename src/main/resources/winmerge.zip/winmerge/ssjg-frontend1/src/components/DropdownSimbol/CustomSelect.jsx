import { useState } from "react";
import "./CustomSelect.scss";
import { SymbolItem } from "../SymbolItem/SymbolItem";
import { useMakeSymbol } from "../../utils/makeSymbol";

export default function CustomSelect({ items, selected, onChange, 
  getKey = item => item.dimensao ?? item.codigo,
  getLabel = item => item.nome ?? "",
  getSidc = () => null }) {

  const [open, setOpen] = useState(false);


const selectedKey = (selected !== null && selected !== undefined && String(selected).trim() !== "") 
  ? String(selected).trim() 
  : null;


const selectedItem = selectedKey 
  ? items.find(i => String(getKey(i)).trim() === selectedKey) 
  : null;

  const selectedIcon = useMakeSymbol(selectedItem ? getSidc(selectedItem) : null);

  return (
    <div className="custom-select">
      <div className="select-display" onClick={() => setOpen(prev => !prev)}>
      <div className="select-content">
       {selectedItem ? (
       <>
        {selectedIcon && (
          <img
            src={selectedIcon}
            alt={getLabel(selectedItem)}
            className="select-icon"
          />
        )}
        <span>{getLabel(selectedItem)}</span>
        </>
        ) : (
       <span className="placeholder">Selecionar</span>
        )}
      </div>
      <span className={`caret ${open ? "open" : ""}`}>▼</span>
      </div>

      {open && (
        <div className="options-list">
          {items.map(item => (
            <div
              className="option-item"
              key={getKey(item)}
              onClick={(e) => {
                e.stopPropagation();
                onChange(getKey(item));
                setOpen(false);
              }}
            >
              {getSidc(item) && <SymbolItem item={{ sidcFinal: getSidc(item) }} />}
              <span>{getLabel(item)}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
