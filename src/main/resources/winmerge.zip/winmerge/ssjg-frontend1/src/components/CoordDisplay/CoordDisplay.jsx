import "./CoordDisplay.scss";

/**
 * Exibe as coordenadas DMS no mapa.
 *
 * @param {{ lat: string, lon: string }|null} coords
 */

export function CoordDisplay({ coords }) {
  if (!coords) return null;

  return (
    <div className="coord-display">
      <div className="coord-block">
        <span className="coord-label">LAT</span>
        <span className="coord-value">{coords.lat}</span>
      </div>
      <div className="coord-divider" />
      <div className="coord-block">
        <span className="coord-label">LON</span>
        <span className="coord-value">{coords.lon}</span>
      </div>
    </div>
  );
}