import React, { useState } from "react";
import { User, LogOut } from "lucide-react";
import Cookies from "js-cookie";
import { useNavigate } from "react-router-dom";
import "./UserMenu.scss";

function getNomeDoToken() {
  try {
    const token = localStorage.getItem("access_token");
    if (!token) return "Usuário";
    const payload = JSON.parse(atob(token.split('.')[1]));
    return payload.name || payload.preferred_username || "Usuário";
  } catch {
    return "Usuário";
  }
}

export const UserMenu = () => {
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);

  const handleLogout = () => {
    Cookies.remove("access_token");
    localStorage.clear();
    navigate("/", { replace: true });
  };

  const userName  = getNomeDoToken();
  const firstName = userName.trim().split(/\s+/)[0];

  return (
    <div className="user-menu">
      <button className="user-menu-btn" onClick={() => setOpen(!open)}>
        <User className="user-icon" />
        <span className="user-name">Olá, {firstName}</span>
      </button>
      {open && (
        <div className="user-dropdown">
          <button className="dropdown-item logout" onClick={handleLogout}>
            <LogOut className="dropdown-icon" />
            Sair
          </button>
        </div>
      )}
    </div>
  );
};