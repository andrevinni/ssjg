import "./MapTooltip.scss";

/**
 * Tooltip que aparece ao passar o mouse sobre uma base no mapa.
 * @param {{ nome, tipo, partido, lat, lon }} info
 * @param {{ x, y }} position - posição em pixels na tela
 */
export function MapTooltip({ info, position }) {
  if (!info || !position) return null;

  const PARTIDO_COR = {
    AZUL:     "#0dcaf0",
    VERMELHO: "#d94a4a",
    VERDE:    "#4aaa4a",
  };

  const cor = PARTIDO_COR[info.partido?.toUpperCase()] ?? "#888";

  return (
    <div
      className="map-tooltip"
      style={{ left: position.x + 14, top: position.y - 10 }}
    >
      <div className="tooltip-header" style={{ borderColor: cor }}>
        <span className="tooltip-dot" style={{ background: cor }} />
        <span className="tooltip-nome">{info.nome}</span>
      </div>
      <div className="tooltip-row">
        <span className="tooltip-label">TIPO</span>
        <span className="tooltip-value">{info.tipo}</span>
      </div>
      <div className="tooltip-row">
        <span className="tooltip-label">PARTIDO</span>
        <span className="tooltip-value" style={{ color: cor }}>{info.partido}</span>
      </div>
      <div className="tooltip-row">
        <span className="tooltip-label">LAT</span>
        <span className="tooltip-value">{info.lat}</span>
      </div>
      <div className="tooltip-row">
        <span className="tooltip-label">LON</span>
        <span className="tooltip-value">{info.lon}</span>
      </div>
    </div>
  );
}