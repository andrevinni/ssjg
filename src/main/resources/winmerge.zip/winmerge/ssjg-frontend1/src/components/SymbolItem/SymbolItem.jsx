
import { useMakeSymbol } from "../../utils/makeSymbol";
import './SymbolItem.scss'
export const SymbolItem = ({ item }) => {

const simboloPNG = useMakeSymbol(item?.sidcFinal ?? null);

  return (
    <div class='symbol-row'>
      {simboloPNG && <img src={simboloPNG} alt={item.nome} />}
      <p>{item.nome}</p>
    </div>
  );
};
