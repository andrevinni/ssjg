import { useState } from "react";
import { createJogo } from "../../api/gameApi";
import "./ModalGame.scss";

export const ModalGame = ({ setIsOpen, onCreate }) => {
  const [form, setForm] = useState({ nome: "", versao: "", dataExecucao: "" });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const isFormValid = form.nome && form.versao && form.dataExecucao;

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!isFormValid) return;

    setLoading(true);
    setError(null);

    try {
      const novoJogo = await createJogo(form); // retorna jogo
      setForm({ nome: "", versao: "", dataExecucao: "" });
      onCreate(novoJogo);
    } catch (err) {
      console.error(err);
      setError("Erro ao criar jogo. Tente novamente.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="modal-overlay" onClick={() => setIsOpen(false)}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <h2 className="modal-title">Criar Novo Jogo</h2>

        <form onSubmit={handleSubmit}>
          <label htmlFor="nome">Nome do Jogo</label>
          <input
            type="text"
            name="nome"
            value={form.nome}
            onChange={handleChange}
            placeholder="Digite o nome do jogo"
          />

          <label htmlFor="versao">Versão</label>
          <input
            type="text"
            name="versao"
            value={form.versao}
            onChange={handleChange}
            placeholder="Ex: 1.0"
          />

          <label htmlFor="dataExecucao">Data de Execução</label>
          <input
            type="date"
            name="dataExecucao"
            value={form.dataExecucao}
            onChange={handleChange}
          />

          {error && <p className="modal-error">{error}</p>}

          <div className="modal-actions">
            <button
              type="button"
              onClick={() => setIsOpen(false)}
              className="btn btn-cancel"
              disabled={loading}
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={!isFormValid || loading}
              className="btn btn-create"
            >
              {loading ? "Criando..." : "Criar"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};