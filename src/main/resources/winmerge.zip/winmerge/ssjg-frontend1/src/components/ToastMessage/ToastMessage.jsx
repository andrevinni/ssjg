import "./ToastMessage.scss";

export default function ToastMessage({ type, message }) {
  if (!message) return null;

  return (
    <div className={`toast ${type}`}>
      {message}
    </div>
  );
}