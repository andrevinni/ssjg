import { Navigate } from "react-router-dom";
import Cookies from "js-cookie";

export const PrivateRoute = ({ children }) => {
  const token = Cookies.get("access_token") || localStorage.getItem("access_token");
  if (!token) {
    return <Navigate to="/" replace />;
  }
  return children;
};