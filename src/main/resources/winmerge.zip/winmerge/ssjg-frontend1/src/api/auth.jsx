import axios from "axios";

const GATEWAY_URL = window.API_BASEURL;

export async function exchangeCode(code, redirectUri) {

  const response = await fetch(`${GATEWAY_URL}/auth/exchange`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ code, redirectUri }),
  });

  const responseText = await response.text();


  if (!response.ok) throw new Error(`Exchange falhou: ${responseText}`);

  const data = JSON.parse(responseText);
  const token = data.accessToken || data.access_token;
  if (!token) throw new Error("Token não encontrado na resposta");

  if (data.expiresIn) {
    localStorage.setItem("token_expires_in", Date.now() + (data.expiresIn * 1000));
  }
  if (data.refreshToken) {
    localStorage.setItem("refresh_token", data.refreshToken);
  }

  return token;
}

export async function autenticateUserLogin(token) {

  return axios.get(`${GATEWAY_URL}/auth/getAuthorities`, {
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: "*/*",
    },
  })
  .then(resp => {
    return resp.data || {};
  })
  .catch(err => {
    console.error(" Erro getAuthorities:", err.response?.status, err.response?.data);
    throw err;
  });
}