const BASE_URL = window.API_BASEURL
import { showSidc } from "../utils/showSidc";

function getAuthHeaders() {
  const token = localStorage.getItem("access_token");

  return {
    "Content-Type": "application/json",
    ...(token && { Authorization: `Bearer ${token}` }),
  };
}

export async function getSimbolos() {
  try {
    const response = await fetch(
      `${BASE_URL}/simbolos`, {
    headers: getAuthHeaders(),
  });
  

    const data = await response.json();
 
    // já retorna com SIDC pronto
    return data.map((item) => ({
      ...item,
      sidcFinal: showSidc(item.sidcExtendido)
    }));

  } catch (error) {
    console.error("Erro ao carregar símbolos:", error);
    return [];
  }
}

export async function getDimensoes() {
  try {
    const response = await fetch(`${BASE_URL}/dimensoes`, {
    headers: getAuthHeaders(),
  });
    
    const data = await response.json();

    const lista = data.dimensoes ?? [];

    return lista.map(item => ({
      ...item
    }));

  } catch (error) {
    console.error("Erro ao carregar simbologia:", error);
    return [];
  }
}

export async function getSimbologiaPorDimensao(dimensao) {
  try {
    const response = await fetch(
      `${BASE_URL}/simbologia/${dimensao}`, {
    headers: getAuthHeaders(),
  }
    );
    const data = await response.json();

    return {
      iconeCentral: data.iconeCentral ?? [],
      primeiroModificador: data.primeiroModificador ?? [],
      segundoModificador: data.segundoModificador ?? []
    };
  } catch (error) {
    console.error("Erro ao carregar simbologia:", error);
    return {
      iconeCentral: [],
      primeiroModificador: [],
      segundoModificador: []
    };
  }
}

export async function deleteSimbolo(id) {
  try {
    await fetch(`${BASE_URL}/simbolos/${id}`, {
      method: "DELETE",
      headers: getAuthHeaders(),
    });

    return true;
  } catch (error) {
    console.error("Erro ao excluir símbolo:", error);
    return false;
  }
}

export async function salvarSimbolo(payload) {
  const response = await fetch(`${BASE_URL}/simbolos`, {
    method: "POST",
    headers:  getAuthHeaders(),
    body: JSON.stringify(payload)
  });

  if (!response.ok) {
    throw new Error("Erro ao salvar símbolo");
  }

  return response.json();
}

export async function atualizarSimbolo(id, payload) {
  const response = await fetch(`${BASE_URL}/simbolos/${id}`, {
    method: "PUT",
    headers: getAuthHeaders(),
    body: JSON.stringify(payload)
  });

  if (!response.ok) {
    throw new Error("Erro ao atualizar símbolo");
  }

  return response.json();
}

