const BASE_URL = window.API_BASEURL

function getAuthHeaders() {
  const token = localStorage.getItem("access_token");

  return {
    "Content-Type": "application/json",
    ...(token && { Authorization: `Bearer ${token}` }),
  };
}

export async function fetchJogos() {

  const response = await fetch(`${BASE_URL}/jogos`, {
    headers: getAuthHeaders(),
  });


  if (!response.ok) throw new Error(`Erro ao buscar jogos: ${response.status}`);
  const data = await response.json();
  return data.jogos;
}

/**
 * GET /jogos/:jogoId/cenarios/:cenarioId
 * Retorna { cenario: { id, nome, bases, plataformas } }
 */
export async function fetchCenario(jogoId, cenarioId) {
  const response = await fetch(`${BASE_URL}/jogos/${jogoId}/cenarios/${cenarioId}`, {
    headers: getAuthHeaders(),
  });
  if (!response.ok) throw new Error(`Erro ao buscar cenário: ${response.status}`);
  const data = await response.json();
  return data.cenario;
}

/**
 * POST
 * Por enquanto retorna mock com cenarioId=1 para abrir o mapa na demonstração.
 */
export async function createJogo(payload) {
  // --- descomentar quando a rota estiver pronta ---
  // const response = await fetch(`${BASE_URL}/jogos`, {
  //   method: "POST",
  //   headers: { "Content-Type": "application/json" },
  //   body: JSON.stringify(payload),
  // });
  // if (!response.ok) throw new Error(`Erro ao criar jogo: ${response.status}`);
  // const data = await response.json();
  // return data.jogo;
 
  return {
    id: 1,
    ...payload,
    dataCriacao: new Date().toISOString(),
    cenarios: [{ id: 1, nome: "Cenário demo" }],
  };
}