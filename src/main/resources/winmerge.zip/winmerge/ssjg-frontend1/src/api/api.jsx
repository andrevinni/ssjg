import axios from 'axios';
import Cookies from "js-cookie";

const baseUrl = window.API_BASEURL

const api = axios.create()

api.interceptors.request.use(
  (config) => {
    const token = Cookies.get("access_token");
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

const requestConfig = {
  headers: {
      Authorization: `Bearer ${Cookies.get("access_token")}`,
      Accept: "*/*"
  }
}

const formatarArgQuery = (k, v) => 
  v ? `&${k}=${encodeURIComponent(v)}` : ''

const montarQueryString = (criterios = {}) => 
  Object.entries(criterios)
  .map(([k, v]) =>
  v ? (Array.isArray(v) 
    ? v.map((va) => formatarArgQuery(k, va)).join('') 
    : formatarArgQuery(k, v)) 
    : ''
).join('')

const tratarErroAxios = (err) => {
  if (err.response) {
    console.error("Erro API:", err.response.data);
    throw new Error(err.response.data?.message || err);
  }
  throw err;
};

export {
  api,
  montarQueryString,
  requestConfig,
  baseUrl,
  tratarErroAxios 
}
