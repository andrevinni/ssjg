export function parseSdic(sdic) {
  return {
    versao: sdic.slice(0, 2),
    hostilidade: sdic.slice(2, 4),
    dimensao: sdic.slice(4, 6),
    situacao: sdic.slice(6, 7),
    forcaTarefa: sdic.slice(7, 8),
    amplificadores: sdic.slice(8, 10),
    iconeCentral: sdic.slice(10, 16),
    primeiroModificador: sdic.slice(16, 18),
    segundoModificador: sdic.slice(18, 20),
    identPais: sdic.slice(20, 23),
    identExtensao: sdic.slice(23, 30),
  };
}