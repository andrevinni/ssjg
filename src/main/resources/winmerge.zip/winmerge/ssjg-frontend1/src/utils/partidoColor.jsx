// Cor por partido
 export const COLOR_MAP = {
  AZUL:     { iconColor: "#1a3a6b", fillColor: "#0dcaf0" },
  VERMELHO: { iconColor: "#6b1a1a", fillColor: "#d94a4a" },
  VERDE:    { iconColor: "#1a4a1a", fillColor: "#4aaa4a" },
  AMARELO:  { iconColor: "#6b5a00", fillColor: "#f0c430" },
};