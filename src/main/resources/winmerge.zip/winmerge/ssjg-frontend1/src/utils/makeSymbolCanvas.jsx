import  {COLOR_MAP} from "./partidoColor.jsx"
/**
 * @param {string} sidc     - SIDC completo
 * @param {string} partido  - "AZUL" | "VERMELHO" | "VERDE" | "AMARELO"
 * @returns {HTMLCanvasElement|null}
 */
// Função usada pelo open Layers
export function makeSymbolCanvas(sidc, partido) {
  if (!window.ms || !sidc || typeof sidc !== "string") return null;

 
  const colors = COLOR_MAP[partido?.toUpperCase()] ?? COLOR_MAP.AZUL;
 
  try {
    const symbol = new window.ms.Symbol(sidc.trim(), {
      size: 40,
      fillColor: colors.fillColor,
      iconColor: colors.iconColor,
      strokeWidth: 2,
    });
    return symbol.asCanvas();
  } catch (error) {
    console.error("makeSymbolCanvas: erro ao criar símbolo:", error);
    return null;
  }
}