import { useEffect, useState } from "react";
import { makeSymbolCanvas } from "./makeSymbolCanvas";

// retorna PNG base64
/**
 * @param {string} sidc     - SIDC completo
 * @param {string} partido  - "AZUL" | "VERMELHO" | "VERDE" | "AMARELO"
 * @returns {string|null}   - data URL PNG ou null
 */
export const useMakeSymbol = (sidc, partido) => {
  const [simboloPNG, setSimboloPNG] = useState(null);
 
  useEffect(() => {
    const canvas = makeSymbolCanvas(sidc, partido);
    setSimboloPNG(canvas ? canvas.toDataURL() : null);
  }, [sidc, partido]);
 
  return simboloPNG;
};
