import Cookies from "js-cookie";

const AUTH_SERVER  = window.OAUTH2_URL;
const CLIENT_ID    = window.OAUTH2_CLIENT_ID;
const REDIRECT_URI = window.location.origin;

export function redirectToLogin() {
  Cookies.remove("access_token");
  localStorage.removeItem("access_token");

  const url = `${AUTH_SERVER}/protocol/openid-connect/auth?` +
    new URLSearchParams({
      client_id: CLIENT_ID,
      response_type: "code",
      redirect_uri: REDIRECT_URI,
      scope: "openid profile email",
    });
  window.location.href = url;
}

export { REDIRECT_URI };