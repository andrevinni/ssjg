import Feature from "ol/Feature";
import Point from "ol/geom/Point";
import { Style, Icon } from "ol/style";
import { fromLonLat } from "ol/proj";
import { showSidc } from "../utils/showSidc";
import { makeSymbolCanvas } from "../utils/makeSymbolCanvas";

/**
 * Plota as bases no VectorSource do OpenLayers.
 *
 * @param {import("ol/source/Vector").default} vectorSource - source do layer
 * @param {Array} bases - lista de bases vindas do backend
 */
export function plotBases(vectorSource, bases) {
  if (!bases?.length) return;

  vectorSource.clear();

  bases.forEach((base) => {
    const { latitude, longitude } = base.coordenadas.decimal;

    const sidcString = showSidc(base.simbolo.sidcExtendido);
    const canvas = makeSymbolCanvas(sidcString, base.partido);

    if (!canvas) return;

    const feature = new Feature({
      geometry: new Point(fromLonLat([longitude, latitude])),
      nome: base.nome,
      tipo: base.tipo,
      partido: base.partido,
    });

    feature.setStyle(
      new Style({
        image: new Icon({
          img: canvas,
          size: [canvas.width, canvas.height],
          anchor: [0.5, 0.5],
        }),
      })
    );

    vectorSource.addFeature(feature);
  });
}