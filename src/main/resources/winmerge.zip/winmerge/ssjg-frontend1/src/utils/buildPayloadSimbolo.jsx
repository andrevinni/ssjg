import { parseSdic } from "./parseSdic";

export function buildPayloadSimbolo({
  nome,
  dimensao,
  sidc,
  extensoes
}) {
  const parsed = parseSdic(sidc);

  return {
    nome,
    dimensao,
    sidcExtendido: {
      ...parsed,
      extensaoModificadores: {
        extensaoModificadorTransversal: 0,
        extensaoPrimeiroModificador: extensoes?.mod1 ?? 0,
        extensaoSegundoModificador: extensoes?.mod2 ?? 0,
        extensaoIconeCentral: extensoes?.iconeCentral ?? 0,
      }
    }
  };
}