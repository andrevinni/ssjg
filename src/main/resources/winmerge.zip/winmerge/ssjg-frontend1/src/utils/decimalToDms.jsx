/**
 * Converte graus decimais para objeto DMS
 * @param {number} decimal - valor em graus decimais
 * @param {boolean} isLat  - true para latitude, false para longitude
 * @returns {{ grau: number, minuto: number, segundo: string, direcao: string }}
 */
export function decimalToDMS(decimal, isLat) {
  const abs = Math.abs(decimal);
  const grau = Math.floor(abs);
  const minDecimal = (abs - grau) * 60;
  const minuto = Math.floor(minDecimal);
  const segundo = ((minDecimal - minuto) * 60).toFixed(2);
  const direcao = isLat
    ? decimal >= 0 ? "N" : "S"
    : decimal >= 0 ? "E" : "W";

  return { grau, minuto, segundo, direcao };
}

/**
 * Formata objeto DMS como string legível
 * @param {{ grau: number, minuto: number, segundo: string, direcao: string }} dms
 * @returns {string} ex: "22° 54' 24.48" S"
 */
export function formatDMS({ grau, minuto, segundo, direcao }) {
  return `${grau}° ${minuto}' ${segundo}" ${direcao}`;
}