import React from "react";
import ssjgLogo from "../assets/img/ssjg.png";
import marinhaLogo from "../assets/img/marinha.gif";
import brasaoLogo from "../assets/img/brasao.png";
import BoxForm from "../components/Boxform/BoxForm.jsx"

const HandleLogin = ({onLogin, errorMessage}) => {
  return (
    <div className="login-container">
      <div className="login-header-logos">
        <img src={marinhaLogo} alt="Logo Marinha" />
        <img src={brasaoLogo} alt="Logo Brasão" />
        <img src={ssjgLogo} alt="Logo SSJG" />
      </div>

      <BoxForm logo={ssjgLogo} title="Sistema Simulador para Jogos de Guerra">
        <div className="login-form">
         
          <p>
            Para acessar o sistema, clique no botão abaixo e faça login pelo Score 2.0.
          </p>

          <button onClick={onLogin}>Autenticar</button>
           {errorMessage && <div className="error-card">{errorMessage}</div>}
        </div>
      </BoxForm>
    </div>
  );
};

export default  HandleLogin;
 