import { useEffect, useState, useRef } from 'react';
import { useNavigate } from "react-router-dom";
import Cookies from "js-cookie";
import HandleLogin from './HandleLogin';
import { exchangeCode, autenticateUserLogin } from '../api/auth';
import Loading from '../components/Loading/Loading';
import { redirectToLogin } from '../utils/redirectToLogin';

const redirectUri = window.location.origin;

const Login = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState(null);
  const hasRun = useRef(false);

  // Detecta se veio de um logout por expiração
  useEffect(() => {
    const state = window.history.state?.usr;
    if (state?.expired) {
      setErrorMessage("Sua sessão expirou. Faça login novamente.");
    }
  }, []);

  useEffect(() => {
    if (hasRun.current) return;
    hasRun.current = true;

    const params = new URLSearchParams(window.location.search);
    const code = params.get("code");

    if (code) window.history.replaceState({}, document.title, "/");
    if (!code) return;

    const autenticar = async () => {
      setLoading(true);
      try {
        const token = await exchangeCode(code, redirectUri);

        Cookies.set("access_token", token, { sameSite: "Lax" });
        localStorage.setItem("access_token", token);

        await autenticateUserLogin(token);

        // Agenda logout automático
        const expMs = parseInt(localStorage.getItem("token_expires_in"));
        if (expMs && !isNaN(expMs)) {
          const msRestantes = expMs - Date.now();
          if (msRestantes > 0) {
            setTimeout(() => {
              Cookies.remove("access_token");
              localStorage.clear();
              navigate("/", { replace: true, state: { expired: true } });
            }, msRestantes);
          }
        }

        navigate("/home", { replace: true });

      } catch (err) {
        console.error("Erro na autenticação:", err);
        Cookies.remove("access_token");
        localStorage.clear();
        const status = err?.response?.status;
        if (status === 403) {
          setErrorMessage("Acesso negado. Você não tem permissão para acessar o sistema.");
        } else {
          setErrorMessage("Erro na autenticação. Tente novamente.");
        }
      } finally {
        setLoading(false);
      }
    };

    autenticar();
  }, []);

  if (loading) {
    return <Loading fullScreen message="Validando acesso…" />;
  }

  return (
    <div>
      <HandleLogin onLogin={redirectToLogin} errorMessage={errorMessage} />
    </div>
  );
};

export default Login;