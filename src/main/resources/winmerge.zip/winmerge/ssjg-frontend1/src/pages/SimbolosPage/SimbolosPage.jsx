import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import ModalSimbologia from "../../components/ModalSimbologia/ModalSimbologia";
import "./SimbolosPage.scss";
import { getSimbolos } from "../../api/simbologia";
import SimboloCard from "../../components/SimboloCard/SimboloCard";
import {deleteSimbolo} from "../../api/simbologia"
import ConfirmDialog from "../../components/ConfirmDialog/ConfirmDialog";
import ToastMessage from "../../components/ToastMessage/ToastMessage";
const SimbolosPage = () => {
  const navigate = useNavigate();

  const [openModal, setOpenModal] = useState(false);
  const [search, setSearch] = useState("");
  const [simbolos, setSimbolos] = useState([]);
  const [simboloSelect, setSimboloSelect] = useState(null);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [toast, setToast] = useState({
  type: "",
  message: ""
});
const [isEdit, setIsEdit] = useState(false);
const [simboloEditando, setSimboloEditando] = useState(null);

useEffect(() => {
  async function loadSimbolos() {
    const data = await getSimbolos();
    setSimbolos(data);
  }

  loadSimbolos();
}, []);

useEffect(() => {
  if (!toast.message) return;

  const timer = setTimeout(() => {
    setToast({ type: "", message: "" });
  }, 3000);

  return () => clearTimeout(timer);
}, [toast]);

  const simbolosFiltrados = simbolos.filter((s) =>
    s.nome?.toLowerCase().includes(search.toLowerCase())
  );

 async function confirmarDelete() {
  const ok = await deleteSimbolo(simboloSelect);

  if (ok) {
    setSimbolos(prev => prev.filter(s => s.id !== simboloSelect));
    setSimboloSelect(null);
  }

  setConfirmOpen(false);
}



  return (
    <div className="simbolos-page">
      <header className="header">
        <h2>Símbolos</h2>

        <div className="actions">
          <div className="search-wrapper">
          <span className="search-icon">🔍</span>
          <input
           type="text"
           placeholder="Buscar símbolo..."
           value={search}
           onChange={(e) => setSearch(e.target.value)}
          />
        </div>


          <button onClick={() => {setIsEdit(false);setSimboloEditando(null); setOpenModal(true);}}>
            + Novo Símbolo
          </button>
          <button
           onClick={() => {
            const simbolo = simbolos.find(s => s.id === simboloSelect);
            setSimboloEditando(simbolo);
            setIsEdit(true);
            setOpenModal(true);
          }}
          disabled={!simboloSelect}
         >
          ✏️ Editar
        </button>
          <button 
          onClick={() => setConfirmOpen(true)} 
          disabled={!simboloSelect} 
          className="delete">
           🗑 Excluir
          </button>


          <button className="close" onClick={() => navigate(-1)}>
            ✕
          </button>
        </div>
      </header>
      <ToastMessage type={toast.type} message={toast.message} />

      <div className="lista-simbolos">
        {simbolosFiltrados.map((simbolo) => (
    <SimboloCard 
    key={simbolo.id} 
    simbolo={simbolo} 
    simboloSelect={simboloSelect === simbolo.id}
    onClick={() => setSimboloSelect(prev => prev === simbolo.id ? null : simbolo.id)}
    />
  ))}
      </div>

    <ModalSimbologia
     open={openModal}
     onClose={() => {
      setOpenModal(false);
      setIsEdit(false);
      setSimboloEditando(null);
     }}
    simbolo={simboloEditando}
    isEdit={isEdit}
    onSaveSuccess={(simboloSalvo, error) => {
  if (error) {
    setToast({
      type: "error",
      message: error
    });
    return;
  }

  if (isEdit) {
    setSimbolos(prev =>
      prev.map(s =>
        s.id === simboloSalvo.id ? simboloSalvo : s
      )
    );

    setToast({
      type: "success",
      message: "Atualizado com sucesso!"
    });
  } else {
    setSimbolos(prev => [simboloSalvo, ...prev]);

    setToast({
      type: "success",
      message: "Salvo com sucesso!"
    });
  }
}}
  showToast={(type, message) =>
    setToast({ type, message })
  }
    />
      <ConfirmDialog
      open={confirmOpen}
      title="Excluir símbolo"
      message="Tem certeza que deseja excluir este símbolo?"
      onConfirm={confirmarDelete}
      onCancel={() => setConfirmOpen(false)}
     />

    </div>

  );
};

export default SimbolosPage;
