import addButton from '../../assets/img/adicionar.svg';
import carimbo from '../../assets/img/carimbo.png';
import { CardAction } from "../../components/CardAction/CardAction.jsx";
import { ModalGame } from "../../components/ModalGame/ModalGame.jsx";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useJogos } from "../../hooks/useJogos";
import "./Carimbo.scss";

const Carimbo = () => {
  const navigate = useNavigate();
  const [isOpen, setIsOpen] = useState(false);
  const [hoveredIndex, setHoveredIndex] = useState(null);
  const [jogosLocais, setJogosLocais] = useState([]);

  const { jogos, loading, error, refetch } = useJogos();

  const jogosOrdenados = [...jogos, ...jogosLocais].sort(
    (a, b) => new Date(b.dataCriacao) - new Date(a.dataCriacao)
  );

  const handleCreateGame = (novoJogo) => {
    if (novoJogo) {
      setJogosLocais((prev) => [novoJogo, ...prev]);
    } else {
      refetch();
    }
    setIsOpen(false);
  };

  const handleCardClick = (jogo) => {
    const primeiroCenario = jogo.cenarios?.[0];
    if (!primeiroCenario) return; 
    navigate(`/carimbo/mapa/${jogo.id}/${primeiroCenario.id}`);
  };

  return (
    <div className="new-game">
      <button className="back-btn-home" onClick={() => navigate("/home")} title="Voltar para Home">
        ⬅
      </button>

      <CardAction
        className="add-button-card"
        label="Adicionar Novo Jogo"
        icon={addButton}
        onClick={() => setIsOpen(true)}
      />

      {isOpen && <ModalGame setIsOpen={setIsOpen} onCreate={handleCreateGame} />}

      {loading && <p style={{ color: "#888" }}>Carregando jogos...</p>}
      {error && <p style={{ color: "red" }}>{error}</p>}

      <div className="carimbo-jogos">
        {jogosOrdenados.map((jogo, index) => (
          <div
            key={jogo.id}
            className="carimbo-card-wrapper"
            onMouseEnter={() => setHoveredIndex(index)}
            onMouseLeave={() => setHoveredIndex(null)}
          >
            <CardAction
              className="carimbo-card"
              label={
                <div className="card-label">
                  <div>{jogo.nome}</div>
                  <div>Versão: {jogo.versao}</div>
                  <div>Data: {new Date(jogo.dataCriacao).toLocaleDateString("pt-BR")}</div>
                </div>
              }
              icon={carimbo}
              onClick={() => handleCardClick(jogo)}
            />
            {hoveredIndex === index && (
              <div className="carimbo-card-buttons">
                <button className="carimbo-btn-editar" disabled>Editar</button>
                <button className="carimbo-btn-excluir" disabled>Excluir</button>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default Carimbo;