import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
//import { exchangeCodeForToken } from "../services/authServices";

const Callback = () => {
  const navigate = useNavigate();

  useEffect(() => {
    const getToken = async () => {
      const urlParams = new 
      (window.location.search);
      const code = urlParams.get("code");

      if (code) {
        try {
          //const token = await exchangeCodeForToken(code);
          localStorage.setItem("token", "mocked_token_123");
          navigate("/home");
        } catch (error) {
          alert(`Erro ao realizar login: ${error}.`);
        }
      }
    };

    getToken();
  }, [navigate]);

  return <p>Processando login...</p>;
};

export default Callback;
