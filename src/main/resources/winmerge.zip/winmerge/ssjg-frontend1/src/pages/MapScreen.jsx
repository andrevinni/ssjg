import { useNavigate, useParams } from "react-router-dom";
import { useCenario } from "../hooks/useCenario";
import { MapGame } from "../components/MapGame/MapGame";

const MapScreen = () => {
  const { jogoId, cenarioId } = useParams();
  const navigate = useNavigate();
  const { cenario, loading, error } = useCenario(jogoId, cenarioId);

  if (loading) {
    return <div style={{ padding: "2rem", color: "#fff" }}>Carregando cenário...</div>;
  }

  if (error || !cenario) {
    return (
      <div style={{ padding: "2rem" }}>
        <p>{error ?? "Cenário não encontrado!"}</p>
        <button onClick={() => navigate("/carimbo")}>Voltar</button>
      </div>
    );
  }

  return <MapGame cenario={cenario} />;
};

export default MapScreen;