import { useEffect, useState } from "react";
import { toLonLat } from "ol/proj";
import { decimalToDMS, formatDMS } from "../utils/decimalToDms";

/**
 * Hook que escuta o movimento do mouse no mapa OpenLayers
 * e retorna as coordenadas formatadas em DMS.
 *
 * @param {import("ol/Map").default|null} map - instância do mapa OL
 * @returns {{ lat: string, lon: string }|null}
 */
export function useMouseCoords(map) {
  const [coords, setCoords] = useState(null);

  useEffect(() => {
    if (!map) return;

    const handler = (evt) => {
      const [lon, lat] = toLonLat(evt.coordinate);
      setCoords({
        lat: formatDMS(decimalToDMS(lat, true)),
        lon: formatDMS(decimalToDMS(lon, false)),
      });
    };

    map.on("pointermove", handler);
    return () => map.un("pointermove", handler);
  }, [map]);

  return coords;
}