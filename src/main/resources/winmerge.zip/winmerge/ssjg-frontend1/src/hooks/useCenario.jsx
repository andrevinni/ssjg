import { useEffect, useState } from "react";
import { fetchCenario } from "../api/gameApi";

/**
 * Busca o cenário pelo jogoId e cenarioId.
 * @param {string} jogoId
 * @param {string} cenarioId
 * @returns {{ cenario: object|null, loading: boolean, error: string|null }}
 */
export function useCenario(jogoId, cenarioId) {
  const [cenario, setCenario] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!jogoId || !cenarioId) {
      setError("IDs não informados.");
      setLoading(false);
      return;
    }

    async function load() {
      try {
        const data = await fetchCenario(jogoId, cenarioId);
        setCenario(data);
      } catch (err) {
        console.error(err);
        setError(err.message);
      } finally {
        setLoading(false);
      }
    }

    load();
  }, [jogoId, cenarioId]);

  return { cenario, loading, error };
}