/**
 * Hook que extrai as bases do objeto jogo recebido via navigation state.
 * O jogo já vem completo do MapScreen — não precisa buscar na API de novo.
 *
 * @param {{ cenario: { bases: Array } }} jogo
 * @returns {{ bases: Array, error: string|null }}
 */
export function useBases(jogo) {
  if (!jogo) {
    return { bases: [], error: "Jogo não encontrado." };
  }

  const bases = jogo?.cenario?.bases ?? [];

  if (!bases.length) {
    return { bases: [], error: "Nenhuma base encontrada no cenário." };
  }

  return { bases, error: null };
}