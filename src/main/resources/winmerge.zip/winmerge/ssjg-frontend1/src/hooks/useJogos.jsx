import { useEffect, useState } from "react";
import { fetchJogos } from "../api/gameApi";

/**
 * Busca a lista de jogos do backend.
 * GET /jogos → { jogos: [{ id, nome, versao, dataCriacao, cenarios }] }
 * @returns {{ jogos: Array, loading: boolean, error: string|null, refetch: Function }}
 */
export function useJogos() {
  const [jogos, setJogos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  async function load() {
    setLoading(true);
    try {
      const data = await fetchJogos();
      setJogos(data);
    } catch (err) {
      console.error(err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  // refetch permite recarregar a lista após criar um novo jogo
  return { jogos, loading, error, refetch: load };
}