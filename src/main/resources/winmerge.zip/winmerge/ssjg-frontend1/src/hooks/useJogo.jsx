import { useEffect, useState } from "react";
import { fetchCenarios } from "../api/gameApi";

/**
 * Hook que busca o jogo completo pelo ID na API.
 * Usado pelo MapScreen para carregar o jogo antes de abrir o mapa.
 *
 * @param {number|string} jogoId
 * @returns {{ jogo: object|null, loading: boolean, error: string|null }}
 */
export function useJogo(jogoId) {
  const [jogo, setJogo] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    
    
    if (!jogoId) {
      setError("ID do jogo não informado.");
      setLoading(false);
      return;
    }

    async function load() {
      try {
        const data = await fetchCenarios(jogoId);
        setJogo(data);
      } catch (err) {
        console.error(err);
        setError(err.message);
      } finally {
        setLoading(false);
      }
    }

    load();
  }, [jogoId]);

  return { jogo, loading, error };
}