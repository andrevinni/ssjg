// ***********************************************
// This example commands.js shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
//
//
// -- This is a parent command --
// Cypress.Commands.add('login', (email, password) => { ... })
//
//
// -- This is a child command --
// Cypress.Commands.add('drag', { prevSubject: 'element'}, (subject, options) => { ... })
//
//
// -- This is a dual command --
// Cypress.Commands.add('dismiss', { prevSubject: 'optional'}, (subject, options) => { ... })
//
//
// -- This will overwrite an existing command --
// Cypress.Commands.overwrite('visit', (originalFn, url, options) => { ... })

// cypress/support/commands.js

/**
 * Injeta o token de autenticação no localStorage/sessionStorage
 * Baseado no helper auth.js do Playwright
 */
Cypress.Commands.add('injectToken', () => {
  // Opção 1: Se você tem um token fixo para testes
  const token = Cypress.env('VITE_APP_TEST_TOKEN') || 'eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJ3Vm9JYU5wMTRnTjFEa1FZUzROYkpJOVkwaDF1RzVMS0VqN19laGRsLTc4In0.eyJleHAiOjE3NzczOTY4MTQsImlhdCI6MTc3NzM5MzIxNSwiYXV0aF90aW1lIjoxNzc3MzkzMjE0LCJqdGkiOiI1NmRlYmE4Mi00YTIwLTRjNGUtODA0MC04YTUwYWFlM2EwYWQiLCJpc3MiOiJodHRwczovL3Nzby5zY29yZS5jdGltLm1iOjkwMDAvcmVhbG1zL3Njb3JlMi1kZXYiLCJhdWQiOlsiYXBwLXByb3h5IiwiYWNjb3VudCIsImFwcC1zY29yZSJdLCJzdWIiOiJlYWM0YmEwYi0zOGRiLTQzOTktOWI2YS0yMmM2MmJjZTVhY2UiLCJ0eXAiOiJCZWFyZXIiLCJhenAiOiJhcHAtc3NqZyIsInNlc3Npb25fc3RhdGUiOiIyZmNmOGVhNS04ZmFhLTQ0NTUtYjUxZi02YWQwM2QzNmNiZDUiLCJhY3IiOiIxIiwiYWxsb3dlZC1vcmlnaW5zIjpbIioiXSwicmVhbG1fYWNjZXNzIjp7InJvbGVzIjpbImRlZmF1bHQtcm9sZXMtc2NvcmUyLWRldiIsIm9mZmxpbmVfYWNjZXNzIiwidW1hX2F1dGhvcml6YXRpb24iLCJzY29yZTItYXBpLWdlcmFsIl19LCJyZXNvdXJjZV9hY2Nlc3MiOnsiYXBwLXByb3h5Ijp7InJvbGVzIjpbImNvbXVuaWNhY2FvIiwiYXJtYXplbmFtZW50byIsInBhZHJhbyIsInZpZGVvIl19LCJhY2NvdW50Ijp7InJvbGVzIjpbIm1hbmFnZS1hY2NvdW50IiwibWFuYWdlLWFjY291bnQtbGlua3MiLCJ2aWV3LXByb2ZpbGUiXX0sImFwcC1zY29yZSI6eyJyb2xlcyI6WyJ1c3VhcmlvIl19fSwic2NvcGUiOiJvcGVuaWQgZW1haWwgcHJvZmlsZSIsInNpZCI6IjJmY2Y4ZWE1LThmYWEtNDQ1NS1iNTFmLTZhZDAzZDM2Y2JkNSIsImVtYWlsX3ZlcmlmaWVkIjpmYWxzZSwibmFtZSI6IlJPQkVSVEEgQ0FTVFJPIFJPQkVSVEEgQ0FTVFJPIiwicHJlZmVycmVkX3VzZXJuYW1lIjoiMDc5MzUzNzc3MDciLCJnaXZlbl9uYW1lIjoiUk9CRVJUQSBDQVNUUk8iLCJmYW1pbHlfbmFtZSI6IlJPQkVSVEEgQ0FTVFJPIiwiZW1haWwiOiIwNzkzNTM3NzcwN0BzY29yZS5tYiJ9.ea0vGI-mhr4K5tRLFATQju5OABayUQGcGhMIzbkCchnGiD84CtAjDzMhsJLnuHN4KTEW6mCg-HG939nciWSWZOgII1sjjnvKlpL_iuTOQX7cXt0A-HlHTJKrq4pPW_3IFfSNsfFpzEbWwUwxHRF3YPRndkCbODdzxVq0rveP5y3z-3_rYBPHqk-PzrBPw3-eMf-9cU90Rkp5f1qAWREgOFSUf2Z4_k2-5HZmJ83vJdgCNvamjCCE89QrKGn15T47Eyb_8iUVyibpOmOmg3nx-4Ay7-w8piep51nqNN77AVkC-UH39izZ95MBeW6dcv9UVwA51PgGirAfKJRXgRK9Gw'
  
  // Armazena no localStorage (ou sessionStorage, dependendo da sua app)
  window.localStorage.setItem('access_token', token)
  window.localStorage.setItem('auth_token', token)
  
  // Se sua app usa sessionStorage
  window.sessionStorage.setItem('token', token)
  window.sessionStorage.setItem('auth_token', token)
  
  // Se usa cookies (comum em apps com SSO)
  cy.setCookie('auth_token', token, { 
    path: '/',
    domain: 'localhost',
    secure: false,
    httpOnly: false
  })
  
  cy.log('✅ Token injetado com sucesso')
})

/**
 * Versão mais completa - faz login via API primeiro
 */
Cypress.Commands.add('loginViaApi', () => {
  const cpf = Cypress.env('VITE_APP_TEST_CPF')
  const senha = Cypress.env('VITE_APP_TEST_PASSWORD')
  
  if (!cpf || !senha) {
    throw new Error('❌ Credenciais não encontradas no cypress.env.json')
  }
  
  cy.request({
    method: 'POST',
    url: 'http://localhost:8081/auth/login', // Ajuste para URL real da sua API
    body: {
      cpf: cpf,
      password: senha,
      tipoId: '3' // CPF
    },
    failOnStatusCode: false
  }).then((response) => {
    if (response.status === 200 && response.body.token) {
      // Armazena o token recebido
      const token = response.body.token
      window.localStorage.setItem('token', token)
      window.localStorage.setItem('auth_token', token)
      window.sessionStorage.setItem('token', token)
      cy.setCookie('auth_token', token)
      cy.log('✅ Login via API realizado com sucesso')
    } else {
      cy.log('❌ Falha no login via API, tentando injetar token mock')
      // Fallback para token mock
      const mockToken = 'mock-token-para-testes-' + Date.now()
      window.localStorage.setItem('token', mockToken)
      window.sessionStorage.setItem('token', mockToken)
    }
  })
})

/**
 * Versão que simula o retorno da função injectToken do Playwright
 * Baseado no arquivo helpers/auth.js que você mencionou
 */
Cypress.Commands.add('injectTokenFromFile', () => {
  // Se você tem um arquivo de helpers como no Playwright
  cy.fixture('auth-token.json').then((authData) => {
    const token = authData.token || authData.access_token
    
    window.localStorage.setItem('token', token)
    window.sessionStorage.setItem('token', token)
    cy.setCookie('auth_token', token)
    
    cy.log('✅ Token injetado a partir do fixture')
  })
})

/**
 * Limpa token (útil entre testes)
 */
Cypress.Commands.add('clearToken', () => {
  window.localStorage.removeItem('token')
  window.localStorage.removeItem('auth_token')
  window.sessionStorage.removeItem('token')
  window.sessionStorage.removeItem('auth_token')
  cy.clearCookie('auth_token')
  cy.clearCookie('token')
  cy.log('🗑️ Token removido')
})