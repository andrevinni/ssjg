// cypress/support/commands.js

// Comando customizado para login via API
Cypress.Commands.add('loginViaApi', (username, password) => {
  const API_AUTH_URL = Cypress.env('VITE_APP_OAUTH2_URL')
  
  cy.request({
    method: 'POST',
    url: API_AUTH_URL,
    form: true,
    body: {
      username: username,
      password: password,
      grant_type: 'password',
      client_id: 'app-ssjg',
    }
  }).then((response) => {
    expect(response.status).to.eq(200)
    
    const { access_token, refresh_token, expires_in } = response.body
    
    cy.visit('/')
    
    cy.window().then((win) => {
      win.localStorage.setItem('access_token', access_token)
      win.localStorage.setItem('refresh_token', refresh_token)
      win.localStorage.setItem('token_expires_at', (Date.now() + (expires_in * 1000)).toString())
    })
    
    cy.log('✅ Login via API realizado')
  })
})

// Comando para login com token mockado (sem chamar API)
Cypress.Commands.add('loginMockado', () => {
  const mockToken = {
    access_token: 'eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJ...',
    refresh_token: 'mock-refresh-token',
    token_expires_at: Date.now() + (5 * 60 * 1000)
  }
  
  cy.visit('/')
  
  cy.window().then((win) => {
    win.localStorage.setItem('access_token', mockToken.access_token)
    win.localStorage.setItem('refresh_token', mockToken.refresh_token)
    win.localStorage.setItem('token_expires_at', mockToken.token_expires_at.toString())
    
    win.localStorage.setItem('user_profile', JSON.stringify({
      name: 'Usuário Mockado',
      email: 'mock@teste.com',
      roles: ['ADMIN']
    }))
  })
  
  cy.log('✅ Login mockado realizado')
})