// cypress/e2e/login-completo.cy.js
describe('Login com CPF usando .env', () => {
  const cpf = Cypress.env('VITE_APP_TEST_CPF')
  const senha = Cypress.env('VITE_APP_TEST_PASSWORD')
  
  beforeEach(() => {
    cy.injectToken()
  })

  it('login com CPF usando .env', () => {
    cy.log(`🔐 Testando login com CPF: ${cpf}`)
    
    // 1. Visita seu app
    cy.visit('http://localhost:5173')
    
    // 2. Clica no botão "Autenticar" do SEU app
    cy.log('📌 Clicando no botão Autenticar do app...')
    cy.contains('button', 'Autenticar').click()
    
    // 3. Aguarda o redirecionamento para o SSO (domínio externo)
    cy.log('📌 Aguardando redirecionamento para SSO...')
    cy.url({ timeout: 1000 }).should('include', 'sso.score.ctim.mb:9000')
    
    // 4. Usa cy.origin para interagir com o domínio do SSO
    cy.log('📌 Interagindo com formulário do SSO...')
    cy.origin('https://sso.score.ctim.mb:9000', { args: { cpf, senha } }, ({ cpf, senha }) => {
      // Este código executa DENTRO do domínio do SSO
      
      // Aguarda o formulário carregar
      //cy.get('#identificacao', { timeout: 10000 }).should('be.visible')
      
      // Seleciona CPF
      cy.get('#cdTipoId').select('3')
      
      // Preenche CPF
      cy.get('#nmId').type(cpf)
      
      // Preenche senha
      cy.get('#password').type(senha)
      
      // Clica em Entrar
      cy.get('#kc-login').click()
    })
    
    // 5. Aguarda o redirecionamento de volta para seu app
    cy.log('📌 Aguardando redirecionamento para o app...')
    cy.url({ timeout: 2000 }).should('include', 'localhost:5173')
    cy.url().should('include', '/home')
    
    cy.log('✅ Login completo realizado com sucesso!')
  })
})