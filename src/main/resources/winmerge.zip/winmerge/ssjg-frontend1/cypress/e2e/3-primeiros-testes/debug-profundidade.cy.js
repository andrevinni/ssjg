// cypress/e2e/debug-profundidade.cy.js
describe('Debug Profundo - SSO', () => {
  const cpf = Cypress.env('VITE_APP_TEST_CPF')
  const senha = Cypress.env('VITE_APP_TEST_PASSWORD')
  
  it('inspeciona completamente a página do SSO', () => {
    cy.visit('http://localhost:5173')
    cy.contains('button', 'Autenticar').click()
    cy.url().should('include', 'sso.score.ctim.mb:9000')
    cy.wait(3000)
    
    // 1. Verifica se está dentro de um iframe
    cy.get('iframe').then($iframes => {
      cy.log(`🔍 Encontrados ${$iframes.length} iframes na página`)
      if ($iframes.length > 0) {
        cy.log('⚠️ ESTAMOS DENTRO DE UM IFRAME!')
        $iframes.each((i, iframe) => {
          cy.log(`Iframe ${i}: id="${iframe.id}", src="${iframe.src}"`)
        })
      } else {
        cy.log('✅ Nenhum iframe encontrado')
      }
    })
    
    // 2. Verifica Shadow DOM
    cy.get('body').then($body => {
      const shadowHosts = $body.find('*').filter((i, el) => el.shadowRoot)
      cy.log(`🔍 Shadow hosts encontrados: ${shadowHosts.length}`)
    })
    
    // 3. Tenta encontrar os elementos de diferentes formas
    cy.log('📌 Tentando encontrar #cdTipoId...')
    cy.get('#cdTipoId', { timeout: 5000 }).then($el => {
      if ($el.length) {
        cy.log(`✅ #cdTipoId encontrado! Visível: ${$el.is(':visible')}`)
        cy.log(`   Tag: ${$el.prop('tagName')}`)
      } else {
        cy.log('❌ #cdTipoId NÃO encontrado diretamente')
      }
    })
    
    // 4. Procura por qualquer select na página
    cy.get('select').then($selects => {
      cy.log(`🔍 Total de selects na página: ${$selects.length}`)
      $selects.each((i, select) => {
        cy.log(`Select ${i}: id="${select.id}", name="${select.name}"`)
      })
    })
    
    // 5. Procura por qualquer input
    cy.get('input').then($inputs => {
      cy.log(`🔍 Total de inputs na página: ${$inputs.length}`)
      $inputs.each((i, input) => {
        cy.log(`Input ${i}: id="${input.id}", name="${input.name}", type="${input.type}"`)
      })
    })
    
    // 6. Tenta encontrar pelo texto do label
    cy.contains('label', 'CPF').then($label => {
      if ($label.length) {
        cy.log('✅ Label "CPF" encontrado!')
        const forAttr = $label.attr('for')
        cy.log(`   Label aponta para: ${forAttr}`)
      }
    })
    
    // 7. Tira screenshot
    cy.screenshot('pagina-sso-debug')
  })
})