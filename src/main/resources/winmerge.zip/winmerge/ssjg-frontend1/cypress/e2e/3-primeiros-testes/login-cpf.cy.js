// tests/e2e/login-cpf-env.spec.js
describe('Login com CPF usando .env', () => {
  // Configura timeout global maior para todos os testes
  const TIMEOUT = 120000 // 2 minutos
  
  // Função auxiliar para pausa (mais legível)
  const aguardar = (ms) => cy.wait(ms)
  
  beforeEach(() => {
    // Adiciona slow motion para este teste específico
    Cypress.config('defaultCommandTimeout', 60000)
  })
  
  it('login com CPF usando .env', () => {
    // Pega as variáveis do .env
    const cpf = Cypress.env('VITE_APP_TEST_CPF')
    const senha = Cypress.env('VITE_APP_TEST_PASSWORD')
    
    // Verifica se as variáveis existem
    if (!cpf || !senha) {
      throw new Error(`
        ❌ Variáveis não encontradas!
        Verifique se o arquivo cypress.env.json existe e contém:
        {
          "VITE_APP_TEST_CPF": "seu-cpf-aqui",
          "VITE_APP_TEST_PASSWORD": "sua-senha-aqui"
        }
      `)
    }
    
    cy.log(`🔐 Testando login com CPF: ${cpf}`)
    
    cy.visit('http://localhost:5173')
    aguardar(2000) // Pausa de 2 segundos após navegar
    
    cy.url().should('include', '/sso/', { timeout: 10000 })
    aguardar(1500) // Pausa para garantir carregamento do formulário
    
    // Seleciona CPF (valor '3' no select)
    cy.get('select[name="cdTipoId"]').select('3')
    aguardar(500)
    
    // Preenche usando as variáveis do .env
    cy.get('input[name="nmId"]').type(cpf)
    aguardar(500)
    
    cy.get('input[name="password"]').type(senha)
    aguardar(500)
    
    cy.get('#kc-login').click()
    aguardar(3000) // Pausa maior após clique para garantir processamento
    
    cy.url().should('include', '/home', { timeout: 15000 })
    aguardar(2000) // Pausa final para ver resultado
    
    cy.url().should('eq', 'http://localhost:5173/home')
    cy.log('✅ Login com CPF realizado com sucesso!')
  })
})

// ─── Fixtures ──────────────────────────────────────────────────────────────────

/**
 * Cenário sem bases — ideal para testar o mapa sem dependência de
 * makeSymbolCanvas / milsymbol.
 */
const MOCK_CENARIO_VAZIO = {
  id: 10,
  nome: 'Cenário Alpha',
  bases: [],
};

/**
 * Cenário com UMA base posicionada exatamente no centro inicial da View
 * do MapGame [-43.1729, -22.9068]. Em teoria, com zoom 5, o pixel da feature
 * fica muito próximo do centro geométrico do container do mapa.
 *
 * ⚠️  O tooltip só aparecerá se makeSymbolCanvas() conseguir criar o canvas
 *     (requer milsymbol disponível no bundle). Veja o describe "Tooltip" abaixo.
 */
const MOCK_CENARIO_COM_BASE = {
  id: 10,
  nome: 'Cenário Alpha',
  bases: [
    {
      nome: 'Base Alfa',
      tipo: 'TERRESTRE',
      partido: 'AZUL',
      coordenadas: { decimal: { latitude: -22.9068, longitude: -43.1729 } },
      simbolo: { sidcExtendido: 'SFGPUCI---**---' },
    },
    {
      nome: 'Base Beta',
      tipo: 'NAVAL',
      partido: 'VERMELHO',
      coordenadas: { decimal: { latitude: -22.95, longitude: -43.2 } },
      simbolo: { sidcExtendido: 'SHGPUCI---**---' },
    },
  ],
};

// ─── Mock helpers ──────────────────────────────────────────────────────────────

const mockCenario = (cenario = MOCK_CENARIO_VAZIO, jogoId = 1, cenarioId = 10) => {
  // URL exata que seu frontend está chamando
  const url = `http://10.5.112.125:8081/jogos/${jogoId}/cenarios/${cenarioId}`;
  
  cy.intercept('GET', url, {
    statusCode: 200,
    body: { cenario }
  }).as('mockCenario');
};

const mockCenarioFlexivel = (cenario = MOCK_CENARIO_VAZIO) => {
  // Intercepta qualquer requisição que contenha '/jogos/*/cenarios/*'
  cy.intercept('GET', /\/jogos\/\d+\/cenarios\/\d+$/, {
    statusCode: 200,
    body: { cenario }
  }).as('mockCenarioFlexivel');
};

const mockCenarioErro = () => {
  cy.intercept('GET', '**/jogos/*/cenarios/*', (req) => {
    cy.wait(500)
    req.reply({ statusCode: 500, body: 'Internal Server Error' })
  }).as('mockCenarioErro');
};

/** Para não travar o Carimbo quando navegamos de volta */
const mockJogosVazio = () => {
  cy.intercept('GET', '**/jogos', (req) => {
    if (req.method !== 'GET') return;
    cy.wait(300)
    req.reply({
      statusCode: 200,
      body: { jogos: [] }
    })
  }).as('mockJogosVazio');
};

/**
 * Intercepta todos os tiles do OSM e devolve um PNG 1×1 transparente.
 * Evita erros de CORS ao rodar o Cypress contra localhost.
 */
const TILE_PNG_B64 =
  'iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAIAAADTED8xAAACwUlEQVR4nO3TMQ0AMAzAsPLHMxC7h2gwesSSAeTJnPsga9YLYJEBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5BmANIMQJoBSDMAaQYgzQCkGYA0A5D2AVNsIpO/z/xGAAAAAElFTkSuQmCC';

const mockOsmTiles = () => {
  cy.intercept('GET', 'https://tile.openstreetmap.org/**', {
    statusCode: 200,
    headers: { 'content-type': 'image/png' },
    body: Cypress.Buffer.from(TILE_PNG_B64, 'base64')
  }).as('mockTiles');
};

/**
 * Utilitário: move o mouse varrendo pixels ao redor de (cx, cy)
 * até o elemento ficar visível, ou esgota a lista de offsets.
 */
async function scanUntilVisible(selector, cx, cy, offsets) {
  for (const [dx, dy] of offsets) {
    cy.get('body').trigger('mousemove', cx + dx, cy + dy);
    cy.wait(300); // Pausa entre movimentos
    
    // Verifica se o elemento ficou visível
    const $el = Cypress.$(selector);
    if ($el.is(':visible')) return true;
  }
  return false;
}

// ─── Suite 1: estados de carregamento e erro ──────────────────────────────────

describe('MapScreen — loading e erro', () => {
  beforeEach(() => {
    cy.injectToken(); // Assumindo que você tem um custom command para isso
  });

  it('exibe loading enquanto aguarda resposta do cenário', () => {
    cy.intercept('GET', '**/jogos/1/cenarios/10', (req) => {
      cy.wait(1500);
      req.reply({
        statusCode: 200,
        body: { cenario: MOCK_CENARIO_VAZIO }
      });
    }).as('slowCenario');
    
    mockOsmTiles();
    cy.visit('/carimbo/mapa/1/10');
    cy.wait(500);
    cy.contains('Carregando cenário...').should('be.visible');
  });

  it('exibe mensagem de erro e botão Voltar quando API falha', () => {
    mockCenarioErro();
    mockOsmTiles();
    cy.visit('/carimbo/mapa/1/10');
    cy.wait(1000);
    cy.contains('button', 'Voltar').should('be.visible');
  });

  it('botão Voltar no estado de erro navega para /carimbo', () => {
    mockCenarioErro();
    mockJogosVazio();
    cy.visit('/carimbo/mapa/1/10');
    cy.wait(1000);
    cy.contains('button', 'Voltar').click();
    cy.wait(1000);
    cy.url().should('eq', Cypress.config().baseUrl + '/carimbo');
  });

  it('acesso sem token redireciona para /', () => {
    // Sem injectToken
    cy.visit('/carimbo/mapa/1/10');
    cy.wait(1000);
    cy.url().should('eq', Cypress.config().baseUrl + '/');
  });
});

// ─── Suite 2: renderização do mapa ───────────────────────────────────────────

describe('MapScreen — renderização do mapa', () => {
  beforeEach(() => {
    cy.injectToken();
    mockCenarioFlexivel(MOCK_CENARIO_VAZIO);
    mockOsmTiles();
    cy.visit('/carimbo/mapa/1/10');
  });

  it('container do mapa é visível após carregamento', () => {
    cy.wait(1000);
    cy.get('.map-container').should('be.visible');
  });

  it('botão Voltar (⬅) está visível no mapa', () => {
    cy.wait(500);
    cy.get('.back-btn').should('be.visible');
  });

  it('botão Voltar navega para /carimbo', () => {
    mockJogosVazio();
    cy.wait(500);
    cy.get('.back-btn').click();
    cy.wait(1000);
    cy.url().should('include', '/carimbo');
  });

  it('botão de filtro de partido está visível', () => {
    cy.wait(500);
    cy.get('.filter-toggle').should('be.visible');
  });
});

// ─── Suite 3: FilterPartido ───────────────────────────────────────────────────

describe('MapScreen — FilterPartido', () => {
  beforeEach(() => {
    cy.injectToken();
    mockCenarioFlexivel(MOCK_CENARIO_VAZIO);
    mockOsmTiles();
    cy.visit('/carimbo/mapa/1/10');
  });

  it('clicar no toggle abre o dropdown com todas as opções', () => {
    cy.get('.filter-toggle').click();
    cy.wait(500);
    cy.get('.filter-dropdown').should('be.visible');

    const opcoes = ['Todos', 'Azul', 'Vermelho', 'Verde'];
    opcoes.forEach(label => {
      cy.contains('.filter-btn', label).should('be.visible');
    });
  });

  it('"Todos" está marcado como active por padrão', () => {
    cy.get('.filter-toggle').click();
    cy.wait(300);
    cy.contains('.filter-btn', 'Todos').should('have.class', 'active');
  });

  it('clicar em "Azul" fecha o dropdown e exibe indicador colorido', () => {
    cy.get('.filter-toggle').click();
    cy.wait(300);
    cy.contains('.filter-btn', 'Azul').click();
    cy.wait(500);

    cy.get('.filter-dropdown').should('not.be.visible');
    cy.get('.filter-indicator').should('be.visible');
  });

  it('indicador colorido não é exibido quando filtro é "Todos"', () => {
    // Ativa um filtro primeiro
    cy.get('.filter-toggle').click();
    cy.wait(300);
    cy.contains('.filter-btn', 'Azul').click();
    cy.wait(500);
    cy.get('.filter-indicator').should('be.visible');

    // Volta para Todos
    cy.get('.filter-toggle').click();
    cy.wait(300);
    cy.contains('.filter-btn', 'Todos').click();
    cy.wait(500);
    cy.get('.filter-indicator').should('not.be.visible');
  });

  it('selecionar "Vermelho" marca o botão como active', () => {
    cy.get('.filter-toggle').click();
    cy.wait(300);
    cy.contains('.filter-btn', 'Vermelho').click();
    cy.wait(500);

    // Reabre para verificar o active
    cy.get('.filter-toggle').click();
    cy.wait(300);
    cy.contains('.filter-btn', 'Vermelho').should('have.class', 'active');
    cy.contains('.filter-btn', 'Todos').should('not.have.class', 'active');
  });

  it('clicar novamente no toggle fecha o dropdown', () => {
    cy.get('.filter-toggle').click();
    cy.wait(300);
    cy.get('.filter-dropdown').should('be.visible');

    cy.get('.filter-toggle').click();
    cy.wait(300);
    cy.get('.filter-dropdown').should('not.be.visible');
  });
});

// ─── Suite 4: CoordDisplay ───────────────────────────────────────────────────

describe('MapScreen — CoordDisplay', () => {
  beforeEach(() => {
    cy.injectToken();
    mockCenarioFlexivel(MOCK_CENARIO_VAZIO);
    mockOsmTiles();
    cy.visit('/carimbo/mapa/1/10');
  });

  it('CoordDisplay não está visível antes de qualquer movimento do mouse', () => {
    cy.wait(500);
    cy.get('.coord-display').should('not.be.visible');
  });

  it('CoordDisplay aparece ao mover o mouse sobre o mapa', () => {
    cy.get('.map-container').then($container => {
      const rect = $container[0].getBoundingClientRect();
      const x = rect.left + rect.width / 2;
      const y = rect.top + rect.height / 2;
      
      cy.get('body').trigger('mousemove', x, y);
      cy.wait(500);
      
      cy.get('.coord-display', { timeout: 5000 }).should('be.visible');
      cy.get('.coord-label').contains('LAT').should('be.visible');
      cy.get('.coord-label').contains('LON').should('be.visible');
    });
  });

  it('coordenadas exibidas mudam ao mover o mouse lateralmente', () => {
    cy.get('.map-container').then($container => {
      const rect = $container[0].getBoundingClientRect();
      const cx = rect.left + rect.width / 2;
      const cy = rect.top + rect.height / 2;
      
      cy.get('body').trigger('mousemove', cx, cy);
      cy.wait(500);
      cy.get('.coord-display', { timeout: 5000 }).should('be.visible');
      
      cy.get('.coord-block').eq(1).find('.coord-value').invoke('text').then(lon1 => {
        cy.get('body').trigger('mousemove', cx + 80, cy);
        cy.wait(500);
        cy.get('.coord-block').eq(1).find('.coord-value').invoke('text').should('not.eq', lon1);
      });
    });
  });
});

// ─── Suite 5: MapTooltip (hover sobre feature) ───────────────────────────────

/**
 * ⚠️  DEPENDÊNCIA DE CANVAS / MILSYMBOL
 *
 * O tooltip só é exibido se plotBases() adicionar a feature com sucesso, o que
 * exige que makeSymbolCanvas() retorne um HTMLCanvasElement válido.
 * Em ambientes headless isso depende do milsymbol e da disponibilidade de canvas.
 *
 * Se esses testes forem instáveis em CI, adicione:
 *   it.skip(process.env.CI === 'true', 'requer canvas/milsymbol')
 * ou mock de makeSymbolCanvas via cy.visit com onBeforeLoad.
 */
describe('MapScreen — MapTooltip', () => {
  // Offsets (dx, dy) a varrer ao redor do centro para encontrar a feature
  const SCAN_OFFSETS = [
    [0, 0], [-10, 0], [10, 0], [0, -10], [0, 10],
    [-20, 0], [20, 0], [0, -20], [0, 20],
    [-15, -15], [15, 15], [-15, 15], [15, -15],
  ];

  beforeEach(() => {
    cy.injectToken();
    mockCenarioFlexivel(MOCK_CENARIO_VAZIO);
    mockOsmTiles();
    cy.visit('/carimbo/mapa/1/10');
  });

  it('tooltip aparece ao passar o mouse sobre uma base no mapa', () => {
    cy.get('.map-container').then($container => {
      const rect = $container[0].getBoundingClientRect();
      const cx = rect.left + rect.width / 2;
      const cy = rect.top + rect.height / 2;
      
      // Varre os offsets
      let found = false;
      for (const [dx, dy] of SCAN_OFFSETS) {
        cy.get('body').trigger('mousemove', cx + dx, cy + dy);
        cy.wait(300);
        
        cy.get('body').then(() => {
          if (Cypress.$('.map-tooltip').is(':visible')) {
            found = true;
          }
        });
        
        if (found) break;
      }
      
      cy.get('.map-tooltip').should('be.visible');
    });
  });

  it('tooltip exibe nome, tipo e partido corretos da base', () => {
    cy.get('.map-container').then($container => {
      const rect = $container[0].getBoundingClientRect();
      const cx = rect.left + rect.width / 2;
      const cy = rect.top + rect.height / 2;
      
      // Move até encontrar o tooltip
      for (const [dx, dy] of SCAN_OFFSETS) {
        cy.get('body').trigger('mousemove', cx + dx, cy + dy);
        cy.wait(300);
        
        cy.get('body').then(() => {
          if (Cypress.$('.map-tooltip').is(':visible')) {
            cy.wait(500);
            cy.get('.tooltip-nome').should('contain', 'Base Alfa');
            cy.contains('.tooltip-row', 'TIPO')
              .find('.tooltip-value')
              .should('contain', 'TERRESTRE');
            cy.contains('.tooltip-row', 'PARTIDO')
              .find('.tooltip-value')
              .should('contain', 'AZUL');
          }
        });
      }
    });
  });

  it('tooltip exibe coordenadas em formato DMS', () => {
    cy.get('.map-container').then($container => {
      const rect = $container[0].getBoundingClientRect();
      const cx = rect.left + rect.width / 2;
      const cy = rect.top + rect.height / 2;
      
      for (const [dx, dy] of SCAN_OFFSETS) {
        cy.get('body').trigger('mousemove', cx + dx, cy + dy);
        cy.wait(300);
        
        cy.get('body').then(() => {
          if (Cypress.$('.map-tooltip').is(':visible')) {
            cy.wait(500);
            
            cy.contains('.map-tooltip .tooltip-row', 'LAT')
              .find('.tooltip-value')
              .invoke('text')
              .should('have.length.greaterThan', 0);
            
            cy.contains('.map-tooltip .tooltip-row', 'LON')
              .find('.tooltip-value')
              .invoke('text')
              .should('have.length.greaterThan', 0);
          }
        });
      }
    });
  });

  it('tooltip desaparece ao mover o mouse para área sem feature', () => {
    cy.get('.map-container').then($container => {
      const rect = $container[0].getBoundingClientRect();
      const cx = rect.left + rect.width / 2;
      const cy = rect.top + rect.height / 2;
      
      // Localiza a feature
      for (const [dx, dy] of SCAN_OFFSETS) {
        cy.get('body').trigger('mousemove', cx + dx, cy + dy);
        cy.wait(300);
        
        if (Cypress.$('.map-tooltip').is(':visible')) {
          cy.wait(500);
          cy.get('.map-tooltip').should('be.visible');
          
          // Move para o canto superior esquerdo — longe de qualquer feature
          cy.get('body').trigger('mousemove', rect.left + 15, rect.top + 15);
          cy.wait(1000);
          cy.get('.map-tooltip', { timeout: 3000 }).should('not.be.visible');
          break;
        }
      }
    });
  });

  it('cursor muda para "pointer" sobre feature e volta ao normal fora dela', () => {
    cy.get('.map-container').then($container => {
      const rect = $container[0].getBoundingClientRect();
      const cx = rect.left + rect.width / 2;
      const cy = rect.top + rect.height / 2;
      
      // Move sobre feature
      for (const [dx, dy] of SCAN_OFFSETS) {
        cy.get('body').trigger('mousemove', cx + dx, cy + dy);
        cy.wait(300);
        
        if (Cypress.$('.map-tooltip').is(':visible')) {
          cy.wait(500);
          cy.get('.map-container').should('have.css', 'cursor', 'pointer');
          break;
        }
      }
      
      // Move para área limpa
      cy.get('body').trigger('mousemove', rect.left + 15, rect.top + 15);
      cy.wait(500);
      cy.get('.map-container').should('have.css', 'cursor', 'auto');
    });
  });

  it('debug - verificar interceptação de tiles', () => {
    cy.intercept('GET', 'https://tile.openstreetmap.org/**', (req) => {
      cy.log(`🌍 Tile requisitado: ${req.url}`);
      req.reply({
        statusCode: 200,
        headers: { 'content-type': 'image/png' },
        body: Cypress.Buffer.from(TILE_PNG_B64, 'base64')
      });
    }).as('osmTile');
    
    cy.injectToken();
    cy.visit('/carimbo/mapa/1/10');
    
    cy.wait(5000);
    
    // Verifica interceptações
    cy.get('@osmTile.all').then(interceptions => {
      cy.log(`📊 Total de tiles requisitados: ${interceptions.length}`);
      if (interceptions.length === 0) {
        cy.log('⚠️ Nenhum tile foi requisitado - o mapa pode não estar tentando carregar tiles');
      } else {
        cy.log('✅ Tiles estão sendo requisitados e mockados');
      }
    });
  });

  it('debug - visualizar mapa renderizado', () => {
    cy.injectToken();
    mockCenario(MOCK_CENARIO_COM_BASE);
    mockOsmTiles();
    
    cy.visit('/carimbo/mapa/1/10');
    
    // Aguarda o canvas do mapa
    cy.get('.map-container canvas', { timeout: 10000 }).should('be.visible');
    
    // Aguarda um pouco para renderização completa
    cy.wait(3000);
    
    // Tira screenshot para ver o que está aparecendo
    cy.screenshot('mapa-estado-atual');
    
    // Verifica se o canvas tem conteúdo (não está preto/branco)
    cy.get('.map-container canvas').then($canvas => {
      const canvas = $canvas[0];
      const ctx = canvas.getContext('2d');
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      
      let hasContent = false;
      for (let i = 0; i < imageData.data.length; i += 4) {
        const r = imageData.data[i];
        const g = imageData.data[i+1];
        const b = imageData.data[i+2];
        
        // Se encontrar um pixel que não é branco (255,255,255) nem preto (0,0,0)
        if (!(r === 255 && g === 255 && b === 255) && !(r === 0 && g === 0 && b === 0)) {
          hasContent = true;
          break;
        }
      }
      
      cy.log('Canvas tem conteúdo?', hasContent);
    });
  });

  it('debug - plotBases nao esta plotando', () => {
    cy.injectToken();
    mockCenario(MOCK_CENARIO_COM_BASE);
    mockOsmTiles();
    
    cy.visit('/carimbo/mapa/1/10', {
      onBeforeLoad(win) {
        win.plotBasesCalls = [];
        const originalLog = win.console.log;
        win.console.log = (...args) => {
          if (args[0]?.includes('plotBases')) {
            win.plotBasesCalls.push(args);
          }
          originalLog.apply(win.console, args);
        };
      }
    });
    
    cy.wait(3000);
    
    // Verifica estado do componente
    cy.window().then(win => {
      cy.log('Bases no cenário:', JSON.stringify(win.cenario?.bases || [], null, 2));
      cy.log('Features no VectorSource:', win.vectorSourceRef?.current?.getFeatures().length || 0);
      cy.log('Chamadas do plotBases:', win.plotBasesCalls?.length || 0);
    });
    
    cy.screenshot('mapa-sem-bases');
  });

  it('debug - plotBases corrigido com URL correta', () => {
    cy.injectToken();
    
    // Usa o mock com a URL correta
    mockCenario(MOCK_CENARIO_COM_BASE);
    mockOsmTiles();
    
    cy.visit('/carimbo/mapa/1/10');
    cy.wait(3000);
    
    cy.window().then(win => {
      const cenario = win.cenario;
      cy.log('✅ Cenário carregado:', cenario ? `com ${cenario.bases?.length || 0} bases` : 'NÃO CARREGADO');
      
      if (cenario?.bases) {
        cy.log('Bases encontradas:', cenario.bases.map(b => b.nome).join(', '));
      }
      
      const features = win.vectorSourceRef?.current?.getFeatures().length || 0;
      cy.log('Features no VectorSource:', features);
      
      // Se ainda não tiver features, tenta forçar
      if (features === 0 && cenario?.bases?.length > 0) {
        cy.log('⚠️ Forçando plotBases manualmente...');
        if (win.plotBases && win.vectorSourceRef.current && win.cenario?.bases) {
          win.plotBases(win.vectorSourceRef.current, win.cenario.bases);
          if (win.map) win.map.render();
        }
        
        cy.wait(1000);
        const featuresAfter = win.vectorSourceRef?.current?.getFeatures().length || 0;
        cy.log('Features após força:', featuresAfter);
      }
    });
    
    cy.screenshot('mapa-com-bases-corrigido');
  });

  it('debug - verificar requisição do cenário', () => {
    cy.intercept('GET', '**/cenarios*', (req) => {
      cy.log('🔍 Requisição de cenário detectada:', req.url);
      req.continue();
    }).as('cenarioRequest');
    
    cy.injectToken();
    mockOsmTiles();
    cy.visit('/carimbo/mapa/1/10');
    
    cy.wait(3000);
    
    cy.window().then(win => {
      cy.log('Cenário carregado no frontend:', win.cenario);
    });
  });

  it('validar que o mock está funcionando', () => {
    cy.intercept('GET', '**/cenarios*', (req) => {
      cy.log('📡 Requisição interceptada:', req.url);
      req.reply({
        statusCode: 200,
        body: { cenario: MOCK_CENARIO_COM_BASE }
      });
    }).as('cenarioMock');
    
    cy.injectToken();
    mockOsmTiles();
    cy.visit('/carimbo/mapa/1/10');
    cy.wait(2000);
    
    cy.window().then(win => {
      const cenario = win.cenario;
      cy.log('Cenário no frontend:', cenario ? `✅ ${cenario.bases?.length} bases` : '❌ undefined');
      
      expect(cenario).to.exist;
      expect(cenario.bases.length).to.equal(2);
    });
  });

  it('comparar com navegador real', () => {
    cy.injectToken();
    
    cy.intercept('GET', '**/cenarios*', {
      statusCode: 200,
      body: { cenario: MOCK_CENARIO_COM_BASE }
    }).as('cenarioMock');
    
    mockOsmTiles();
    
    cy.visit('/carimbo/mapa/1/10');
    cy.wait(5000);
    
    cy.window().then(win => {
      const dados = {
        cenarioRecebido: !!win.cenario,
        qtdBases: win.cenario?.bases?.length || 0,
        vectorSourceFeatures: win.vectorSourceRef?.current?.getFeatures().length || 0,
        plotBasesExiste: typeof win.plotBases === 'function',
        mapaInicializado: !!win.map
      };
      
      cy.log('📊 Status no Cypress:', JSON.stringify(dados, null, 2));
      
      const nomesBases = win.cenario?.bases?.map(b => b.nome) || [];
      cy.log('🏷️ Bases que deveriam estar no mapa:', nomesBases);
    });
    
    cy.screenshot('cypress-mapa-sem-bases');
  });

  it('forçar plotBases manualmente', () => {
    cy.injectToken();
    
    cy.intercept('GET', '**/cenarios*', {
      statusCode: 200,
      body: { cenario: MOCK_CENARIO_COM_BASE }
    }).as('cenarioMock');
    
    mockOsmTiles();
    
    cy.visit('/carimbo/mapa/1/10');
    cy.wait(3000);
    
    // Verifica estado inicial
    cy.window().then(win => {
      let features = win.vectorSourceRef?.current?.getFeatures().length || 0;
      cy.log('Features antes:', features);
      
      // Força o plotBases
      try {
        const source = win.vectorSourceRef.current;
        const bases = win.cenario?.bases;
        
        if (!source) cy.log('❌ source nao encontrado');
        if (!bases) cy.log('❌ bases nao encontradas');
        if (typeof win.plotBases !== 'function') cy.log('❌ plotBases nao é funcao');
        
        cy.log('Chamando plotBases com', bases?.length, 'bases');
        win.plotBases(source, bases);
        win.map?.render();
        
        cy.wait(1000);
        features = win.vectorSourceRef?.current?.getFeatures().length || 0;
        cy.log('Features depois:', features);
      } catch (err) {
        cy.log('Erro:', err.message);
      }
    });
    
    cy.screenshot('cypress-bases-forcadas');
  });

  it('usar plotBases customizado', () => {
    cy.injectToken();
    
    cy.intercept('GET', '**/cenarios*', {
      statusCode: 200,
      body: { cenario: MOCK_CENARIO_COM_BASE }
    }).as('cenarioMock');
    
    mockOsmTiles();
    
    // Injeta uma versão customizada do plotBases
    cy.visit('/carimbo/mapa/1/10', {
      onBeforeLoad(win) {
        win.customPlotBases = (source, bases) => {
          if (!source || !bases) return;
          
          console.log('🎨 CustomPlotBases:', bases.length);
          
          bases.forEach(base => {
            const { latitude, longitude } = base.coordenadas.decimal;
            
            const feature = new win.ol.Feature({
              geometry: new win.ol.geom.Point(
                win.ol.proj.fromLonLat([longitude, latitude])
              ),
              nome: base.nome,
              tipo: base.tipo,
              partido: base.partido
            });
            
            feature.setStyle(new win.ol.style.Style({
              image: new win.ol.style.Circle({
                radius: 6,
                fill: new win.ol.style.Fill({ color: '#FF0000' }),
                stroke: new win.ol.style.Stroke({ color: '#FFFFFF', width: 2 })
              }),
              text: new win.ol.style.Text({
                text: base.nome,
                offsetY: -15,
                fill: new win.ol.style.Fill({ color: '#000000' }),
                stroke: new win.ol.style.Stroke({ color: '#FFFFFF', width: 2 }),
                font: '12px Arial'
              })
            }));
            
            source.addFeature(feature);
          });
        };
      }
    });
    
    cy.wait(3000);
    
    // Executa o plot customizado
    cy.window().then(win => {
      if (win.vectorSourceRef?.current && win.cenario?.bases) {
        win.customPlotBases(win.vectorSourceRef.current, win.cenario.bases);
        win.map?.render();
      }
    });
    
    cy.wait(1000);
    
    cy.window().then(win => {
      const features = win.vectorSourceRef?.current?.getFeatures().length || 0;
      cy.log('Features plotadas pelo custom:', features);
    });
    
    cy.screenshot('cypress-custom-bases');
  });
});