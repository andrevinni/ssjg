// cypress/e2e/mapa-teste.cy.js

describe('Testes do Mapa após login', () => {
  
  beforeEach(() => {
    // Login via API antes de cada teste
    cy.loginViaApi(
      Cypress.env('VITE_APP_TEST_USER'),
      Cypress.env('VITE_APP_TEST_PASSWORD')
    )
  })
  
  it('deve carregar o mapa corretamente', () => {
    cy.visit('/carimbo/mapa/1/10')
    cy.wait(2000)
    
    cy.get('.map-container').should('be.visible')
    cy.get('.map-container canvas').should('exist')
    
    cy.screenshot('mapa-carregado')
  })
  
  it('deve exibir o tooltip ao passar mouse sobre base', () => {
    cy.visit('/carimbo/mapa/1/10')
    cy.wait(3000)
    
    // Move o mouse sobre o centro do mapa (ajuste conforme necessário)
    cy.get('.map-container').trigger('mousemove', { clientX: 400, clientY: 300 })
    
    // Verifica se o tooltip aparece
    cy.get('.map-tooltip', { timeout: 5000 }).should('be.visible')
  })
})