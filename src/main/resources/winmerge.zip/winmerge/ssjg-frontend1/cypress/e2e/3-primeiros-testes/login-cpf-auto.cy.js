// cypress/e2e/login-completo.cy.js
describe('Login com CPF usando .env', () => {
  const cpf = Cypress.env('VITE_APP_TEST_CPF')
  const senha = Cypress.env('VITE_APP_TEST_PASSWORD')
  
  beforeEach(() => {
    cy.injectToken()
  })

  it('login com CPF usando .env', () => {
    cy.log(`🔐 Testando login com CPF: ${cpf}`)
    
    // Passo 1: Visita a página inicial
    cy.visit('http://localhost:5173')
    
    // Passo 2: Aguarda e clica no botão "Autenticar" (primeiro botão)
    cy.log('📌 Clicando no botão Autenticar inicial...')
    cy.contains('button', 'Autenticar', { timeout: 10000 }).should('be.visible').click()
    // Ou se o botão tiver um ID específico:
    // cy.get('#btn-autenticar').click()
    // cy.get('button[type="submit"]').first().click()
    
    // Passo 3: Aguarda o redirecionamento para SSO
    cy.log('📌 Aguardando redirecionamento para SSO...')
    cy.url({ timeout: 10000 }).should('include', '/sso/')
    
    // Passo 4: Aguarda o formulário de login carregar
    cy.log('📌 Aguardando formulário de login...')
    cy.get('#identificacao', { timeout: 10000 }).should('be.visible')
    
    // Passo 5: Seleciona CPF
    cy.log('📌 Selecionando tipo CPF...')
    cy.get('#cdTipoId').select('3')
    
    // Passo 6: Preenche CPF
    cy.log('📌 Preenchendo CPF...')
    cy.get('#nmId').should('be.visible').clear().type(cpf)
    
    // Passo 7: Preenche senha
    cy.log('📌 Preenchendo senha...')
    cy.get('#password').should('be.visible').clear().type(senha)
    
    // Passo 8: Clica no botão "Entrar"
    cy.log('📌 Clicando no botão Entrar...')
    cy.get('#kc-login').click()
    
    // Passo 9: Aguarda a home
    cy.log('📌 Aguardando redirecionamento para home...')
    cy.url({ timeout: 20000 }).should('include', '/home')
    
    cy.log('✅ Login com CPF realizado com sucesso!')
  })
})