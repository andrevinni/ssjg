// cypress/e2e/3-primeiros-testes/login-api-mock.cy.js

const API_AUTH_URL = 'https://sso.score.ctim.mb:9000/realms/score2-dev/protocol/openid-connect/token'

const TEST_USER = '07935377707'
const TEST_PASSWORD = 'M@rinha123!'
const CLIENT_ID = 'app-ssjg'
// 🔥 Você PRECISA do client_secret - pegue com o time de backend
const CLIENT_SECRET = 'mSHgJZG5NSI472axSmDs3KJTQnCPM6A9'  // 👈 Substitua pelo valor real

describe('Login via API', () => {
  
  it('deve fazer login com client_secret', () => {
    cy.request({
      method: 'POST',
      url: API_AUTH_URL,
      form: true,
      body: {
        username: TEST_USER,
        password: TEST_PASSWORD,
        grant_type: 'password',
        client_id: CLIENT_ID,
        client_secret: CLIENT_SECRET,  // 🔥 Adiciona o secret
      },
      failOnStatusCode: false
    }).then((response) => {
      cy.log(`Status: ${response.status}`)
      
      if (response.status !== 200) {
        cy.log(`❌ Erro: ${JSON.stringify(response.body)}`)
        throw new Error(`Auth failed: ${response.body?.error_description || response.body?.error}`)
      }
      
      const authData = response.body
      cy.log(`✅ Token obtido! Expira em: ${authData.expires_in} segundos`)
      
      // Injeta token no localStorage
      cy.visit('/')
      
      cy.window().then((win) => {
        win.localStorage.setItem('access_token', authData.access_token)
        win.localStorage.setItem('refresh_token', authData.refresh_token)
        cy.log('💾 Token salvo')
      })
      
      cy.visit('/home')
      cy.url().should('include', '/home')
      
      cy.log('✅ Login realizado!')
    })
  })
})