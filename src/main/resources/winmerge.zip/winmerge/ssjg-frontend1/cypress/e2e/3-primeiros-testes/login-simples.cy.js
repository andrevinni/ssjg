// cypress/e2e/login-simples.cy.js
describe('Login com CPF usando .env', () => {
  // ✅ Use Cypress.env() diretamente - É síncrono!
  const cpf = Cypress.env('VITE_APP_TEST_CPF')
  const senha = Cypress.env('VITE_APP_TEST_PASSWORD')
  
  before(() => {
    cy.log(`CPF carregado: ${cpf}`)
    cy.log(`Senha carregada: ${senha ? '✅' : '❌'}`)
    
    if (!cpf || !senha) {
      throw new Error('Variáveis não encontradas! Configure no cypress.config.js')
    }
  })

  it('login com CPF usando .env', () => {
    cy.log(`🔐 Testando login com CPF: ${cpf}`)
    
    cy.visit('http://localhost:5173')
    cy.wait(2000)
    
    cy.url().should('include', '/sso/', { timeout: 10000 })
    cy.wait(1500)
    
    cy.get('select[name="cdTipoId"]').select('3')
    cy.wait(500)
    
    cy.get('input[name="nmId"]').type(cpf)
    cy.wait(500)
    
    cy.get('input[name="password"]').type(senha)
    cy.wait(500)
    
    cy.get('#kc-login').click()
    cy.wait(3000)
    
    cy.url().should('include', '/home', { timeout: 15000 })
    cy.wait(2000)
    
    cy.log('✅ Login com CPF realizado com sucesso!')
  })
})