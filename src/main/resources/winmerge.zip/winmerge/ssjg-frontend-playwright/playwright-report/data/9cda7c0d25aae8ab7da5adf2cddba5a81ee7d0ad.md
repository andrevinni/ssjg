# Page snapshot

```yaml
- generic [ref=e3]:
  - generic [ref=e4]:
    - img "Logo Marinha" [ref=e5]
    - img "Logo Brasão" [ref=e6]
    - img "Logo SSJG" [ref=e7]
  - generic [ref=e8]:
    - generic [ref=e9]:
      - img [ref=e10]
      - heading "Sistema Simulador para Jogos de Guerra" [level=2] [ref=e11]
    - generic [ref=e12]:
      - generic [ref=e13]:
        - text: CPF
        - textbox "CPF" [ref=e14]:
          - /placeholder: 000.000.000-00
      - generic [ref=e15]:
        - text: Senha
        - textbox "Senha" [ref=e16]:
          - /placeholder: Digite sua senha
      - alert [ref=e17]: CPF ou senha inválidos.
      - button "Autenticar" [disabled] [ref=e18] [cursor=pointer]
      - paragraph [ref=e19]:
        - text: 🧪
        - strong [ref=e20]: Modo Mock
        - text: "— CPF:"
        - code [ref=e21]: 529.982.247-25
        - text: "/ Senha:"
        - code [ref=e22]: "123456"
```