import axios from "axios";
import { api, requestConfig, baseUrl, tratarErroAxios } from "./api";

const DEV_TOKEN = "eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJ3Vm9JYU5wMTRnTjFEa1FZUzROYkpJOVkwaDF1RzVMS0VqN19laGRsLTc4In0.eyJleHAiOjE3NzQyODM0MDYsImlhdCI6MTc3NDI3OTgwNiwianRpIjoiNjYzYTNkNzYtMGZiMi00NjQwLWExYjMtMmU5NGE5ODg2OGFjIiwiaXNzIjoiaHR0cHM6Ly9zc28uc2NvcmUuY3RpbS5tYjo5MDAwL3JlYWxtcy9zY29yZTItZGV2IiwiYXVkIjpbImFwcC1wcm94eSIsImFjY291bnQiLCJhcHAtc2NvcmUiXSwic3ViIjoiZWFjNGJhMGItMzhkYi00Mzk5LTliNmEtMjJjNjJiY2U1YWNlIiwidHlwIjoiQmVhcmVyIiwiYXpwIjoiYXBwLXNzamciLCJzZXNzaW9uX3N0YXRlIjoiOGI2YjhlMGUtNDAxYy00MDQwLTk0YjktMDhmOTlkYzgwOTE1IiwiYWNyIjoiMSIsImFsbG93ZWQtb3JpZ2lucyI6WyIqIl0sInJlYWxtX2FjY2VzcyI6eyJyb2xlcyI6WyJkZWZhdWx0LXJvbGVzLXNjb3JlMi1kZXYiLCJvZmZsaW5lX2FjY2VzcyIsInVtYV9hdXRob3JpemF0aW9uIiwic2NvcmUyLWFwaS1nZXJhbCJdfSwicmVzb3VyY2VfYWNjZXNzIjp7ImFwcC1wcm94eSI6eyJyb2xlcyI6WyJjb211bmljYWNhbyIsImFybWF6ZW5hbWVudG8iLCJwYWRyYW8iLCJ2aWRlbyJdfSwiYWNjb3VudCI6eyJyb2xlcyI6WyJtYW5hZ2UtYWNjb3VudCIsIm1hbmFnZS1hY2NvdW50LWxpbmtzIiwidmlldy1wcm9maWxlIl19LCJhcHAtc2NvcmUiOnsicm9sZXMiOlsidXN1YXJpbyJdfX0sInNjb3BlIjoiZW1haWwgcHJvZmlsZSIsInNpZCI6IjhiNmI4ZTBlLTQwMWMtNDA0MC05NGI5LTA4Zjk5ZGM4MDkxNSIsImVtYWlsX3ZlcmlmaWVkIjpmYWxzZSwibmFtZSI6IlJPQkVSVEEgQ0FTVFJPIFJPQkVSVEEgQ0FTVFJPIiwicHJlZmVycmVkX3VzZXJuYW1lIjoiMDc5MzUzNzc3MDciLCJnaXZlbl9uYW1lIjoiUk9CRVJUQSBDQVNUUk8iLCJmYW1pbHlfbmFtZSI6IlJPQkVSVEEgQ0FTVFJPIiwiZW1haWwiOiIwNzkzNTM3NzcwN0BzY29yZS5tYiJ9.Sbq1wyauUtM_UfxhGZBXcr7eEzIDppkmZjOVAFAtYiCroh6wqyNdSQO3g6P1aXA1FLi-uwOZbyhVTn2gDQW5ibH5Gg4JhIJPXwzMYzZ4xkoRpP-oOf3ZcAE-4s4hlUTNeM9iOBbLi10pdczW5f6xO7vdLgpLnfyvCcJnGwrJKk_LprnKPW5aan9gpeGkm2V1AKQPTkR2KKGi65lxrfDzcT7BNV7_nVc5RmSdGIewGOjnBWP02-xCyIJepZquDtsgVl2BO5DfFw3opZ8DjVjP1WyvkGpvyJYHMqfCNRYcBzJvVRXk7Lx_xbDK_7Bhay8GmCrwBD3VV2o3xIMRlLh1ww";

export const autenticateUserLogin = (token) => {
  const API_BASE_URL = import.meta.env.VITE_APP_API_BASEURL;
  const tokenFinal = token || DEV_TOKEN;

  return axios.get(`${API_BASE_URL}/login/getAuthorities`, {
    headers: {
      Authorization: `Bearer ${tokenFinal}`,
      Accept: "*/*"
    }
  })
  .then(resp => {
    console.log("Resposta backend:", resp);
    return resp.data || {};
  })
  .catch(err => {
    console.error("Erro Axios:", err.response || err);
    throw err;
  });
};