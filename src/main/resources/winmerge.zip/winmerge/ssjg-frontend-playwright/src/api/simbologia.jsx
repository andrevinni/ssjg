
import { showSidc } from "../utils/showSidc";

export async function getSimbolos() {
  try {
    const response = await fetch(
      "http://10.5.112.125:8083/ssjg-loader/api/v1/simbolos"
    );

    const data = await response.json();
 
    // já retorna com SIDC pronto
    return data.map((item) => ({
      ...item,
      sidcFinal: showSidc(item.sidcExtendido)
    }));

  } catch (error) {
    console.error("Erro ao carregar símbolos:", error);
    return [];
  }
}

export async function getDimensoes() {
  try {
    const response = await fetch("http://10.5.112.125:8083/ssjg-loader/api/v1/dimensoes");
    console.log("rota simbologia", response)
    const data = await response.json();

    const lista = data.dimensoes ?? [];

    return lista.map(item => ({
      ...item
    }));

  } catch (error) {
    console.error("Erro ao carregar simbologia:", error);
    return [];
  }
}

export async function getSimbologiaPorDimensao(dimensao) {
  try {
    const response = await fetch(
      `http://10.5.112.125:8083/ssjg-loader/api/v1/simbologia/${dimensao}`
    );
    const data = await response.json();

    return {
      iconeCentral: data.iconeCentral ?? [],
      primeiroModificador: data.primeiroModificador ?? [],
      segundoModificador: data.segundoModificador ?? []
    };
  } catch (error) {
    console.error("Erro ao carregar simbologia:", error);
    return {
      iconeCentral: [],
      primeiroModificador: [],
      segundoModificador: []
    };
  }
}

export async function deleteSimbolo(id) {
  try {
    await fetch(`http://10.5.112.125:8083/ssjg-loader/api/v1/simbolos/${id}`, {
      method: "DELETE"
    });

    return true;
  } catch (error) {
    console.error("Erro ao excluir símbolo:", error);
    return false;
  }
}



