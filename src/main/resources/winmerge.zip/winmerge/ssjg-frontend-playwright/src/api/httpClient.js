/**
 * httpClient.js  (substitui api.jsx)
 * ─────────────────────────────────────────────────────────────────
 * Cliente HTTP com:
 *   • Injeção automática do Bearer token em toda requisição
 *   • Refresh automático ao receber 401 (sem interromper outras chamadas)
 *   • Fila de requisições durante o refresh para evitar race conditions
 *   • Funções utilitárias mantidas da api.jsx original
 * ─────────────────────────────────────────────────────────────────
 */
import axios from 'axios';
import tokenManager from '../auth/tokenManager';
import authService  from '../auth/authService';

// ── Base URL ──────────────────────────────────────────────────────
const getBaseUrl = () => {
  if (
    window._parametros_?.API_BASEURL &&
    window._parametros_.API_BASEURL !== '%VITE_APP_API_BASEURL%'
  ) {
    return window._parametros_.API_BASEURL;
  }
  return import.meta.env.VITE_API_BASEURL || '/ssjg-auth/api/v1';
};

export const baseUrl = getBaseUrl();
console.log('🔧 API Base URL:', baseUrl);

// ── Instância Axios ───────────────────────────────────────────────
export const api = axios.create({
  baseURL:         baseUrl,
  timeout:         30000,
  headers:         { 'Content-Type': 'application/json' },
  withCredentials: false,
});

// ── Interceptor de REQUEST: injeta Bearer token ───────────────────
api.interceptors.request.use(
  (config) => {
    const token = tokenManager.getAccessToken();
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    console.log(`📡 ${config.method?.toUpperCase()} ${config.baseURL}${config.url}`);
    return config;
  },
  (error) => Promise.reject(error)
);

// ── Interceptor de RESPONSE: trata 401 com refresh automático ─────
let _isRefreshing  = false;
let _failedQueue   = [];

const processQueue = (error, token = null) => {
  _failedQueue.forEach(({ resolve, reject }) =>
    error ? reject(error) : resolve(token)
  );
  _failedQueue = [];
};

api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;

    // Não tenta refresh em rotas de auth
    const isAuthRoute = originalRequest.url?.includes('/auth/');
    if (error.response?.status !== 401 || originalRequest._retry || isAuthRoute) {
      return Promise.reject(error);
    }

    if (_isRefreshing) {
      // Outro refresh em andamento: enfileira esta requisição
      return new Promise((resolve, reject) => {
        _failedQueue.push({
          resolve: (token) => {
            originalRequest.headers.Authorization = `Bearer ${token}`;
            resolve(api(originalRequest));
          },
          reject,
        });
      });
    }

    originalRequest._retry = true;
    _isRefreshing = true;

    try {
      const newToken = await authService.refreshToken();
      processQueue(null, newToken);
      originalRequest.headers.Authorization = `Bearer ${newToken}`;
      return api(originalRequest);
    } catch (refreshError) {
      processQueue(refreshError, null);
      return Promise.reject(refreshError);
    } finally {
      _isRefreshing = false;
    }
  }
);

// ── Utilitários (mantidos da api.jsx original) ────────────────────
export const formatarArgQuery = (k, v) =>
  v ? `&${k}=${encodeURIComponent(v)}` : '';

export const montarQueryString = (criterios = {}) =>
  Object.entries(criterios)
    .map(([k, v]) =>
      v
        ? Array.isArray(v)
          ? v.map(va => formatarArgQuery(k, va)).join('')
          : formatarArgQuery(k, v)
        : ''
    )
    .join('');

export const tratarErroAxios = (err) => {
  if (err.response) {
    console.error('Erro API:', err.response.data);
    throw new Error(err.response.data?.message || err);
  }
  throw err;
};

// Compatibilidade com código legado que importa requestConfig
export const requestConfig = {
  get headers() {
    return {
      Authorization: `Bearer ${tokenManager.getAccessToken()}`,
      Accept: '*/*',
    };
  },
};
