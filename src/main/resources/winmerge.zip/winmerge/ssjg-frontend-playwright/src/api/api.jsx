import axios from 'axios';
import Cookies from "js-cookie";

// ✅ CORREÇÃO: Garantir URL absoluta
const getBaseUrl = () => {
  // Prioridade 1: window._parametros_
  if (window._parametros_?.API_BASEURL && 
      window._parametros_.API_BASEURL !== '%VITE_APP_API_BASEURL%') {
    return window._parametros_.API_BASEURL;
  }
  
  // Prioridade 2: URL fixa do servidor
  return 'http://10.5.112.125:8082/ssjg-auth/api/v1';
};

// ✅ Usar caminho relativo (Vite vai fazer proxy)
const baseUrl = '/ssjg-auth/api/v1';  // Não precisa da URL completa!

console.log('🔧 API Base URL:', baseUrl);

const api = axios.create({
  baseURL: baseUrl,
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json'
  },
  withCredentials: false // Não enviar credenciais cross-origin
});

api.interceptors.request.use(
  (config) => {
    const token = Cookies.get("access_token");
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    console.log(`📡 ${config.method?.toUpperCase()} ${config.baseURL}${config.url}`);
    return config;
  },
  (error) => Promise.reject(error)
);

const requestConfig = {
  headers: {
      Authorization: `Bearer ${Cookies.get("access_token")}`,
      Accept: "*/*"
  }
}

const formatarArgQuery = (k, v) => 
  v ? `&${k}=${encodeURIComponent(v)}` : ''

const montarQueryString = (criterios = {}) => 
  Object.entries(criterios)
  .map(([k, v]) =>
  v ? (Array.isArray(v) 
    ? v.map((va) => formatarArgQuery(k, va)).join('') 
    : formatarArgQuery(k, v)) 
    : ''
).join('')

const tratarErroAxios = (err) => {
  if (err.response) {
    console.error("Erro API:", err.response.data);
    throw new Error(err.response.data?.message || err);
  }
  throw err;
};

export {
  api,
  montarQueryString,
  requestConfig,
  baseUrl,
  tratarErroAxios 
}
