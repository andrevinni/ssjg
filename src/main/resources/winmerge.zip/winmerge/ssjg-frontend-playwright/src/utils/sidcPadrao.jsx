export const SIDC_PADRAO = {
  versao: "10",
  hostilidade: "03",
  dimensao: "00",
  situacao: "0",
  forcaTarefa: "0",
  amplificadores: "00",
  iconeCentral: "000000",
  primeiroModificador: "00",
  segundoModificador: "00",
  identPais: "076",
  identExtensao: "0000000"
};