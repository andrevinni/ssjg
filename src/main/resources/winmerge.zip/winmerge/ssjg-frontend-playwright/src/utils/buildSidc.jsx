import { showSidc } from "./showSidc";

export function buildSidc({
  base,
  iconeCentral,
  primeiroModificador,
  segundoModificador,
  identExtensao = "0000000"
}) {
  return showSidc({
    ...base,
    iconeCentral: iconeCentral ?? base.iconeCentral,
    primeiroModificador: primeiroModificador ?? base.primeiroModificador,
    segundoModificador: segundoModificador ?? base.segundoModificador,
    identExtensao
  });
}
