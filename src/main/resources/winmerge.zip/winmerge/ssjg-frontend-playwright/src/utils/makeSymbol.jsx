import { useEffect, useState } from "react";

export const useMakeSymbol = (sidc) => {
  const [simboloPNG, setSimboloPNG] = useState(null);

  useEffect(() => {
    if (!sidc || typeof sidc !== "string") {
      setSimboloPNG(null);
      return;
    }

    try {
      const symbol = new window.ms.Symbol(sidc.trim(), { size: 100 });
      const png = symbol.asCanvas().toDataURL();
      setSimboloPNG(png);
    } catch (error) {
      console.error("Erro ao criar símbolo:", error);
      setSimboloPNG(null);
    }
  }, [sidc]);

  return simboloPNG;
};
