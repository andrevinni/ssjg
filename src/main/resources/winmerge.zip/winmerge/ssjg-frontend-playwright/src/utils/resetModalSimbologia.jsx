import { showSidc } from "./showSidc";
import { SIDC_PADRAO } from "./sidcPadrao";

export function resetModalSimbologia({
  setSelectedDimensao,
  setIconeCentral,
  setMod1,
  setMod2,
  setIconesCentrais,
  setPrimeirosMods,
  setSegundosMods,
  setSidc,
  setExtensoes
}) {
  setSelectedDimensao("");
  setIconeCentral("");
  setMod1("");
  setMod2("");

  setIconesCentrais([]);
  setPrimeirosMods([]);
  setSegundosMods([]);

  // 🔥 Zera extensões
  setExtensoes({
    iconeCentral: 0,
    mod1: 0,
    mod2: 0
  });

  setSidc(showSidc(SIDC_PADRAO));
}
