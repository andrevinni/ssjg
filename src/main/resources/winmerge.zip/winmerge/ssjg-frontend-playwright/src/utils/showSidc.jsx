export function showSidc(sidc) {
  if (!sidc) return "";

  const {
    versao = "",
    hostilidade = "",
    dimensao = "",
    situacao = "",
    forcaTarefa = "",
    amplificadores = "",
    iconeCentral = "",
    primeiroModificador = "",
    segundoModificador = "",
    identPais = "",
    identExtensao = ""
  } = sidc;

  return (
    versao +
    hostilidade +
    dimensao +
    situacao +
    forcaTarefa +
    amplificadores +
    iconeCentral +
    primeiroModificador +
    segundoModificador +
    identPais +
    identExtensao
  );
}
