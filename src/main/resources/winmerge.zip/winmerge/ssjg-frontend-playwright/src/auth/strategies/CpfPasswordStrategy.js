/**
 * CpfPasswordStrategy.js
 * ─────────────────────────────────────────────────────────────────
 * Estratégia de autenticação por CPF + Senha.
 *
 * CONTRATO COM O BACKEND (Java Spring Boot):
 *   POST /auth/login
 *   Body:  { cpf: "000.000.000-00", senha: "****", strategy: "cpf_password" }
 *   200:   { access_token, refresh_token, token_type: "Bearer", expires_in: 3600 }
 *   401:   { error: "INVALID_CREDENTIALS", message: "CPF ou senha inválidos." }
 *   403:   { error: "ACCOUNT_LOCKED", message: "..." }
 *
 * Durante a fase MOCK, a validação é feita localmente.
 * Basta trocar _mockAuthenticate() pela chamada real à API.
 * ─────────────────────────────────────────────────────────────────
 */

// ── Usuários mock para apresentação ──────────────────────────────
// REMOVER em produção — substituir pela chamada real ao backend.
const MOCK_USERS = [
  {
    cpf:         '529.982.247-25',   // CPF válido para testes
    senha:       '123456',
    nome:        'Capitão Demo',
    posto:       'CF',
    authorities: ['ROLE_USER', 'ROLE_OPERADOR'],
  },
  {
    cpf:         '153.509.460-56',   // CPF válido para testes
    senha:       'admin123',
    nome:        'Administrador Sistema',
    posto:       'CMG',
    authorities: ['ROLE_USER', 'ROLE_ADMIN', 'ROLE_GESTOR'],
  },
];

// ── Helpers ───────────────────────────────────────────────────────

/** Remove formatação do CPF: "000.000.000-00" → "00000000000" */
const sanitizeCpf = (cpf) => cpf.replace(/\D/g, '');

/** Valida formato de CPF (11 dígitos, não todos iguais) */
const isValidCpfFormat = (cpf) => {
  const digits = sanitizeCpf(cpf);
  if (digits.length !== 11) return false;
  if (/^(\d)\1{10}$/.test(digits)) return false;
  return true;
};

// ── Estratégia ───────────────────────────────────────────────────

const CpfPasswordStrategy = {

  name: 'cpf_password',

  label: 'CPF e Senha',  // usado para renderizar o botão/tab no futuro

  /**
   * Valida os dados de entrada antes de enviar ao backend.
   * Retorna null se válido, ou string com mensagem de erro.
   */
  validate({ cpf, senha }) {
    if (!cpf || !isValidCpfFormat(cpf)) {
      return 'CPF inválido. Informe os 11 dígitos.';
    }
    if (!senha || senha.length < 6) {
      return 'A senha deve ter no mínimo 6 caracteres.';
    }
    return null;
  },

  /**
   * Autentica o usuário.
   *
   * Em produção: faz POST /auth/login e retorna o usuário + tokens do backend.
   * Em mock: valida localmente e retorna dados simulados.
   *
   * @returns {Promise<{ user: object }>}
   * @throws  {Error} com mensagem amigável em caso de falha
   */
  async authenticate({ cpf, senha }) {
    // ── MOCK (remover quando backend estiver pronto) ──────────────
    if (import.meta.env.VITE_AUTH_MOCK === 'true') {
      return await this._mockAuthenticate({ cpf, senha });
    }

    // ── PRODUÇÃO: chamada real ao backend ─────────────────────────
    // Descomente e ajuste quando o Java estiver pronto:
    //
    // const { api } = await import('../../api/httpClient');
    // const { data } = await api.post('/auth/login', {
    //   cpf: sanitizeCpf(cpf),
    //   senha,
    //   strategy: this.name,
    // });
    // return { user: data.user, accessToken: data.access_token, refreshToken: data.refresh_token };

    throw new Error('Backend não configurado. Defina VITE_AUTH_MOCK=true para usar modo mock.');
  },

  // ── Mock interno (apenas para apresentação) ───────────────────
  async _mockAuthenticate({ cpf, senha }) {
    // Simula latência de rede
    await new Promise(r => setTimeout(r, 800));

    const cpfLimpo = sanitizeCpf(cpf);
    const user = MOCK_USERS.find(
      u => sanitizeCpf(u.cpf) === cpfLimpo && u.senha === senha
    );

    if (!user) {
      const err = new Error('CPF ou senha inválidos.');
      err.code = 'INVALID_CREDENTIALS';
      throw err;
    }

    const { senha: _, ...userSemSenha } = user;
    return { user: userSemSenha };
  },
};

export default CpfPasswordStrategy;