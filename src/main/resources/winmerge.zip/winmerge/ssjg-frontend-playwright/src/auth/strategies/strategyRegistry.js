/**
 * strategyRegistry.js
 * ─────────────────────────────────────────────────────────────────
 * Registro central de estratégias de autenticação.
 *
 * Para adicionar uma nova estratégia (OAuth, CAC, Biometria, SSO…):
 *   1. Crie MinhaStrategy.js seguindo o contrato de CpfPasswordStrategy
 *   2. Importe e registre aqui com registry.register(MinhaStrategy)
 *   3. Pronto — sem mais alterações em nenhum outro arquivo.
 * ─────────────────────────────────────────────────────────────────
 */
import CpfPasswordStrategy from './CpfPasswordStrategy';

// Adicione futuros imports aqui:
// import OAuthStrategy      from './OAuthStrategy';
// import CacStrategy        from './CacStrategy';
// import BiometriaStrategy  from './BiometriaStrategy';

// ── Contrato que toda estratégia deve implementar ─────────────────
//
// {
//   name:       string           — identificador único (ex: 'cpf_password')
//   label:      string           — rótulo legível (ex: 'CPF e Senha')
//   validate:   (credentials) => string | null
//   authenticate:(credentials) => Promise<{ user, accessToken?, refreshToken? }>
// }

class StrategyRegistry {
  constructor() {
    this._strategies = new Map();
  }

  register(strategy) {
    if (!strategy.name || !strategy.authenticate) {
      throw new Error(`Estratégia inválida: deve ter 'name' e 'authenticate'.`);
    }
    this._strategies.set(strategy.name, strategy);
    return this; // fluent API
  }

  get(name) {
    const s = this._strategies.get(name);
    if (!s) throw new Error(`Estratégia '${name}' não encontrada no registry.`);
    return s;
  }

  /** Lista todas as estratégias disponíveis (para renderizar opções de login). */
  list() {
    return Array.from(this._strategies.values());
  }

  has(name) {
    return this._strategies.has(name);
  }
}

// ── Instância singleton pré-configurada ───────────────────────────
const registry = new StrategyRegistry();

registry
  .register(CpfPasswordStrategy);
  // .register(OAuthStrategy)     // descomente quando implementar
  // .register(CacStrategy)
  // .register(BiometriaStrategy)

export default registry;
