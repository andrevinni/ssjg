/**
 * tokenManager.js
 * ─────────────────────────────────────────────────────────────────
 * Responsável por criar, armazenar, ler e invalidar tokens JWT.
 *
 * CONTRATO COM O BACKEND (Java Spring Boot):
 *   POST /auth/login       → { access_token, refresh_token, token_type, expires_in }
 *   POST /auth/refresh     → { access_token, expires_in }
 *   POST /auth/logout      → 204 No Content
 *
 * Tokens são armazenados em Cookies httpOnly-like via js-cookie.
 * ─────────────────────────────────────────────────────────────────
 */
import Cookies from 'js-cookie';

// ── Configurações ────────────────────────────────────────────────
const ACCESS_TOKEN_KEY  = 'access_token';
const REFRESH_TOKEN_KEY = 'refresh_token';
const USER_DATA_KEY     = 'auth_user';

const ACCESS_TOKEN_TTL_MIN  = 3;        // 60 minutos
//const REFRESH_TOKEN_TTL_MIN = 12 * 60;  // 12 horas
const REFRESH_TOKEN_TTL_MIN = 5;  // 5 minutos

// ── Helpers internos ─────────────────────────────────────────────

/**
 * Cria um JWT mockado (apenas para frontend/apresentação).
 * O backend real emitirá um JWT assinado com RS256/HS256.
 */
const _createMockJWT = (payload) => {
  const header  = btoa(JSON.stringify({ alg: 'HS256', typ: 'JWT' }));
  const body    = btoa(JSON.stringify(payload));
  const sig     = btoa('mock-signature-substituir-pelo-backend');
  return `${header}.${body}.${sig}`;
};

/**
 * Decodifica o payload de qualquer JWT (mock ou real).
 */
const _decodePayload = (token) => {
  try {
    const parts = token.split('.');
    if (parts.length !== 3) return null;
    return JSON.parse(atob(parts[1]));
  } catch {
    return null;
  }
};

// ── API pública ──────────────────────────────────────────────────

const tokenManager = {

  /**
   * Gera e armazena um par de tokens (chamado pelo authService após login bem-sucedido).
   * Em produção, os tokens virão diretamente da resposta do backend.
   */
  setTokens({ accessToken, refreshToken, user }) {
    Cookies.set(ACCESS_TOKEN_KEY,  accessToken,  { expires: ACCESS_TOKEN_TTL_MIN / 1440, sameSite: 'Strict' });
    Cookies.set(REFRESH_TOKEN_KEY, refreshToken, { expires: REFRESH_TOKEN_TTL_MIN / 1440, sameSite: 'Strict' });
    if (user) {
      Cookies.set(USER_DATA_KEY, JSON.stringify(user), { expires: REFRESH_TOKEN_TTL_MIN / 1440 });
    }
  },

  /**
   * Cria tokens mock para apresentação/testes.
   * REMOVER quando o backend estiver pronto — o backend emitirá tokens reais.
   */
  createMockTokens(user) {
    const now = Math.floor(Date.now() / 1000);

    const accessToken = _createMockJWT({
      sub:         user.cpf,
      name:        user.nome,
      authorities: user.authorities || [],
      iat:         now,
      exp:         now + ACCESS_TOKEN_TTL_MIN * 60,
      type:        'access',
    });

    const refreshToken = _createMockJWT({
      sub:  user.cpf,
      iat:  now,
      exp:  now + REFRESH_TOKEN_TTL_MIN * 60,
      type: 'refresh',
    });

    this.setTokens({ accessToken, refreshToken, user });
    return { accessToken, refreshToken };
  },

  getAccessToken()  { return Cookies.get(ACCESS_TOKEN_KEY)  || null; },
  getRefreshToken() { return Cookies.get(REFRESH_TOKEN_KEY) || null; },

  getUser() {
    try {
      const raw = Cookies.get(USER_DATA_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch {
      return null;
    }
  },

  /**
   * Retorna true se o access_token existir e não estiver expirado.
   */
  isAccessTokenValid() {
    const token = this.getAccessToken();
    if (!token) return false;
    const payload = _decodePayload(token);
    if (!payload?.exp) return false;
    // Margem de 30s para evitar race condition
    return payload.exp > Math.floor(Date.now() / 1000) + 30;
  },

  /**
   * Retorna true se o refresh_token existir e não estiver expirado.
   */
  isRefreshTokenValid() {
    const token = this.getRefreshToken();
    if (!token) return false;
    const payload = _decodePayload(token);
    if (!payload?.exp) return false;
    return payload.exp > Math.floor(Date.now() / 1000);
  },

  /**
   * Quantos milissegundos até o access_token expirar.
   * Retorna 0 se já expirado ou inválido.
   */
  msUntilExpiry() {
    const token = this.getAccessToken();
    if (!token) return 0;
    const payload = _decodePayload(token);
    if (!payload?.exp) return 0;
    return Math.max(0, payload.exp * 1000 - Date.now());
  },

  clearTokens() {
    Cookies.remove(ACCESS_TOKEN_KEY);
    Cookies.remove(REFRESH_TOKEN_KEY);
    Cookies.remove(USER_DATA_KEY);
  },
};

export default tokenManager;
