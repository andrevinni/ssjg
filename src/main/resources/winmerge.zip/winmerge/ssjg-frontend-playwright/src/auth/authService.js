/**
 * authService.js
 * ─────────────────────────────────────────────────────────────────
 * Orquestra todo o ciclo de vida da autenticação:
 *   • Login via qualquer estratégia registrada
 *   • Logout
 *   • Refresh automático do access_token
 *   • Controle de inatividade (expira sessão após 12h sem uso)
 *   • Notificação de eventos para o AuthContext
 * ─────────────────────────────────────────────────────────────────
 */
import tokenManager    from './tokenManager';
import strategyRegistry from './strategies/strategyRegistry';

// ── Configurações ─────────────────────────────────────────────────
const INACTIVITY_TIMEOUT_MS = 2 * 60 * 1000; // 2 horas
const REFRESH_MARGIN_MS     =  1 * 60 * 1000;       // renova 5min antes de expirar
export const WARN_BEFORE_MS =  1 * 60 * 1000;  // aviso 1 min antes

// ── Estado interno ────────────────────────────────────────────────
let _inactivityTimer  = null;
let _refreshTimer     = null;
let _onSessionExpired = null;  // callback registrado pelo AuthContext
let _isRefreshing     = false;
let _pendingQueue     = [];    // fila de chamadas aguardando refresh

// ── Helpers ───────────────────────────────────────────────────────

const _notifyExpired = () => {
  authService.logout();
  _onSessionExpired?.();
};

const _scheduleRefresh = () => {
  clearTimeout(_refreshTimer);
  const msLeft = tokenManager.msUntilExpiry();
  if (msLeft <= 0) return;

  const delay = Math.max(0, msLeft - REFRESH_MARGIN_MS);
  _refreshTimer = setTimeout(() => authService.refreshToken(), delay);
};

const _resetInactivity = () => {
  clearTimeout(_inactivityTimer);
  _inactivityTimer = setTimeout(_notifyExpired, INACTIVITY_TIMEOUT_MS);
};

const ACTIVITY_EVENTS = ['mousemove', 'keydown', 'click', 'scroll', 'touchstart'];

const _startActivityListeners = () => {
  ACTIVITY_EVENTS.forEach(e => window.addEventListener(e, _resetInactivity, { passive: true }));
  _resetInactivity();
};

const _stopActivityListeners = () => {
  ACTIVITY_EVENTS.forEach(e => window.removeEventListener(e, _resetInactivity));
  clearTimeout(_inactivityTimer);
};

// ── authService ───────────────────────────────────────────────────

const authService = {

  /**
   * Registra callback chamado quando a sessão expira por inatividade.
   * O AuthContext usa isso para redirecionar para o login.
   */
  onSessionExpired(callback) {
    _onSessionExpired = callback;
  },

  /**
   * Realiza login usando a estratégia especificada.
   *
   * @param {string} strategyName  — ex: 'cpf_password'
   * @param {object} credentials   — ex: { cpf, senha }
   * @returns {Promise<object>}    — dados do usuário autenticado
   */
  async login(strategyName = 'cpf_password', credentials = {}) {
    const strategy = strategyRegistry.get(strategyName);

    // Valida campos antes de chamar o backend
    const validationError = strategy.validate(credentials);
    if (validationError) {
      throw new Error(validationError);
    }

    // Autentica via estratégia
    const result = await strategy.authenticate(credentials);

    // Gera/armazena tokens
    if (result.accessToken && result.refreshToken) {
      // Backend real retornou os tokens diretamente
      tokenManager.setTokens({
        accessToken:  result.accessToken,
        refreshToken: result.refreshToken,
        user:         result.user,
      });
    } else {
      // Modo mock: gera tokens localmente
      tokenManager.createMockTokens(result.user);
    }

    // Inicia monitoramento
    _scheduleRefresh();
    _startActivityListeners();

    return result.user;
  },

  /**
   * Renova o access_token usando o refresh_token.
   *
   * CONTRATO BACKEND:
   *   POST /auth/refresh
   *   Body:  { refresh_token: "..." }
   *   200:   { access_token, expires_in }
   *   401:   sessão expirada → redirecionar para login
   */
  async refreshToken() {
    if (_isRefreshing) {
      // Se já está renovando, enfileira e aguarda
      return new Promise((resolve, reject) => {
        _pendingQueue.push({ resolve, reject });
      });
    }

    _isRefreshing = true;

    try {
      const refreshToken = tokenManager.getRefreshToken();
      if (!refreshToken || !tokenManager.isRefreshTokenValid()) {
        throw new Error('Refresh token expirado ou ausente.');
      }

      // ── MOCK (remover quando backend estiver pronto) ──────────
      if (import.meta.env.VITE_AUTH_MOCK === 'true') {
        await new Promise(r => setTimeout(r, 300));
        const user = tokenManager.getUser();
        if (user) tokenManager.createMockTokens(user);
      } else {
        // ── PRODUÇÃO ──────────────────────────────────────────────
        // const { api } = await import('../api/httpClient');
        // const { data } = await api.post('/auth/refresh', { refresh_token: refreshToken });
        // tokenManager.setTokens({ accessToken: data.access_token, refreshToken, user: tokenManager.getUser() });
      }

      const newToken = tokenManager.getAccessToken();
      _pendingQueue.forEach(p => p.resolve(newToken));
      _scheduleRefresh();

      return newToken;

    } catch (err) {
      _pendingQueue.forEach(p => p.reject(err));
      _notifyExpired();
      throw err;
    } finally {
      _isRefreshing = false;
      _pendingQueue = [];
    }
  },

  logout() {
    tokenManager.clearTokens();
    _stopActivityListeners();
    clearTimeout(_refreshTimer);
    _isRefreshing = false;
    _pendingQueue = [];
  },

  resumeSession() {
  if (this.isAuthenticated()) {
    _scheduleRefresh();
    _startActivityListeners();
    }
  },

  isAuthenticated() {
    return tokenManager.isAccessTokenValid() || tokenManager.isRefreshTokenValid();
  },

  getUser() {
    return tokenManager.getUser();
  },

  getAccessToken() {
    return tokenManager.getAccessToken();
  },

  /**
   * Busca authorities/perfis do usuário logado.
   *
   * CONTRATO BACKEND:
   *   GET /auth/me/authorities
   *   Header: Authorization: Bearer <access_token>
   *   200: { authorities: ['ROLE_USER', 'ROLE_ADMIN', ...] }
   */
  async getAuthorities() {
    if (import.meta.env.VITE_AUTH_MOCK === 'true') {
      await new Promise(r => setTimeout(r, 200));
      return tokenManager.getUser()?.authorities || [];
    }
    // const { api } = await import('../api/httpClient');
    // const { data } = await api.get('/auth/me/authorities');
    // return data.authorities;
  },

  /**
   * Retorna as estratégias disponíveis para login.
   * Útil para renderizar múltiplas opções na tela de login.
   */
  getAvailableStrategies() {
    return strategyRegistry.list().map(s => ({ name: s.name, label: s.label }));
  },
};

export { authService };
export default authService;
