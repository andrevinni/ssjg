/**
 * AuthContext.jsx
 * ─────────────────────────────────────────────────────────────────
 * Provider global de autenticação.
 * Envolva o <App> com <AuthProvider> para disponibilizar o contexto.
 * ─────────────────────────────────────────────────────────────────
 */
import { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import authService from './authService';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const navigate  = useNavigate();
  const [user,    setUser]    = useState(null);
  const [loading, setLoading] = useState(true);  // true enquanto verifica sessão inicial

  // ── Inicialização: restaura sessão existente ──────────────────
  useEffect(() => {
    const existingUser = authService.getUser();
    if (authService.isAuthenticated() && existingUser) {
      setUser(existingUser);
      authService.resumeSession(); // ← ADICIONE esta linha
    }
    setLoading(false);
  }, []);

  // ── Registra callback de expiração por inatividade ────────────
  useEffect(() => {
    authService.onSessionExpired(() => {
      setUser(null);
      navigate('/', { replace: true, state: { reason: 'inactivity' } });
    });
  }, [navigate]);

  // ── Login ─────────────────────────────────────────────────────
  const login = useCallback(async (strategyName, credentials) => {
    const loggedUser = await authService.login(strategyName, credentials);
    setUser(loggedUser);
    return loggedUser;
  }, []);

  // ── Logout ────────────────────────────────────────────────────
  const logout = useCallback(() => {
    authService.logout();
    setUser(null);
    navigate('/', { replace: true });
  }, [navigate]);

  const value = {
    user,
    loading,
    isAuthenticated: !!user && authService.isAuthenticated(),
    login,
    logout,
    getAccessToken: authService.getAccessToken.bind(authService),
    availableStrategies: authService.getAvailableStrategies(),
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

/**
 * Hook principal — use em qualquer componente:
 *   const { user, login, logout, isAuthenticated } = useAuth();
 */
export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth deve ser usado dentro de <AuthProvider>');
  return ctx;
};

export default AuthContext;
