/**
 * Login.jsx
 * ─────────────────────────────────────────────────────────────────
 * Página de login. Usa o AuthContext para orquestrar a autenticação.
 * Compatível com qualquer estratégia registrada no strategyRegistry.
 * ─────────────────────────────────────────────────────────────────
 */
import { useEffect, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';
import HandleLogin from './HandleLogin';
import Loading     from '../components/Loading/Loading';

const Login = () => {
  const navigate  = useNavigate();
  const location  = useLocation();
  const { login, isAuthenticated, loading: authLoading } = useAuth();

  const [loading,      setLoading]      = useState(false);
  const [errorMessage, setErrorMessage] = useState(null);

  // Mensagem de expiração por inatividade
  const inactivityMsg = location.state?.reason === 'inactivity'
    ? 'Sessão encerrada por inatividade. Faça login novamente.'
    : null;

  // Redireciona se já autenticado
  useEffect(() => {
    if (!authLoading && isAuthenticated) {
      navigate('/home', { replace: true });
    }
  }, [isAuthenticated, authLoading, navigate]);

  const handleLogin = async ({ cpf, senha }) => {
    setLoading(true);
    setErrorMessage(null);

    try {
      await login('cpf_password', { cpf, senha });
      navigate('/home', { replace: true });
    } catch (err) {
      console.error('❌ Erro no login:', err);
      setErrorMessage(err.message || 'Erro na autenticação. Verifique suas credenciais.');
    } finally {
      setLoading(false);
    }
  };

  if (authLoading) {
    return <Loading fullScreen message="Verificando sessão…" />;
  }

  if (loading) {
    return <Loading fullScreen message="Validando acesso…" />;
  }

  return (
    <HandleLogin
      onLogin={handleLogin}
      errorMessage={errorMessage || inactivityMsg}
      loading={loading}
    />
  );
};

export default Login;
