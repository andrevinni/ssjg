import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import ModalSimbologia from "../../components/ModalSimbologia/ModalSimbologia";
import "./SimbolosPage.scss";
import { getSimbolos } from "../../api/simbologia";
import SimboloCard from "../../components/SimboloCard/SimboloCard";
import {deleteSimbolo} from "../../api/simbologia"
import ConfirmDialog from "../../components/ConfirmDialog/ConfirmDialog";
const SimbolosPage = () => {
  const navigate = useNavigate();

  const [openModal, setOpenModal] = useState(false);
  const [search, setSearch] = useState("");
  const [simbolos, setSimbolos] = useState([]);
  const [simboloSelect, setSimboloSelect] = useState(null);
  const [confirmOpen, setConfirmOpen] = useState(false);

useEffect(() => {
  async function loadSimbolos() {
    const data = await getSimbolos();
    setSimbolos(data);
  }

  loadSimbolos();
}, []);

  const simbolosFiltrados = simbolos.filter((s) =>
    s.nome?.toLowerCase().includes(search.toLowerCase())
  );

 async function confirmarDelete() {
  const ok = await deleteSimbolo(simboloSelect);

  if (ok) {
    setSimbolos(prev => prev.filter(s => s.id !== simboloSelect));
    setSimboloSelect(null);
  }

  setConfirmOpen(false);
}



  return (
    <div className="simbolos-page">
      <header className="header">
        <h2>Símbolos</h2>

        <div className="actions">
          <div className="search-wrapper">
          <span className="search-icon">🔍</span>
          <input
           type="text"
           placeholder="Buscar símbolo..."
           value={search}
           onChange={(e) => setSearch(e.target.value)}
          />
        </div>


          <button onClick={() => setOpenModal(true)}>
            + Novo Símbolo
          </button>
          <button 
          onClick={() => setConfirmOpen(true)} 
          disabled={!simboloSelect} 
          className="delete">
           🗑 Excluir
          </button>


          <button className="close" onClick={() => navigate(-1)}>
            ✕
          </button>
        </div>
      </header>

      <div className="lista-simbolos">
        {simbolosFiltrados.map((simbolo) => (
    <SimboloCard 
      key={simbolo.id} 
      simbolo={simbolo} 
      selecionado={simboloSelect === simbolo.id}
      onClick={() => setSimboloSelect(simbolo.id)}/>
  ))}
      </div>

      <ModalSimbologia
        open={openModal}
        onClose={() => setOpenModal(false)}
      />
      <ConfirmDialog
      open={confirmOpen}
      title="Excluir símbolo"
      message="Tem certeza que deseja excluir este símbolo?"
      onConfirm={confirmarDelete}
      onCancel={() => setConfirmOpen(false)}
     />

    </div>

  );
};

export default SimbolosPage;
