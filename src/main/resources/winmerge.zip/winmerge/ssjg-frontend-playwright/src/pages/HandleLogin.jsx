/**
 * HandleLogin.jsx
 * ─────────────────────────────────────────────────────────────────
 * Componente de apresentação (UI only) do formulário de login.
 * Mantém o visual original com logos + BoxForm.
 * ─────────────────────────────────────────────────────────────────
 */
import React, { useState } from 'react';
import ssjgLogo   from '../assets/img/ssjg.png';
import marinhaLogo from '../assets/img/marinha.gif';
import brasaoLogo  from '../assets/img/brasao.png';
import BoxForm     from '../components/Boxform/BoxForm.jsx';

// ── Formatação de CPF ─────────────────────────────────────────────
const formatCpf = (value) => {
  const digits = value.replace(/\D/g, '').slice(0, 11);
  return digits
    .replace(/(\d{3})(\d)/, '$1.$2')
    .replace(/(\d{3})(\d)/, '$1.$2')
    .replace(/(\d{3})(\d{1,2})$/, '$1-$2');
};

// ─────────────────────────────────────────────────────────────────
const HandleLogin = ({ onLogin, errorMessage, loading }) => {
  const [cpf,   setCpf]   = useState('');
  const [senha, setSenha] = useState('');

  const handleCpfChange = (e) => setCpf(formatCpf(e.target.value));

  const handleSubmit = (e) => {
    e.preventDefault();
    onLogin({ cpf, senha });
  };

  return (
    <div className="login-container">
      <div className="login-header-logos">
        <img src={marinhaLogo} alt="Logo Marinha" />
        <img src={brasaoLogo}  alt="Logo Brasão" />
        <img src={ssjgLogo}    alt="Logo SSJG" />
      </div>

      <BoxForm logo={ssjgLogo} title="Sistema Simulador para Jogos de Guerra">
        <form className="login-form" onSubmit={handleSubmit} noValidate>

          <div className="form-group">
            <label htmlFor="cpf">CPF</label>
            <input
              id="cpf"
              type="text"
              inputMode="numeric"
              placeholder="000.000.000-00"
              value={cpf}
              onChange={handleCpfChange}
              disabled={loading}
              autoComplete="username"
              maxLength={14}
            />
          </div>

          <div className="form-group">
            <label htmlFor="senha">Senha</label>
            <input
              id="senha"
              type="password"
              placeholder="Digite sua senha"
              value={senha}
              onChange={(e) => setSenha(e.target.value)}
              disabled={loading}
              autoComplete="current-password"
            />
          </div>

          {errorMessage && (
            <div className="error-card" role="alert">
              {errorMessage}
            </div>
          )}

          <button type="submit" disabled={loading || !cpf || !senha}>
            {loading ? 'Autenticando…' : 'Autenticar'}
          </button>

          {/* ── Créditos de modo mock (visível apenas em dev) ────── */}
          {import.meta.env.VITE_AUTH_MOCK === 'true' && (
            <p className="mock-hint">
              🧪 <strong>Modo Mock</strong> — CPF: <code>529.982.247-25</code> / Senha: <code>123456</code>
            </p>
          )}
        </form>
      </BoxForm>
    </div>
  );
};

export default HandleLogin;
