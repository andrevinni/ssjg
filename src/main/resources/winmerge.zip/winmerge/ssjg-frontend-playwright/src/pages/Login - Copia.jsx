import { useEffect, useState } from 'react';
import { useNavigate } from "react-router-dom";
import Cookies from "js-cookie";
import { useAuth } from "react-oidc-context";
import HandleLogin from './HandleLogin';
import { autenticateUserLogin } from '../api/auth';
import Loading from '../components/Loading/Loading';

// Decodifica o JWT e verifica se está expirado
const isTokenExpired = (token) => {
  try {
    const payload = JSON.parse(atob(token.split('.')[1]));
    const agora = Math.floor(Date.now() / 1000);
    return payload.exp < agora;
  } catch {
    return true; // token inválido = considera expirado
  }
};

const Login = () => {
  const auth = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [authenticated, setAuthenticated] = useState(false);
  const [errorMessage, setErrorMessage] = useState(null);

  // ✅ Novo fluxo: login direto com token do .env
  const handleDevLogin = async () => {
    const token = import.meta.env.VITE_DEV_TOKEN;

    // Em qualquer componente, adicione:
    console.log('window._parametros_:', window._parametros_);
    console.log('API_BASEURL:', window._parametros_?.API_BASEURL);

    if (!token) {
      setErrorMessage("Token não encontrado no .env (VITE_DEV_TOKEN)");
      return;
    }

    if (isTokenExpired(token)) {
      setErrorMessage("Token expirado! Gere um novo token pelo Postman e atualize o VITE_DEV_TOKEN no .env");
      return;
    }

    setLoading(true);
    try {
      Cookies.set("access_token", token);
      await autenticateUserLogin(token);
      setAuthenticated(true);
      navigate("/home", { replace: true });
    } catch (err) {
      setErrorMessage("Erro na autenticação com o Backend");
      console.error("Erro na autenticação:", err);
      Cookies.remove("access_token");
    } finally {
      setLoading(false);
    }
  };

  // Força logout quando o token OIDC expira
  useEffect(() => {
    if (auth.user?.expired) {
      Cookies.remove("access_token");
      auth.removeUser();
      setAuthenticated(false);
      navigate("/", { replace: true });
      setErrorMessage("Sua sessão expirou. Faça login novamente.");
    }
  }, [auth.user, navigate]);

  // Escuta evento de expiração do token OIDC
  useEffect(() => {
    const handleTokenExpired = () => {
      Cookies.remove("access_token");
      auth.removeUser();
      setAuthenticated(false);
      navigate("/", { replace: true });
      setErrorMessage("Sua sessão expirou. Faça login novamente.");
    };
    auth.events.addAccessTokenExpired(handleTokenExpired);
    return () => auth.events.removeAccessTokenExpired(handleTokenExpired);
  }, [auth, navigate]);

  // Fluxo OIDC normal (quando Keycloak estiver funcionando)
  useEffect(() => {
    const autenticar = async () => {
      if (auth.isAuthenticated && auth.user?.access_token && !authenticated) {
        setLoading(true);
        const token = auth.user.access_token;
        Cookies.set("access_token", token);
        try {
          await autenticateUserLogin(token);
          setAuthenticated(true);
          navigate("/home", { replace: true });
        } catch (err) {
          setErrorMessage("Erro na autenticação com o Backend");
          Cookies.remove("access_token");
          auth.removeUser();
        } finally {
          setLoading(false);
        }
      }
    };
    autenticar();
  }, [auth.isAuthenticated, auth.user]);

  if (loading) {
    return <Loading fullScreen message="Validando acesso com o servidor…" />;
  }
  return (
    <div>
      <HandleLogin
        onLogin={handleDevLogin}   // ← agora chama o fluxo dev
        errorMessage={errorMessage}
      />
    </div>
  );
};

export default Login;