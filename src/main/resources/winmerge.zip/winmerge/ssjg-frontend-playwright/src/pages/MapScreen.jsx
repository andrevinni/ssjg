import { useNavigate, useLocation } from "react-router-dom";
import { MapGame } from "../components/MapGame/MapGame";

const MapScreen = () => {
  const location = useLocation();
  const navigate = useNavigate();

  // Recebe o jogo via state do Link
  const jogo = location.state?.jogo;

  if (!jogo) {
    return (
      <div style={{ padding: "2rem" }}>
        <p>Jogo não encontrado!</p>
        <button onClick={() => navigate("/carimbo")}>Voltar</button>
      </div>
    );
  }

  return <MapGame jogo={jogo} fullScreen />;
};

export default MapScreen;
