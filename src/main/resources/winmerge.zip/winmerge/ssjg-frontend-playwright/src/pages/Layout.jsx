// src/layouts/Layout.jsx
import { UserMenu } from '../components/UserMenu/UserMenu.jsx';
import { SearchBar } from '../components/SearchBar/SearchBar.jsx';
import { Menu } from '../components/Menu/Menu.jsx';
import { Outlet } from "react-router-dom";

const Layout = () => {
  const handleSearch = (query) => {
    console.log("Buscando por:", query);
  };

  return (
    <div className="app-container">
      <header className="app-header">
        <Menu />
        <SearchBar onSearch={handleSearch} />
        <div className="header-right">
          <UserMenu />
        </div>
      </header>

      {/* Onde as páginas serão renderizadas */}
      <main className="page-content">
        <Outlet />
      </main>
    </div>
  );
};

export default Layout;
