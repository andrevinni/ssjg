
import carimbo from '../../assets/img/carimbo.png'
import mahjid from '../../assets/img/mahjid.png'
import azuver from '../../assets/img/azuver.jpg'
import { ModalGame } from "../../components/ModalGame/ModalGame.jsx";
import {CardAction} from "../../components/CardAction/CardAction.jsx"
import {InfoBoard} from "../../components/InfoBoard/InfoBoard.jsx"
import "./Home.scss"
const Home = () => {
  return( 
<div className="home-container">
  <p style={{ fontSize: '2rem', fontWeight: 'bold', textAlign: 'center', color: '#333' }}>Para criar/incluir um novo jogo clique no card correspondente:</p>
  
    <div className="body-container">
       <CardAction to="/carimbo" label='CARIMBÓ' icon={carimbo} />
       <CardAction disabled={true} label='AZUVER' icon={azuver} ModalComponent={ModalGame} />
       <CardAction disabled={true} label='MAHJID' icon={mahjid} ModalComponent={ModalGame} />
       
       
    </div>
     <InfoBoard/>
</div>
  );
};

export default Home;
