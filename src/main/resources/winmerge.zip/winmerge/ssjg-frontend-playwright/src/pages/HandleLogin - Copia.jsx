// src/components/HandleLogin.jsx
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Cookies from 'js-cookie';
import { authService } from '../services/authService';
import ssjgLogo from "../assets/img/ssjg.png";
import marinhaLogo from "../assets/img/marinha.gif";
import brasaoLogo from "../assets/img/brasao.png";
import BoxForm from "../components/Boxform/BoxForm.jsx";

const HandleLogin = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState(null);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = async (e) => {
    e.preventDefault();
    
    if (!username || !password) {
      setErrorMessage('Usuário e senha são obrigatórios');
      return;
    }
    
    setLoading(true);
    setErrorMessage(null);
    
    try {
      // Chama a API real
      const response = await authService.login(username, password);
      
      if (response?.accessToken) {
        console.log('✅ Login realizado com sucesso');
        
        // Opcional: salvar informações do usuário
        if (response.name) {
          localStorage.setItem('user_name', response.name);
        }
        
        // Redireciona para home
        navigate('/home', { replace: true });
      } else {
        throw new Error('Falha na autenticação');
      }
      
    } catch (error) {
      console.error('Erro no login:', error);
      setErrorMessage(error.message || 'Erro na autenticação. Verifique suas credenciais.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-container">
      <div className="login-header-logos">
        <img src={marinhaLogo} alt="Logo Marinha" />
        <img src={brasaoLogo} alt="Logo Brasão" />
        <img src={ssjgLogo} alt="Logo SSJG" />
      </div>

      <BoxForm logo={ssjgLogo} title="Sistema Simulador para Jogos de Guerra">
        <form onSubmit={handleLogin} className="login-form">
          <p>
            Para acessar o sistema, informe suas credenciais.
          </p>
          
          {/* <div className="form-group">
            <label htmlFor="username">Usuário</label>
            <input
              type="text"
              id="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              disabled={loading}
              placeholder="Digite seu usuário"
              data-testid="username-input"
            />
          </div>
          
          <div className="form-group">
            <label htmlFor="password">Senha</label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              disabled={loading}
              placeholder="Digite sua senha"
              data-testid="password-input"
            />
          </div> */}

          <button 
            type="submit"
            disabled={loading}
            data-testid="login-button"
          >
            {loading ? 'Autenticando...' : 'Autenticar'}
          </button>
          
          {errorMessage && (
            <div className="error-card" data-testid="login-error">
              {errorMessage}
            </div>
          )}
        </form>
      </BoxForm>
    </div>
  );
};

export default HandleLogin;