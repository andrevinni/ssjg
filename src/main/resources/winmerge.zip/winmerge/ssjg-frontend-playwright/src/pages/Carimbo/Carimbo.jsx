import addButton from '../../assets/img/adicionar.svg'
import carimbo from '../../assets/img/carimbo.png'
import {CardAction} from "../../components/CardAction/CardAction.jsx"
import { ModalGame } from "../../components/ModalGame/ModalGame.jsx";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Carimbo.scss"
const Carimbo = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [jogos, setJogos] = useState([]);
  const [hoveredIndex, setHoveredIndex] = useState(null);
  const navigate = useNavigate()


  const handleCreateGame = (novoJogo) => {
    setJogos([...jogos, novoJogo]);
    setIsOpen(false);
  };

const handleGoBack =()=>{
  navigate("/home")
}

  return (
      <div className="new-game">
         <button className="back-btn-home" onClick={handleGoBack} title="Voltar para Home">
        ⬅
      </button>
      {/* Card Novo Jogo */}
       <CardAction
        className="add-button-card"
        label="Adicionar Novo Jogo"
        icon={addButton}
        onClick={() => setIsOpen(true)} // abre a modal
      />

      {/* Modal */}
      {isOpen && (<ModalGame setIsOpen={setIsOpen} onCreate={handleCreateGame} />)}
     
     {/* Cards de Jogos Criados */}
       <div className="carimbo-jogos">
        {jogos.map((jogo, index) => (
          <div
            key={index}
            className="carimbo-card-wrapper"
            onMouseEnter={() => setHoveredIndex(index)}
            onMouseLeave={() => setHoveredIndex(null)}
          >
          <CardAction
            className="carimbo-card"
            key={index}
            label={ 
                <>
                <div className="card-label">
                <div>{jogo.nome}</div>
                <div>Versão: {jogo.versao}</div>
                <div>Data: {jogo.data}</div>
                </div>
                </>
                }
            icon={carimbo}
            onClick={() =>  navigate(`mapa/${index}`, { state: { jogo } }) // passa o jogo via state
            }
          />
           {hoveredIndex === index && (
              <div className="carimbo-card-buttons">
                <button className="carimbo-btn-editar">Editar</button>
                <button className="carimbo-btn-excluir">Excluir</button>
              </div>
            )}
            </div>
        ))}
      </div>
    </div>
  );
};

export default Carimbo;
