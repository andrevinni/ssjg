import React from "react";
import "./Pagination.scss"
const Pagination = ({ currentPage, totalPages, onPageChange }) => {
  const handlePrev = () => {
    if (currentPage > 1) onPageChange(currentPage - 1);
  };

  const handleNext = () => {
    if (currentPage < totalPages) onPageChange(currentPage + 1);
  };

  return (
    <div className="pagination-container">
      <button
        onClick={handlePrev}
        disabled={currentPage === 1}
        className="pagination-button"
      >
        ◀
      </button>
      <span className="pagination-text">
        Página {currentPage} de {totalPages}
      </span>
      <button
        onClick={handleNext}
        disabled={currentPage === totalPages}
       className="pagination-button"
      >
        ▶
      </button>
    </div>
  );
};

export default Pagination;
