import React, { useState } from "react";
import "./CardAction.scss";
import { ModalGame } from "../ModalGame/ModalGame";
import { useNavigate } from "react-router-dom";


 export const CardAction = ({to, disabled, label,icon, onClick, className}) => {
  const navigate = useNavigate();
  const [isOpen, setIsOpen] = useState(false);

const handleClick = () => {
    if (!disabled) {
      setIsOpen(true);
    }
    if (onClick) {
      onClick(); // abrir mapa
      return;
    }
     if (to) {
      navigate(to); // navegação para página
    }
  };
  return (
    <>
      <div  className={`novo-exercicio-card ${disabled ? "disabled" : ""}  ${className || ""}`} onClick={handleClick} >
        <img src={icon} alt={label}  className="card-icon"/>
        <span>{label}</span>
      </div>

      {!disabled && isOpen &&  !onClick && (
      <ModalGame   setIsOpen={setIsOpen}/>
      )}
    </>
  );
};