import React, { useState, useEffect } from "react";
import "./ModalMeios.scss";
import Pagination from "../Pagination/Pagination.jsx"
import fragata from "../../assets/img/fragata.png"
import lancha from "../../assets/img/lancha.png"
import Feature from "ol/Feature";
import Point from "ol/geom/Point";
import Style from "ol/style/Style";
import Icon from "ol/style/Icon";
import VectorSource from "ol/source/Vector";
import VectorLayer from "ol/layer/Vector";
import { SearchBar } from '../SearchBar/SearchBar.jsx';
import { toLonLat, fromLonLat } from "ol/proj"; // opcional, se transformar coords

const mockSymbols = [
  { id: 1, name: "F43", code: "Navio", iconUrl: fragata},
  { id: 2, name: "2 ERC", code: "Op Esp", iconUrl: lancha },
];

const tabs = ["Plataformas", "Instalações", "Feições de Controle", "Outras Configurações"];

const categories = [
  "Navios",
  "Aeronaves",
  "Submarinos",
];

const ModalMeios = ({map, onClose }) => {
  const [activeTab, setActiveTab] = useState("Plataformas");
  const [search, setSearch] = useState("");
  const [expandedCategory, setExpandedCategory] = useState("Navios");
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedSymbol, setSelectedSymbol] = useState(null);

  const itemsPerPage = 4;

  const filteredSymbols = mockSymbols.filter((sym) =>
    sym.name.toLowerCase().includes(search.toLowerCase())
  );

  
  const totalPages = Math.ceil(filteredSymbols.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const currentSymbols = filteredSymbols.slice(startIndex, startIndex + itemsPerPage);

// Quando o usuário clicar no símbolo → entra em "modo inserção"
  const handleSymbolClick = (symbol) => {
    setSelectedSymbol(symbol);
  };

  // Quando há símbolo selecionado, escuta cliques no mapa
  useEffect(() => {
    if (!map || !selectedSymbol) return;

    const handleMapClick = (event) => {
      const coordinate = event.coordinate;
      console.log("Coordenadas:", coordinate);

      const feature = new Feature({
        geometry: new Point(coordinate),
        name: selectedSymbol.name,
      });

      const iconStyle = new Style({
        image: new Icon({
          src: selectedSymbol.iconUrl,
          scale: 0.5, // aumenta visibilidade
        }),
      });

      feature.setStyle(iconStyle);

      const vectorSource = new VectorSource({ features: [feature] });
      const vectorLayer = new VectorLayer({ source: vectorSource });
      map.addLayer(vectorLayer);

      setSelectedSymbol(null); // sai do modo de inserção
    };

    map.on("click", handleMapClick);

    return () => {
      map.un("click", handleMapClick);
    };
  }, [map, selectedSymbol]);

 const toggleCategory = (category) => {
    setExpandedCategory((prev) => (prev === category ? null : category));
  };

  const handleSearch = (query) => {
    console.log("Buscando por:", query);
  };

  return (
    <div className="modal-meios">
      <div className="modal-container">
        {/* Header */}
        <div className="modal-header">
          <h3>Inserir Objeto</h3>
          <button className="close-btn" onClick={onClose}>×</button>
        </div>

        {/* Tabs */}
        <div className="tab-row">
          {tabs.map((tab) => (
            <button
              key={tab}
              className={`tab-btn ${activeTab === tab ? "active" : ""}`}
              onClick={() => setActiveTab(tab)}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Search + Action */}
        <div className="actions-row">
            {activeTab !== "Plataformas" &&( <button className="new-btn">＋ Novo {activeTab}</button>)}
         
          <SearchBar onSearch={handleSearch} />
        </div>

       {/* Conteúdo principal */}
        {activeTab === "Plataformas" && (
          <div className="categories-list">
            {categories.map((category) => (
              <div key={category} className="category-section">
                <div
                  className={`category-header ${expandedCategory === category ? "active" : ""}`}
                  onClick={() => toggleCategory(category)}
                >
                  <span>{category}</span>
                  <span>{expandedCategory === category ? "▲" : "▼"}</span>
                </div>

                {expandedCategory === category && (
                  <div className="category-content">
                    <div className="actions-row">
                      <button className="new-btn">＋ Adicionar {category}</button>
                    </div>

                    <div className="symbol-grid">
                      {currentSymbols.map((sym) => (
                        <div
                          key={sym.id}
                          className={`symbol-card ${
                            selectedSymbol?.id === sym.id ? "selected" : ""
                          }`}
                          onClick={() => handleSymbolClick(sym)}
                        >
                         <div className="symbol-icon">
                            <img src={sym.iconUrl} alt={sym.name} className="icon-img" />
                          </div>
                          <p className="symbol-name">{sym.name}</p>
                        </div>
                      ))}
                    </div>
                    {/* Paginação */}
                    <Pagination
                      currentPage={currentPage}
                      totalPages={totalPages}
                      onPageChange={setCurrentPage}
                    />
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {/* Footer */}
        <div className="modal-footer">
          <button className="close-footer-btn" onClick={onClose}>
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
};

export default ModalMeios;
