import { useEffect, useRef, useState } from "react";
import 'ol/ol.css';
import { Map, View } from 'ol';
import TileLayer from 'ol/layer/Tile';
import OSM from 'ol/source/OSM';
import "./MapGame.scss"
import ModalMeios from "../ModalMeios/ModalMeios";
import inserirObjeto from "../../assets/img/inserirObj.png"
import { useNavigate } from "react-router-dom";

export const MapGame = () => {
  const navigate = useNavigate();
  const mapRef = useRef();
  const [map, setMap] = useState(null);
  const [showModal, setShowModal] = useState(false);
  useEffect(() => {
    if (!mapRef.current) return; // só inicializa se o div existe

    const mapInstance = new Map({
      target: mapRef.current,
      layers: [
        new TileLayer({
          source: new OSM(),
        }),
      ],
      view: new View({
        center: [0, 0], // pode converter latitude/longitude
        zoom: 2,
      }),
      controls: [],
    });
    setMap(mapInstance)
    // Limpa o mapa ao desmontar
    return () => mapInstance.setTarget(null);
  }, []);

  const toggleModal = () => {
    setShowModal((prev) => !prev); // alterna entre true/false
  };
  const handleGoBack =()=>{
    navigate("/carimbo")
  }

   return (
    <div className="map-wrapper">
      <div ref={mapRef} className="map-container" />
      {/* Botão flutuante de voltar */}
      <button className="back-btn" onClick={handleGoBack} title="Voltar para Carimbo">
        ⬅
      </button>
      {/* Botão flutuante de símbolos */}
      <button className="symbol-btn" onClick={toggleModal} title="Inserir Objetos">
        <img src={inserirObjeto} alt="Símbolos" className="symbol-icon-img" />
      </button>

      {/* Modal com os símbolos */}
      {showModal && <ModalMeios map={map} onClose={() => setShowModal(false)} />}
    </div>
  );
};
