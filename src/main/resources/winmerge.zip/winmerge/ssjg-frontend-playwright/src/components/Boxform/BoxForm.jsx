import React from "react";
import "./BoxForm.scss"
const BoxForm = ({ logo, title, children }) => {
  return (
    <div className="box-form">
      <div className="login-header">
        <img src={logo}  className="ssjg-img" />
        <h2>{title}</h2>
      </div>
      {children}
    </div>
  );
};

export default BoxForm;