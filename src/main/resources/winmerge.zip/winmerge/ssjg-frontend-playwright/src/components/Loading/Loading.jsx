import "./Loading.scss";

const Loading = ({ message = "Loading...", fullScreen = false }) => {
  return (
    <div className={`loading ${fullScreen ? "fullscreen" : ""}`}>
      <div className="spinner" />
      <span className="loading-message">{message}</span>
    </div>
  );
};

export default Loading;
