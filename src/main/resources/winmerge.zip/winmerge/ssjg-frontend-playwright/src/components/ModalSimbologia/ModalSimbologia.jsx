import { useEffect, useState } from "react";
import {getDimensoes, getSimbologiaPorDimensao } from "../../api/simbologia";
import "./modalSimbologia.scss";
import { SymbolItem } from '../../components/SymbolItem/SymbolItem.jsx';
import { showSidc } from "../../utils/showSidc";
import CustomSelect from "../DropdownSimbol/CustomSelect.jsx";
import {SIDC_PADRAO } from "../../utils/sidcPadrao.jsx";
import { buildSidc } from "../../utils/buildSidc.jsx";
import { resetModalSimbologia } from "../../utils/resetModalSimbologia.jsx";
export default function ModalSimbologia({ open, onClose }) {
  const [dimensoes, setDimensoes] = useState([]);
  const [selectedDimensao, setSelectedDimensao] = useState("");

  const [iconeCentral, setIconeCentral] = useState("");
  const [mod1, setMod1] = useState(null);
  const [mod2, setMod2] = useState(null);


  const [iconesCentrais, setIconesCentrais] = useState([]);
  const [primeirosMods, setPrimeirosMods] = useState([]);
  const [segundosMods, setSegundosMods] = useState([]);

  const [sidc, setSidc] = useState(showSidc(SIDC_PADRAO));

  const [extensoes, setExtensoes] = useState({
  iconeCentral: 0,
  mod1: 0,
  mod2: 0
});


  // Carrega API
  useEffect(() => {
    async function load() {
      const lista = await getDimensoes();

       const listaComSidcFinal = lista.map(item => ({
        ...item,
        sidcFinal: item.sidcFinal ?? showSidc(item.sidc)
      }));
      setDimensoes(listaComSidcFinal);
    }
    load();
  }, []);

  // Objeto da dimensão selecionada
  const dimSelecionada = dimensoes.find(d => d.dimensao === selectedDimensao);

  // Monta SIDC final
 useEffect(() => {
  const base = dimSelecionada?.sidc ?? SIDC_PADRAO;

  const identExtensaoFinal = calcularExtensaoFinal(extensoes);

  const novoSidcObj = {
    ...base,
    iconeCentral: iconeCentral || base.iconeCentral,
    primeiroModificador: mod1 != null ? mod1.split("-")[0] : base.primeiroModificador,
    segundoModificador: mod2 != null ? mod2.split("-")[0] : base.segundoModificador,
    identExtensao: identExtensaoFinal
  };

  setSidc(showSidc(novoSidcObj));
}, [iconeCentral, mod1, mod2, extensoes, dimSelecionada]);


  useEffect(() => {
  if (!selectedDimensao) return;

  async function loadSimbologia() {
    const data = await getSimbologiaPorDimensao(selectedDimensao);

    setIconesCentrais(data.iconeCentral);
    setPrimeirosMods(data.primeiroModificador);
    setSegundosMods(data.segundoModificador);

    // reset seleções ao trocar dimensão
    setIconeCentral("");
    setMod1(null);
    setMod2(null);
  }

  loadSimbologia();
}, [selectedDimensao]);


  if (!open) return null;

 const itemPreview = {
  sidcFinal: sidc
 };

 const resetModal = ()=>{
 resetModalSimbologia({
  setSelectedDimensao,
  setIconeCentral,
  setMod1,
  setMod2,
  setIconesCentrais,
  setPrimeirosMods,
  setSegundosMods,
  setSidc,
  setExtensoes
 });

 }

 function calcularExtensaoFinal(ext) {
  return (
    ext.iconeCentral +
    ext.mod1 +
    ext.mod2
  ).toString().padStart(7, "0");
}


  return (
    <div className="modal-overlay">
      <div className="modal-box">

        <div className="modal-header">
          <h2>CADASTRAR - SÍMBOLOS</h2>
          <button className="close-btn" onClick={()=>{resetModal(), onClose()}}>✖</button>
        </div>

        <div className="modal-grid">

          <div className="form-area">
            <input
              className="modal-input"
              placeholder="Nome *"
            />
         <div className="field-container">
           <legend>Dimensão *</legend>
           <CustomSelect
           items={dimensoes}
           selected={selectedDimensao}
           onChange={(value) => setSelectedDimensao(value)}
           getSidc={item => item.sidcFinal}
           />
          </div>   
          <div className="field-container">
           <legend>Icone Central</legend>
           <CustomSelect
             items={iconesCentrais}
             selected={iconeCentral}
             onChange={(codigo) => {
                const item = iconesCentrais.find(i => i.codigo === codigo);
                setIconeCentral(codigo);
                setExtensoes(prev => ({
                 ...prev,
                iconeCentral: Number(item?.identExtensao || 0)
               }));
              }}
             getKey={item => item.codigo}
             getLabel={item => item.nome}
             getSidc={item =>
             buildSidc({
              base: dimSelecionada?.sidc ?? SIDC_PADRAO,
              iconeCentral: item.codigo,
              identExtensao: calcularExtensaoFinal({
               ...extensoes,
              iconeCentral: Number(item.identExtensao || 0)
             })
             })
             }
           />

          </div>
          <div className="field-container">
           <legend>Primeiro Modificador</legend>
           <CustomSelect
           items={primeirosMods}
           selected={mod1}
          onChange={(key) => {
            const item = primeirosMods.find(i => `${i.codigo}-${i.identExtensao}` === key);
            setMod1(key);
            setExtensoes(prev => ({
             ...prev,
             mod1: Number(item?.identExtensao || 0)
            }));
          }}
          getKey={item => `${item.codigo}-${item.identExtensao}`}
          getLabel={item => item.nome}
          getSidc={item =>
          buildSidc({
           base: dimSelecionada?.sidc ?? SIDC_PADRAO,
           iconeCentral,
           primeiroModificador: item.codigo,
           identExtensao: calcularExtensaoFinal({
             ...extensoes,
            mod1: Number(item.identExtensao || 0)
         })
         })
         }
        />
            </div>

           <div className="field-container">
           <legend>Segundo Modificador</legend>
            <CustomSelect
             items={segundosMods}
             selected={mod2}
             onChange={(key) => {
              const item = segundosMods.find(
              i => `${i.codigo}-${i.identExtensao}` === key
              );
             setMod2(key);
             setExtensoes(prev => ({
             ...prev,
             mod2: Number(item?.identExtensao || 0)
             }));
             }}
              getKey={item => `${item.codigo}-${item.identExtensao}`}
              getLabel={item => item.nome}
              getSidc={item =>
               buildSidc({
                base: dimSelecionada?.sidc ?? SIDC_PADRAO,
                iconeCentral,
                primeiroModificador: mod1 ? mod1.split("-")[0] : undefined,
                segundoModificador: item.codigo,
                identExtensao: calcularExtensaoFinal({
                ...extensoes,
                mod2: Number(item.identExtensao || 0)
               })
             })
             }
             />

            </div>


            <div className="btn-row">
              <button className="btn-outline" onClick={onClose}>Fechar</button>
              <button className="btn-primary">Salvar</button>
            </div>
          </div>

          {/* PREVIEW */}
          <div className="symbol-box">
           <SymbolItem item={itemPreview} />
           <span className="sidc-text">{sidc}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
