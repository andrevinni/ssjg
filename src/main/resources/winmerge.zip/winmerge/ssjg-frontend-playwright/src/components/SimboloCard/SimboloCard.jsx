import { useMakeSymbol } from "../../utils/makeSymbol";
import './simboloCard.scss'
const SimboloCard = ({ simbolo, simboloSelect, onClick  }) => {
  const imagem = useMakeSymbol(simbolo.sidcFinal);

    return (
    <div
      className={`simbolo-card ${simboloSelect ? "selected" : ""}`}
      onClick={onClick}
    >
      {imagem && <img src={imagem} alt={simbolo.nome} />}
      <strong>{simbolo.nome}</strong>
    </div>
  );
};

export default SimboloCard;
