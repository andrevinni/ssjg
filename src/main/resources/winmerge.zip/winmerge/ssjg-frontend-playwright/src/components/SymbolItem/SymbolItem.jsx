
import { useMakeSymbol } from "../../utils/makeSymbol";
import './SymbolItem.scss'
export const SymbolItem = ({ item }) => {
console.log("###", item)
const simboloPNG = useMakeSymbol(item?.sidcFinal ?? null);

console.log("simboloPNG",simboloPNG)
  return (
    <div class='symbol-row'>
      {simboloPNG && <img src={simboloPNG} alt={item.nome} />}
      <p>{item.nome}</p>
    </div>
  );
};
