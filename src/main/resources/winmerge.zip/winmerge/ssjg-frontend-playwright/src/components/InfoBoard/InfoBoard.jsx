import React from "react";
import "./InfoBoard.scss";

export const InfoBoard = () => {
  const notices = [
    "O sistema ficará indisponível no dia 10/10 para manutenção.",
    "Lembre-se de atualizar seu cadastro até o fim do mês.",
    "Nova versão disponível! Confira as melhorias na aba Atualizações.",
  ];

  return (
    <div className="notice-board">
      <h2 className="notice-title">📢   Quadro de  Avisos</h2>
      <ul className="notice-list">
        {notices.map((notice, index) => (
          <li key={index} className="notice-item">
            {notice}
          </li>
        ))}
      </ul>
    </div>
  );
};
