import React, {useState} from "react";
import "./SearchBar.scss"
import searchIcon from"../../assets/img/search.png"
export const SearchBar =({
    placeholder = "Buscar...",
  buttonLabel = "Buscar",
  onSearch,
  icon = searchIcon,
  className = "",
  defaultValue = "",})=>{
    const [searchValue, setSearchValue] = useState(defaultValue);
    const handleSubmit = (e) =>{
       e.preventDefault();
        if(onSearch){
            onSearch(searchValue);
        }
    }
return(
    <form className={`search-bar ${className}`} onSubmit={handleSubmit}> 
        <input
        type="text"
        name="search"
        placeholder={placeholder}
        className="search-input"
        value={searchValue}
        onChange={(e) => setSearchValue(e.target.value)}
        />
        <button type="submit" className="search-button">
        {icon ? (
        <img src={searchIcon} alt="Buscar" className="search-icon" />
        ) : (
        buttonLabel
        )}
      </button>
    </form>
)
}