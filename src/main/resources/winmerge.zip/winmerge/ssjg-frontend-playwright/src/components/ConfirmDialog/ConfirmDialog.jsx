import "./ConfirmDialog.scss";

const ConfirmDialog = ({
  open,
  title = "Confirmar ação",
  message = "Tem certeza?",
  onConfirm,
  onCancel
}) => {
  if (!open) return null;

  return (
    <div className="confirm-overlay">
      <div className="confirm-box">
        <h3>{title}</h3>
        <p>{message}</p>

        <div className="confirm-actions">
          <button className="cancel" onClick={onCancel}>
            Cancelar
          </button>

          <button className="confirm" onClick={onConfirm}>
            Excluir
          </button>
        </div>
      </div>
    </div>
  );
};

export default ConfirmDialog;
