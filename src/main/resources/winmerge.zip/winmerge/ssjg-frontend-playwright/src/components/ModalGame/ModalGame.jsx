import { useState } from "react";
import "./ModalGame.scss"
export const ModalGame = ({ setIsOpen, onCreate }) => {
  const [form, setForm] = useState({ nome: "", versao: "", data: "" });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const isFormValid = form.nome && form.versao && form.data;

  const handleSubmit = (e) => {
    e.preventDefault();
    if (isFormValid) {
      onCreate(form);
      setForm({ nome: "", versao: "", data: "" });
    }
  };
  return (
     <div className="modal-overlay" onClick={() => setIsOpen(false)}>
      <div
        className="modal-content"
        onClick={(e) => e.stopPropagation()}
      >
        <h2 className="modal-title">Criar Novo Jogo</h2>

        <form onSubmit={handleSubmit}>
          <label htmlFor="nome">Nome do Jogo</label>
          <input
            type="text"
            name="nome"
            value={form.nome}
            onChange={handleChange}
            placeholder="Digite o nome do jogo"
          />

          <label htmlFor="versao">Versão</label>
          <input
            type="text"
            name="versao"
            value={form.versao}
            onChange={handleChange}
            placeholder="Ex: 1.0"
          />

          <label htmlFor="data">Data de Lançamento</label>
          <input
            type="date"
            name="data"
            value={form.data}
            onChange={handleChange}
          />

          <div className="modal-actions">
            <button
              type="button"
              onClick={() => setIsOpen(false)}
              className="btn btn-cancel"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={!isFormValid}
              className="btn btn-create"
            >
              Criar
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
