import React, { useState } from "react";
import { useAuth } from "react-oidc-context";
import { User, LogOut } from "lucide-react";
import "./UserMenu.scss";

export const UserMenu = () => {
  const auth = useAuth();
  const [open, setOpen] = useState(false);

  const handleLogout = () => {
    auth.removeUser();
    auth.signoutRedirect();
    window.location.replace("/");
  };

  const userName = auth?.user?.profile?.name || "Usuário";
  const firstName= userName.trim().split(/\s+/)[0];
  return (
    <div className="user-menu">
      {/* Botão principal */}
      <button className="user-menu-btn" onClick={() => setOpen(!open)}>
        <User className="user-icon" />
        <span className="user-name">Olá, {firstName}</span>
      </button>

      {/* Dropdown */}
      {open && (
        <div className="user-dropdown">
          <button className="dropdown-item logout" onClick={handleLogout}>
            <LogOut className="dropdown-icon" />
            Sair
          </button>
        </div>
      )}
    </div>
  );
};
