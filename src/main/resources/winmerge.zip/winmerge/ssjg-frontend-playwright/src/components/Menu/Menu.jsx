import React, { useState } from "react"
import { useNavigate } from "react-router-dom";
import "./Menu.scss"

export const Menu = () => {
  const navigate = useNavigate();

  const [isOpen, setIsOpen] = useState(false);
  const [openParent, setOpenParent] = useState(null);

  // Estrutura de menus
  const menuData = [
    {
      id: "equipamentos",
      label: "Equipamentos",
      children: ["Sensores"],
    },
    {
      id: "simbolos",
      label: "Símbolos",
      children: [],
    },
    {
      id: "avisos",
      label: "Avisos",
      children: [],
    },
  ];

  const toggleParent = (id) => {
    // Abre modal de simbolos
    if (id === "simbolos") {
      navigate("/simbolos");
      setIsOpen(false); // fecha menu lateral
      return;
    }
    setOpenParent(openParent === id ? null : id);
  };

  return (
     <>
      <div className="box-menu">
        {/* Botão hamburguer */}
        <button
          className={`menu ${isOpen ? "active" : ""}`}
          onClick={() => setIsOpen(!isOpen)}
        >
          <span></span>
          <span></span>
          <span></span>
        </button>

        {/* Menu lateral */}
        {isOpen && (
          <nav className="side-menu">
            <button className="close-btn" onClick={() => setIsOpen(false)}>
              ✕
            </button>
            <ul>
              {menuData.map((item) => (
                <li key={item.id}>
                  {/* Pai */}
                  <div
                    className="parent"
                    onClick={() => toggleParent(item.id)}
                  >
                    {item.label}
                    <span>
                      {item.children.length > 0
                        ? openParent === item.id
                          ? "▲"
                          : "▼"
                        : null}
                    </span>
                  </div>

                  {/* Filhos */}
                  {openParent === item.id && item.children.length > 0 && (
                    <ul className="submenu">
                      {item.children.map((child, i) => (
                        <li key={i}>{child}</li>
                      ))}
                    </ul>
                  )}
                </li>
              ))}
            </ul>
          </nav>
        )}
      </div>
    </>
  );
};
