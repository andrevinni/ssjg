const env = import.meta.env.MODE;

const redirectUrls = {
  development: import.meta.env.VITE_LOGIN_URL_DEV,
  production: import.meta.env.VITE_LOGIN_URL_PROD,
};

export const getLoginRedirectUrl = () => {
  return redirectUrls[env] || redirectUrls.development;
};