/**
 * App.jsx
 * ─────────────────────────────────────────────────────────────────
 * AuthProvider deve envolver as rotas pois usa useNavigate internamente.
 * ─────────────────────────────────────────────────────────────────
 */
import React from 'react';
import { BrowserRouter } from 'react-router-dom';
import { AuthProvider }  from './auth/AuthContext';
import { AppRoutes }     from './routes/AppRoutes';

const App = () => (
  <BrowserRouter>
    <AuthProvider>
      <AppRoutes />
    </AuthProvider>
  </BrowserRouter>
);

export default App;
