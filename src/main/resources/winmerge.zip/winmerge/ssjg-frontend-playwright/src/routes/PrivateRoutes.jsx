/**
 * PrivateRoutes.jsx
 * ─────────────────────────────────────────────────────────────────
 * Proteção de rotas baseada no AuthContext.
 * Remove dependência do react-oidc-context.
 * ─────────────────────────────────────────────────────────────────
 */
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';
import Loading from '../components/Loading/Loading';

export const PrivateRoute = ({ children }) => {
  const { isAuthenticated, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return <Loading fullScreen />;
  }

  if (!isAuthenticated) {
    return <Navigate to="/" state={{ from: location }} replace />;
  }

  return children;
};
