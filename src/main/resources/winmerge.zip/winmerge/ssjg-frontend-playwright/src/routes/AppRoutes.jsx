import React from "react";
import { useRoutes } from "react-router-dom";
import { listaDeRotas } from "./ListaDeRotas";

export const AppRoutes = () => {
 const element = useRoutes(listaDeRotas);
 return element;
};