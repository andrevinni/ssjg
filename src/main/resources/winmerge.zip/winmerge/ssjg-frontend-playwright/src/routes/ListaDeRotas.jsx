import Login from "../pages/Login";
import Callback from "../pages/Callback";
import Home from "../pages/Home/Home";
import Carimbo from "../pages/Carimbo/Carimbo";
import Layout from "../pages/Layout";
import MapScreen from "../pages/MapScreen"
import { PrivateRoute } from "./PrivateRoutes";
import SimbolosPage from "../pages/SimbolosPage/SimbolosPage";

export const listaDeRotas = [

  { path: "/", element: <Login />, title: "Login" },
  { path: "/callback", element: <Callback />, title: "Callback" },

  {
    element: <Layout />,
    children: [
      { path: "home", element: <PrivateRoute><Home /></PrivateRoute>, title: "Home" },
      { path: "carimbo", element: <PrivateRoute><Carimbo /></PrivateRoute>, title: "Carimbo" },
      { path: "simbolos", element: ( <PrivateRoute><SimbolosPage /> </PrivateRoute>), title: "Símbolos"},
    ],
  },
   { path: "carimbo/mapa/:jogoIndex", element: <PrivateRoute><MapScreen /></PrivateRoute>, title: "Mapa" },
];