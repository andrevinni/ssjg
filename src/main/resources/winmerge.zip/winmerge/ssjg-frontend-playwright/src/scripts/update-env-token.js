// scripts/update-env-token.js
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Credenciais - mantenha em sigilo
const USERNAME = 'seu_usuario_aqui';  // ✅ Substitua pelo usuário real
const PASSWORD = 'sua_senha_aqui';    // ✅ Substitua pela senha real

async function updateEnvToken() {
  try {
    console.log('🔑 Gerando token...');
    
    // 1. Fazer requisição para obter token
    const response = await fetch('http://10.5.112.125:8082/ssjg-auth/api/v1/login/authenticate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        username: USERNAME,
        password: PASSWORD
      })
    });
    
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    
    const data = await response.json();
    const accessToken = data.accessToken;
    
    if (!accessToken) {
      throw new Error('Token não encontrado na resposta');
    }
    
    console.log('✅ Token obtido com sucesso!');
    console.log(`📝 Token: ${accessToken.substring(0, 50)}...`);
    
    // 2. Atualizar arquivo .env
    const envPath = path.join(__dirname, '..', '.env');
    let envContent = '';
    
    // Verifica se arquivo .env existe
    if (fs.existsSync(envPath)) {
      envContent = fs.readFileSync(envPath, 'utf-8');
    }
    
    // Atualiza ou adiciona VITE_DEV_TOKEN
    if (envContent.includes('VITE_DEV_TOKEN=')) {
      envContent = envContent.replace(
        /VITE_DEV_TOKEN=.*/,
        `VITE_DEV_TOKEN="${accessToken}"`
      );
    } else {
      envContent += `\nVITE_DEV_TOKEN="${accessToken}"\n`;
    }
    
    // Atualiza também outras variáveis úteis
    if (!envContent.includes('VITE_DEV_REFRESH_TOKEN=') && data.refreshToken) {
      envContent += `VITE_DEV_REFRESH_TOKEN="${data.refreshToken}"\n`;
    }
    
    if (!envContent.includes('VITE_API_BASEURL=')) {
      envContent += `VITE_API_BASEURL=http://10.5.112.125:8082/ssjg-auth/api/v1\n`;
    }
    
    fs.writeFileSync(envPath, envContent);
    console.log('✅ Token salvo no arquivo .env!');
    console.log('📍 Arquivo:', envPath);
    
  } catch (error) {
    console.error('❌ Erro ao atualizar token:', error.message);
    process.exit(1);
  }
}

updateEnvToken();