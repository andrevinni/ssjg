import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import "./styles/Login.scss";
import { AuthProvider } from "react-oidc-context";

//defineCustomElements(window);
window
const oidcConfig = {
  authority: import.meta.env.VITE_APP_OAUTH2_URL,
  scope: 'openid profile email',
  client_id: import.meta.env.VITE_APP_OAUTH2_CLIENT_ID,
  client_secret: import.meta.env.VITE_APP_OAUTH2_CLIENT_SECRET,
  redirect_uri: window.location.origin + "/callback",        // ← problema 2 aqui
  post_logout_redirect_uri: window.location.origin
};

// Log temporário para confirmar
console.log("OIDC Config:", oidcConfig);

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <AuthProvider {...oidcConfig}>
       <App />
    </AuthProvider>
  </React.StrictMode>
);
