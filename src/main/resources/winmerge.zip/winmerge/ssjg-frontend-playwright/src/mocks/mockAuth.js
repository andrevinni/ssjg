// src/mocks/mockAuth.js
export const useAuth = () => {
  console.log("🔥 MOCK ESTÁ SENDO USADO!");
  
  const doLogin = async () => {
    const username = "07935377707";
    const password = "M@rinha123!";
    
    // Pega do .env
    //const clientId = import.meta.env.VITE_APP_OAUTH2_CLIENT_ID || "app-ssjg";
    //const clientSecret = import.meta.env.VITE_APP_OAUTH2_CLIENT_SECRET;
    
    const apiUrl = "/ssjg-auth/api/v1/login/authenticate";
    
    const requestBody = {
      username: username,
      password: password
      //client_id: clientId,
      //client_secret: clientSecret
    };
    
    console.log("🚀 Enviando com client credentials");
    console.log("📡 URL:", apiUrl);
    console.log("📦 Body:", { ...requestBody, client_secret: "***" });
    
    try {
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify(requestBody)
      });
      
      console.log("📡 Status:", response.status);
      
      const data = await response.json();
      console.log("📦 Resposta:", data);
      
      const token = data.accessToken;
      
      if (token) {
        console.log("✅ LOGIN REALIZADO COM SUCESSO!");
        localStorage.setItem('access_token', token);
        window.location.href = '/home';
      } else {
        console.error("❌ Token não encontrado");
      }
    } catch (err) {
      console.error("❌ Erro:", err);
    }
  };
  
  return {
    isAuthenticated: localStorage.getItem('access_token') ? true : false,
    user: localStorage.getItem('access_token') ? { 
      access_token: localStorage.getItem('access_token'), 
      expired: false 
    } : null,
    activeNavigator: null,
    isLoading: false,
    error: null,
    events: {
      addAccessTokenExpired: () => {},
      removeAccessTokenExpired: () => {},
    },
    signinRedirect: doLogin,
    signinSilent: () => Promise.resolve(),
    signoutRedirect: () => {
      localStorage.removeItem('access_token');
      window.location.href = '/';
    },
    removeUser: () => {
      localStorage.removeItem('access_token');
    }
  };
};