// src/mocks/mockApi.js
export const mockAutenticateUserLogin = (token) => {
  console.log("🎭 MOCK: Validando token:", token.substring(0, 50) + "...");
  
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        success: true,
        message: "Autenticado com sucesso (mock)",
        user: {
          name: "Usuário Teste",
          username: "07935377707",
          authorities: ["ROLE_USER"]
        }
      });
    }, 500); // Simula delay de rede
  });
};