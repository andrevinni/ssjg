// src/mocks/mockAuth.js
export const useAuth = () => {
  console.log("🔥 MOCK ESTÁ SENDO USADO!");
  
  return {
    isAuthenticated: false,
    user: null,
    activeNavigator: null,
    isLoading: false,
    error: null,
    events: {
      addAccessTokenExpired: () => {},
      removeAccessTokenExpired: () => {},
    },
    signinRedirect: () => {
      const username = "07935377707";
      const password = "M@rinha123!";
      
      console.log("🚀 Iniciando login com:", { username });
      
      fetch('/ssjg-auth/api/v1/login/authenticate', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          username: username,
          password: password 
        })
      })
      .then(async (response) => {
        console.log("📡 Status:", response.status);
        
        const text = await response.text();
        console.log("📝 Resposta:", text);
        
        if (!text || text.trim() === '') {
          throw new Error("Resposta vazia");
        }
        
        try {
          const data = JSON.parse(text);
          console.log("✅ Dados parseados:", data);
          
          // CORREÇÃO: a chave é "accessToken" (com T maiúsculo)
          const token = data.accessToken;
          
          if (token) {
            console.log("✅ Token obtido com sucesso!");
            localStorage.setItem('access_token', token);
            // Força reload para atualizar o estado
            window.location.href = '/home';
          } else {
            console.error("❌ Token não encontrado. Dados recebidos:", data);
          }
        } catch (e) {
          console.error("❌ Erro ao parsear JSON:", e.message);
        }
      })
      .catch(err => {
        console.error("❌ Erro na requisição:", err);
      });
    },
    signinSilent: () => Promise.resolve(),
    signoutRedirect: () => {
      localStorage.removeItem('access_token');
      window.location.href = '/';
    },
    removeUser: () => {
      localStorage.removeItem('access_token');
    }
  };
};