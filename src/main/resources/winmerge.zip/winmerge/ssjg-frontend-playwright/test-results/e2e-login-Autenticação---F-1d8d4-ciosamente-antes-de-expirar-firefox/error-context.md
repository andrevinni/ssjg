# Page snapshot

```yaml
- generic [ref=e3]:
  - banner [ref=e4]:
    - button [ref=e6] [cursor=pointer]
    - generic [ref=e10]:
      - textbox "Buscar..." [ref=e11]
      - button "Buscar" [ref=e12] [cursor=pointer]:
        - img "Buscar" [ref=e13]
    - button "Olá, Usuário" [ref=e16] [cursor=pointer]:
      - img [ref=e17]
      - generic [ref=e20]: Olá, Usuário
  - main [ref=e21]:
    - generic [ref=e22]:
      - paragraph [ref=e23]: "Para criar/incluir um novo jogo clique no card correspondente:"
      - generic [ref=e24]:
        - generic [ref=e25] [cursor=pointer]:
          - img "CARIMBÓ" [ref=e26]
          - generic [ref=e27]: CARIMBÓ
        - generic:
          - img "AZUVER"
          - generic: AZUVER
        - generic:
          - img "MAHJID"
          - generic: MAHJID
      - generic [ref=e28]:
        - heading "📢 Quadro de Avisos" [level=2] [ref=e29]
        - list [ref=e30]:
          - listitem [ref=e31]: O sistema ficará indisponível no dia 10/10 para manutenção.
          - listitem [ref=e32]: Lembre-se de atualizar seu cadastro até o fim do mês.
          - listitem [ref=e33]: Nova versão disponível! Confira as melhorias na aba Atualizações.
```