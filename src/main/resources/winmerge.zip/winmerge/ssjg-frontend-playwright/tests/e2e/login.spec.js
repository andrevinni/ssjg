// tests/auth/login.spec.js
import { test, expect } from '@playwright/test';

test.describe('Autenticação - Fluxo Completo', () => {
  test.beforeEach(async ({ page }) => {
    // Configura interceptação de requisições mock
    await page.route('**/auth/refresh', async (route) => {
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({
          access_token: 'new_mock_token_' + Date.now(),
          expires_in: 3600
        })
      });
    });
  });

  test('deve realizar login com sucesso em modo mock', async ({ page }) => {
    await page.goto('/');
    
    // Preenche credenciais (usando CPF mock sugerido)
    await page.fill('#cpf', '529.982.247-25');
    await page.fill('#senha', '123456');
    
    // Clica em entrar
    await page.click('button[type="submit"]');
    
    // Aguarda redirecionamento
    await page.waitForURL('**/home');
    
    // Verifica se está autenticado (presença de elementos da home)
    await expect(page.locator('[data-testid="user-menu"]')).toBeVisible();
    
    // Verifica se o token foi armazenado no localStorage
    const tokens = await page.evaluate(() => {
      const accessToken = localStorage.getItem('access_token');
      const refreshToken = localStorage.getItem('refresh_token');
      const user = localStorage.getItem('user');
      return { accessToken, refreshToken, user };
    });
    
    expect(tokens.accessToken).toBeTruthy();
    expect(tokens.refreshToken).toBeTruthy();
    expect(tokens.user).toBeTruthy();
  });

  test('deve mostrar erro com credenciais inválidas', async ({ page }) => {
    await page.goto('/');
    
    await page.fill('#cpf', '529.982.247-25');
    await page.fill('#senha', 'senha_errada');
    await page.click('button[type="submit"]');
    
    // Verifica mensagem de erro
    await expect(page.locator('.error-card')).toBeVisible();
    await expect(page.locator('.error-card')).toContainText('Erro na autenticação');
    
    // Permanece na página de login
    await expect(page).toHaveURL('/');
  });

  test('deve renovar token silenciosamente antes de expirar', async ({ page }) => {
    // Mock do tempo e interceptação do refresh
    let refreshCalled = false;
    
    await page.route('**/auth/refresh', async (route) => {
      refreshCalled = true;
      await route.fulfill({
        status: 200,
        body: JSON.stringify({
          access_token: 'refreshed_token_' + Date.now(),
          expires_in: 3600
        })
      });
    });
    
    await page.goto('/');
    await page.fill('#cpf', '529.982.247-25');
    await page.fill('#senha', '123456');
    await page.click('button[type="submit"]');
    await page.waitForURL('**/home');
    
    // Força expiração do token manipulando o localStorage
    await page.evaluate(() => {
      const oldToken = localStorage.getItem('access_token');
      // Simula token expirado modificando timestamp
      const expiredToken = oldToken.replace(/exp=\d+/, 'exp=' + (Date.now() - 60000));
      localStorage.setItem('access_token', expiredToken);
    });
    
    // Dispara uma requisição que forçará o refresh
    await page.reload();
    
    // Aguarda o refresh acontecer
    await page.waitForTimeout(1000);
    
    // Verifica se o refresh foi chamado
    expect(refreshCalled).toBeTruthy();
    
    // Verifica se o token foi atualizado
    const newToken = await page.evaluate(() => localStorage.getItem('access_token'));
    expect(newToken).not.toBe(oldToken);
  });
});

test.describe('Controle de Inatividade', () => {
  test('deve redirecionar para login após inatividade', async ({ page }) => {
    // Mock do tempo de inatividade (reduzido para teste)
    await page.addInitScript(() => {
      // Sobrescreve a constante de timeout para testes
      window.__TEST_INACTIVITY_TIMEOUT = 2000; // 2 segundos
    });
    
    await page.goto('/');
    await page.fill('#cpf', '529.982.247-25');
    await page.fill('#senha', '123456');
    await page.click('button[type="submit"]');
    await page.waitForURL('**/home');
    
    // Aguarda o timeout de inatividade
    await page.waitForTimeout(2500);
    
    // Deve redirecionar para login com mensagem específica
    await page.waitForURL('/');
    
    // Verifica mensagem de inatividade
    const errorMessage = page.locator('.error-card');
    await expect(errorMessage).toContainText('Sessão encerrada por inatividade');
  });

  test('deve resetar timer de inatividade com interações', async ({ page }) => {
    let logoutTriggered = false;
    
    // Monitora redirecionamentos
    page.on('framenavigated', (frame) => {
      if (frame.url().includes('/')) {
        logoutTriggered = true;
      }
    });
    
    await page.goto('/');
    await page.fill('#cpf', '529.982.247-25');
    await page.fill('#senha', '123456');
    await page.click('button[type="submit"]');
    await page.waitForURL('**/home');
    
    // Move o mouse a cada 1.5 segundos para manter sessão ativa
    for (let i = 0; i < 5; i++) {
      await page.mouse.move(100, 100 + i * 50);
      await page.waitForTimeout(1500);
    }
    
    // Aguarda 3 segundos extras
    await page.waitForTimeout(3000);
    
    // Verifica que NÃO foi redirecionado
    expect(logoutTriggered).toBeFalsy();
    await expect(page).toHaveURL(/\/home/);
  });
});

test.describe('Persistência de Sessão', () => {
  test('deve restaurar sessão após recarregar página', async ({ page }) => {
    await page.goto('/');
    await page.fill('#cpf', '529.982.247-25');
    await page.fill('#senha', '123456');
    await page.click('button[type="submit"]');
    await page.waitForURL('**/home');
    
    // Armazena token original
    const originalToken = await page.evaluate(() => localStorage.getItem('access_token'));
    
    // Recarrega página
    await page.reload();
    
    // Deve permanecer na home
    await page.waitForURL('**/home');
    
    // Token deve ser o mesmo
    const restoredToken = await page.evaluate(() => localStorage.getItem('access_token'));
    expect(restoredToken).toBe(originalToken);
  });
});

test.describe('Cenários de Erro', () => {
  test('deve lidar com refresh token expirado', async ({ page }) => {
    await page.route('**/auth/refresh', async (route) => {
      await route.fulfill({
        status: 401,
        body: JSON.stringify({ error: 'Refresh token expired' })
      });
    });
    
    await page.goto('/');
    await page.fill('#cpf', '529.982.247-25');
    await page.fill('#senha', '123456');
    await page.click('button[type="submit"]');
    await page.waitForURL('**/home');
    
    // Força expiração e tenta renovar
    await page.evaluate(() => {
      localStorage.setItem('refresh_token', 'expired_token');
      localStorage.setItem('access_token', 'expired_token');
    });
    
    await page.reload();
    
    // Deve redirecionar para login
    await page.waitForURL('/');
    await expect(page.locator('.error-card')).toContainText(/sessão expirada|faça login/i);
  });
});