// @ts-check
import { test, expect } from '@playwright/test';
import { chromium } from 'playwright';

const browser = await chromium.launch({
  proxy: {
    server: 'http://proxy-1dn.cmb:6060',
    username: '03435069716',
    password: 'QAZwsx!edc2011'
  }
});

test('has title', async ({ page }) => {
  await page.goto('https://playwright.dev/');

  // Expect a title "to contain" a substring.
  await expect(page).toHaveTitle(/Playwright/);
});

test('get started link', async ({ page }) => {
  await page.goto('https://playwright.dev/');

  // Click the get started link.
  await page.getByRole('link', { name: 'Get started' }).click();

  // Expects page to have a heading with the name of Installation.
  await expect(page.getByRole('heading', { name: 'Installation' })).toBeVisible();
});
