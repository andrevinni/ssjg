# SSJG- Sistema Simulador para Jogos de Guerra

Este projeto é uma aplicação web desenvolvida com **React + Vite** que faz à simulação  de um jogo de guerra.

## 📁 Estrutura do Projeto
```bash
 ssjg-frontend/
│
├── public/ # Contém arquivos estáticos que são servidos diretamente sem processamento pelo Vite.
├── src/
│ ├──api/ # Armazena funções que chamam o backend.
│ ├── assets/ # Imagens e ícones usados no projeto
│ ├── components/ # Componentes reutilizáveis que podem ser usados em qualquer página
│ ├── config/ # Configurações globais do app
│ ├── pages/ # Páginas renderizadas nas rotas.
│ ├── routes/ # Gerencia todas as rotas da aplicação React
│ ├── styles/ # Estilos globais
│ ├── utils/ # Funções utilitárias, puras e reutilizáveis.
│ ├── app.js  # Componente principal da aplicação
│ └── main.jsx # Ponto de entrada do React/Vite
├── .gitignore  # Lista arquivos que o Git deve ignorar
├── eslint.config.js # Configurações de linting (padrões de código)
├── index.html # HTML principal do Vite
├── vite.config.js # Configurações do Vite
├── package.json  # Informações do projeto
└── README.md # Documentação do projeto
````
## 📦 Instalação
```bash
# 1. Clone o repositório
git clone https://github.com/seu-usuario/ssjg-frontend.git

cd ssjg-frontend

# 2. Clone o repositório
coloque a pasta .env.local, na raiz do projeto

# 3. Instale as dependências

npm install

# 4. Inicie o projeto localmente
npm run dev
```