// vite.config.js
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      '/ssjg-auth': {
        target: 'http://10.5.112.125:8082',
        changeOrigin: true,
        secure: false,
      }
    }
  }
})