--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4 (Debian 17.4-1.pgdg110+2)
-- Dumped by pg_dump version 17.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE bd_modelo;
--
-- Name: bd_modelo; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE bd_modelo WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE bd_modelo OWNER TO postgres;

\connect bd_modelo

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: dbo; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA dbo;


ALTER SCHEMA dbo OWNER TO postgres;

--
-- Name: tiger; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA tiger;


ALTER SCHEMA tiger OWNER TO postgres;

--
-- Name: tiger_data; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA tiger_data;


ALTER SCHEMA tiger_data OWNER TO postgres;

--
-- Name: topology; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA topology;


ALTER SCHEMA topology OWNER TO postgres;

--
-- Name: SCHEMA topology; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA topology IS 'PostGIS Topology schema';


--
-- Name: fuzzystrmatch; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS fuzzystrmatch WITH SCHEMA public;


--
-- Name: EXTENSION fuzzystrmatch; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION fuzzystrmatch IS 'determine similarities and distance between strings';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


--
-- Name: postgis_tiger_geocoder; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis_tiger_geocoder WITH SCHEMA tiger;


--
-- Name: EXTENSION postgis_tiger_geocoder; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis_tiger_geocoder IS 'PostGIS tiger geocoder and reverse geocoder';


--
-- Name: postgis_topology; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis_topology WITH SCHEMA topology;


--
-- Name: EXTENSION postgis_topology; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis_topology IS 'PostGIS topology spatial types and functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: acompanhamento; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.acompanhamento (
    id_acompanhamento integer NOT NULL,
    id_meiosimulado_um integer NOT NULL,
    id_meiosimulado_um_acompanhamento integer,
    latitudeposgeo numeric(15,9),
    longitudeposgeo numeric(15,9),
    marcacao numeric(15,9),
    distancia double precision,
    tipoacompanhamento integer,
    removida smallint,
    movimento integer,
    datahoratermino character varying(15)
);


ALTER TABLE dbo.acompanhamento OWNER TO postgres;

--
-- Name: acompanhamentomav; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.acompanhamentomav (
    id_meiosimulado integer NOT NULL,
    id_finalidade integer NOT NULL,
    id_acompanhado integer,
    datahoramovimento character varying(14)
);


ALTER TABLE dbo.acompanhamentomav OWNER TO postgres;

--
-- Name: area; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.area (
    id_meiosimulado integer NOT NULL,
    id_finalidade integer NOT NULL,
    tabelaarea character varying(50),
    situacao integer,
    movimento integer,
    eixo double precision NOT NULL,
    eixoacompanhamento double precision NOT NULL
);


ALTER TABLE dbo.area OWNER TO postgres;

--
-- Name: areaambiental; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.areaambiental (
    id_meiosimulado integer NOT NULL,
    diainicio double precision NOT NULL,
    horainicio double precision NOT NULL,
    id_previsaometeorologica integer NOT NULL,
    direcaovento character varying(2),
    horaporsol double precision NOT NULL,
    horanascersol double precision NOT NULL,
    profundidadecamada double precision NOT NULL,
    perfilsonoro character varying(50),
    propagacaoeletromagnetica character varying(50),
    percentagemceu character varying(50),
    temperaturamar double precision NOT NULL,
    horaporlua double precision NOT NULL,
    horanascerlua double precision NOT NULL,
    faselua character varying(50),
    rumocorrente integer,
    veloccorrente double precision
);


ALTER TABLE dbo.areaambiental OWNER TO postgres;

--
-- Name: areapoligonal; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.areapoligonal (
    id_meiosimulado integer NOT NULL
);


ALTER TABLE dbo.areapoligonal OWNER TO postgres;

--
-- Name: areasetorial; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.areasetorial (
    id_meiosimulado integer NOT NULL,
    limitedireito double precision NOT NULL,
    limiteesquerdo double precision NOT NULL,
    limiteinterno double precision NOT NULL,
    limiteexterno double precision NOT NULL
);


ALTER TABLE dbo.areasetorial OWNER TO postgres;

--
-- Name: armamento; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.armamento (
    id_armamento integer NOT NULL,
    nome character varying(50),
    tabelaarmamento character varying(50),
    cargaexplosiva double precision,
    observacao character varying(100),
    empregoarmamento character varying(50)
);


ALTER TABLE dbo.armamento OWNER TO postgres;

--
-- Name: armasas; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.armasas (
    id_armamento integer NOT NULL,
    numprojsalva integer NOT NULL,
    agentelancadorabrev character varying(10),
    alcancemaximo double precision,
    tipo_armasas character varying(50)
);


ALTER TABLE dbo.armasas OWNER TO postgres;

--
-- Name: base; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.base (
    id_base integer NOT NULL,
    nome character varying(50),
    tipobase character varying(50),
    tipobasenum integer,
    id_partido integer NOT NULL,
    extensaocais double precision,
    caladomaximo double precision,
    latitude numeric(15,9),
    longitude numeric(15,9),
    classereparo character varying(600),
    facilidadereparo character varying(600),
    fundeadnummaxnavio integer,
    fundeadcaladomax integer,
    capachangaragem double precision,
    observacao character varying(100),
    "Login" character varying(50)
);


ALTER TABLE dbo.base OWNER TO postgres;

--
-- Name: bomba; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.bomba (
    id_armamento integer NOT NULL,
    tipobomba character varying(50),
    agentelancadorabrev character varying(10),
    pai double precision,
    trigrama character varying(3),
    nomeguiagemabrev character varying(50),
    alcanceeficaz double precision
);


ALTER TABLE dbo.bomba OWNER TO postgres;

--
-- Name: canhao; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.canhao (
    id_armamento integer NOT NULL,
    calibretuboalma character varying(50),
    cadenciatiromantida integer NOT NULL,
    cadenciatirorapida integer NOT NULL,
    numtuboalma character varying(50),
    alcancemaximo double precision,
    alcanceeficaz double precision
);


ALTER TABLE dbo.canhao OWNER TO postgres;

--
-- Name: classeefetivapista; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.classeefetivapista (
    classe_atual integer NOT NULL,
    classe_efetiva integer NOT NULL
);


ALTER TABLE dbo.classeefetivapista OWNER TO postgres;

--
-- Name: codigoerros; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.codigoerros (
    codigoerro integer NOT NULL,
    storedprocedure character varying(100),
    erro character varying(200),
    msgerro character varying(200),
    observacao text
);


ALTER TABLE dbo.codigoerros OWNER TO postgres;

--
-- Name: componentetarefa; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.componentetarefa (
    id_meiosimulado integer NOT NULL,
    id_organizacaotarefa integer NOT NULL,
    situacao integer NOT NULL,
    id_gt integer
);


ALTER TABLE dbo.componentetarefa OWNER TO postgres;

--
-- Name: configuracao; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.configuracao (
    id_configuracao integer NOT NULL,
    id_meiosimulado integer NOT NULL,
    codconfiguracao integer,
    codraioacaoconfiguracao integer NOT NULL,
    caracteristicaconfiguracao character varying(50),
    carga integer NOT NULL,
    capactanquecombexterno integer,
    qtdetanques integer,
    listacabidestanque character varying(50),
    coeficientepos double precision,
    raioacaoaa integer,
    raioacaobb integer,
    qtdebrs_ativa integer,
    alcancemaximobrs double precision,
    listacabidesbrs_ativa character varying(50),
    qtderc integer,
    listacabidesrc character varying(50),
    classecaracteristica character varying(10),
    qtdebrs_passiva integer,
    listacabidesbrs_passiva character varying(50)
);


ALTER TABLE dbo.configuracao OWNER TO postgres;

--
-- Name: dano; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.dano (
    id_plataforma integer NOT NULL,
    m_percentdanototal numeric(15,9),
    m_duracaomaximareparobase numeric(15,9),
    m_valorapresentado character varying(600)
);


ALTER TABLE dbo.dano OWNER TO postgres;

--
-- Name: danoespecifico; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.danoespecifico (
    id_danoespecifico integer NOT NULL,
    id_tipodano integer,
    id_plataforma integer,
    localreparo character varying(50),
    temporeparomar double precision,
    dhinicioreparomar_str character varying(50),
    temporeparobase double precision,
    dhinicioreparobase_str character varying(50),
    perdas character varying(50)
);


ALTER TABLE dbo.danoespecifico OWNER TO postgres;

--
-- Name: dd_propulsao; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.dd_propulsao (
    id_propulsao integer NOT NULL,
    tiporecursologistico character varying(50),
    recursologistico character varying(50),
    id_tiporecursologistico integer,
    id_recursologistico integer,
    nome character varying(10)
);


ALTER TABLE dbo.dd_propulsao OWNER TO postgres;

--
-- Name: dotacaoarmamento; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.dotacaoarmamento (
    id_armamento integer NOT NULL,
    id_localizacao integer NOT NULL,
    qtdedotacao integer,
    qtdercb integer,
    qtdecons integer,
    reparo character varying(50),
    listacabidesarm character varying(50),
    qtdelancavariados integer,
    dano_armamento integer
);


ALTER TABLE dbo.dotacaoarmamento OWNER TO postgres;

--
-- Name: dotacaosensor; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.dotacaosensor (
    id_dotacaosensor integer NOT NULL,
    id_sensor integer NOT NULL,
    id_localizacao integer NOT NULL,
    situacao character varying(50),
    configurado smallint
);


ALTER TABLE dbo.dotacaosensor OWNER TO postgres;

--
-- Name: finalidadeacompanhamentomav; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.finalidadeacompanhamentomav (
    id_finalidade integer NOT NULL,
    nome character varying(50)
);


ALTER TABLE dbo.finalidadeacompanhamentomav OWNER TO postgres;

--
-- Name: finalidadearea; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.finalidadearea (
    id_finalidadearea integer NOT NULL,
    nome character varying(50)
);


ALTER TABLE dbo.finalidadearea OWNER TO postgres;

--
-- Name: finalidadelinha; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.finalidadelinha (
    id_finalidadelinha integer NOT NULL,
    nome character varying(50)
);


ALTER TABLE dbo.finalidadelinha OWNER TO postgres;

--
-- Name: finalidadepontonotavel; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.finalidadepontonotavel (
    id_finalidadepontonotavel integer NOT NULL,
    nome character varying(50)
);


ALTER TABLE dbo.finalidadepontonotavel OWNER TO postgres;

--
-- Name: foguete; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.foguete (
    id_armamento integer NOT NULL,
    pai double precision NOT NULL,
    agentelancadorabrev character varying(50),
    trigrama character varying(3),
    alcanceeficaz double precision
);


ALTER TABLE dbo.foguete OWNER TO postgres;

--
-- Name: formatura; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.formatura (
    id_formatura integer NOT NULL,
    id_modeloformatura integer NOT NULL,
    id_guiaformatura integer,
    eixo numeric(15,9),
    marcacao_guia numeric(15,9),
    distancia_guia numeric(15,9),
    id_um integer,
    "Login" character varying(50)
);


ALTER TABLE dbo.formatura OWNER TO postgres;

--
-- Name: glossario; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.glossario (
    id integer NOT NULL,
    compactado character varying(50),
    descompactado character varying(50)
);


ALTER TABLE dbo.glossario OWNER TO postgres;

--
-- Name: interceptacao; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.interceptacao (
    id_interceptacao integer NOT NULL,
    id_meiosimulado_um integer NOT NULL,
    id_meiosimulado_interceptar integer,
    id_meiosimulado_area integer,
    id_trajeto integer,
    id_pontotrajeto integer,
    ladodestino integer,
    velocmanobra double precision,
    latitudeposgeo numeric(15,9),
    longitudeposgeo numeric(15,9),
    marcacao numeric(15,9),
    distancia double precision,
    datahoratermino character varying(15),
    tipointerceptacao integer,
    removida smallint,
    nomebase character varying(50),
    movimento integer
);


ALTER TABLE dbo.interceptacao OWNER TO postgres;

--
-- Name: itemconfiguracao; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.itemconfiguracao (
    id_itemconfiguracao integer NOT NULL,
    id_configuracao integer NOT NULL,
    id_armamento integer,
    id_sensor integer,
    quantidade integer NOT NULL,
    listacabideitem character varying(50)
);


ALTER TABLE dbo.itemconfiguracao OWNER TO postgres;

--
-- Name: linha; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.linha (
    id_meiosimulado integer NOT NULL,
    id_finalidade integer,
    tabelalinha character varying(50)
);


ALTER TABLE dbo.linha OWNER TO postgres;

--
-- Name: linhamarcacao; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.linhamarcacao (
    id_meiosimulado integer NOT NULL,
    marcacao double precision,
    distancia double precision
);


ALTER TABLE dbo.linhamarcacao OWNER TO postgres;

--
-- Name: linhapoligonal; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.linhapoligonal (
    id_meiosimulado integer NOT NULL
);


ALTER TABLE dbo.linhapoligonal OWNER TO postgres;

--
-- Name: localizacao; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.localizacao (
    id_localizacao integer NOT NULL,
    id_meiosimulado_platsup integer,
    id_meiosimulado_platsub integer,
    id_meiosimulado_plataer integer,
    id_base integer,
    id_meiosimulado_platterra integer
);


ALTER TABLE dbo.localizacao OWNER TO postgres;

--
-- Name: logerrossp; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.logerrossp (
    id_erro integer NOT NULL,
    dh_erro timestamp without time zone NOT NULL,
    nomesp character varying(200),
    num_secao integer,
    codigomssql integer NOT NULL,
    usuarioconectado character varying(200),
    aplicacao character varying(200),
    mensagemerro character varying(1000)
);


ALTER TABLE dbo.logerrossp OWNER TO postgres;

--
-- Name: logtransacoes; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.logtransacoes (
    idlog integer NOT NULL,
    nomesp character varying(100),
    parametrossp text,
    datahora timestamp without time zone
);


ALTER TABLE dbo.logtransacoes OWNER TO postgres;

--
-- Name: macambiente; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.macambiente (
    idpersistencia integer NOT NULL,
    loginusuario character varying(50),
    "TimeStamp" character varying(14),
    nomepersistencia character varying(100),
    fgver integer NOT NULL,
    frver integer NOT NULL,
    nomecartavector character varying(200),
    intervaloatualizacao integer NOT NULL,
    tamanhosimbologia integer NOT NULL,
    estadobotaoatualizacao integer NOT NULL,
    contadoracompmav integer NOT NULL,
    contadormodeloplano integer NOT NULL,
    idvisaoativa integer NOT NULL,
    prefixodefiguravisivel integer NOT NULL
);


ALTER TABLE dbo.macambiente OWNER TO postgres;

--
-- Name: macarmamentovisivel; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.macarmamentovisivel (
    idpersistencia integer NOT NULL,
    tipomeio integer NOT NULL,
    idmeio integer NOT NULL,
    idarmamento integer NOT NULL,
    nomearma character varying(50)
);


ALTER TABLE dbo.macarmamentovisivel OWNER TO postgres;

--
-- Name: maccartaraster; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.maccartaraster (
    idpersistencia integer NOT NULL,
    idcartaraster integer NOT NULL,
    nomecartaraster character varying(100),
    escalade integer NOT NULL,
    escalapara integer NOT NULL,
    resolucaox integer NOT NULL,
    resolucaoy integer NOT NULL,
    posicaomediasegx integer NOT NULL,
    posicaomediasegy integer NOT NULL,
    visivel integer NOT NULL,
    rectlimitesegleft integer NOT NULL,
    rectlimitesegtop integer NOT NULL,
    rectlimitesegright integer NOT NULL,
    rectlimitesegbottom integer NOT NULL,
    copymode integer NOT NULL,
    idescala integer NOT NULL
);


ALTER TABLE dbo.maccartaraster OWNER TO postgres;

--
-- Name: macdesenho; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.macdesenho (
    idpersistencia integer NOT NULL,
    nomearquivodesenho character varying(200),
    arquivodesenho bytea
);


ALTER TABLE dbo.macdesenho OWNER TO postgres;

--
-- Name: macfiltropartido; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.macfiltropartido (
    idpersistencia integer NOT NULL,
    idvisao integer NOT NULL,
    idpartido integer NOT NULL,
    visivel integer NOT NULL
);


ALTER TABLE dbo.macfiltropartido OWNER TO postgres;

--
-- Name: macmarcador; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.macmarcador (
    idpersistencia integer NOT NULL,
    idvisao integer NOT NULL,
    idmarcador integer NOT NULL,
    nome character varying(100),
    escala integer NOT NULL,
    latitude integer NOT NULL,
    longitude integer NOT NULL,
    deslocx integer NOT NULL,
    deslocy integer NOT NULL
);


ALTER TABLE dbo.macmarcador OWNER TO postgres;

--
-- Name: macmeiovisivel; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.macmeiovisivel (
    idpersistencia integer NOT NULL,
    tipomeio integer NOT NULL,
    idmeio integer NOT NULL
);


ALTER TABLE dbo.macmeiovisivel OWNER TO postgres;

--
-- Name: macmodeloplano; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.macmodeloplano (
    idpersistencia integer NOT NULL,
    idplano integer NOT NULL,
    nomeplano character varying(50),
    logincontrolador character varying(50),
    latorigem double precision NOT NULL,
    longorigem double precision NOT NULL,
    eixo integer NOT NULL,
    idmodelo integer NOT NULL,
    idpartido integer NOT NULL
);


ALTER TABLE dbo.macmodeloplano OWNER TO postgres;

--
-- Name: macplanovisivel; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.macplanovisivel (
    idpersistencia integer NOT NULL,
    idplano integer NOT NULL
);


ALTER TABLE dbo.macplanovisivel OWNER TO postgres;

--
-- Name: macsensorvisivel; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.macsensorvisivel (
    idpersistencia integer NOT NULL,
    tipomeio integer NOT NULL,
    idmeio integer NOT NULL,
    idsensor integer NOT NULL,
    nomesensor character varying(50)
);


ALTER TABLE dbo.macsensorvisivel OWNER TO postgres;

--
-- Name: mactrajetovisivel; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.mactrajetovisivel (
    idpersistencia integer NOT NULL,
    idtrajeto integer NOT NULL
);


ALTER TABLE dbo.mactrajetovisivel OWNER TO postgres;

--
-- Name: macvisao; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.macvisao (
    idpersistencia integer NOT NULL,
    idvisao integer NOT NULL,
    windowleft integer NOT NULL,
    windowtop integer NOT NULL,
    windowwidth integer NOT NULL,
    windowheight integer NOT NULL,
    windowstate integer NOT NULL,
    cormar integer NOT NULL,
    corbrasil integer NOT NULL,
    corisobatimetrica integer NOT NULL,
    corcontinente integer NOT NULL,
    corlago integer NOT NULL,
    corrio integer NOT NULL,
    escala integer NOT NULL,
    fo integer NOT NULL,
    lo integer NOT NULL,
    deslocmovex integer NOT NULL,
    deslocmovey integer NOT NULL,
    ambfigura bigint NOT NULL,
    ambsimbfigura bigint NOT NULL,
    ambnomefigura bigint NOT NULL,
    ambnomeconexao bigint NOT NULL,
    btngradevisivel integer NOT NULL,
    btndestruidaabatida integer NOT NULL,
    btnmsliberado integer NOT NULL,
    btnmslibcontato integer
);


ALTER TABLE dbo.macvisao OWNER TO postgres;

--
-- Name: macvisualarma; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.macvisualarma (
    idpersistencia integer NOT NULL,
    tipomeio integer NOT NULL,
    idmeio integer NOT NULL,
    tipoalcancearmamento integer NOT NULL,
    alcancearmamentovisivel integer NOT NULL,
    compreenchimento integer NOT NULL
);


ALTER TABLE dbo.macvisualarma OWNER TO postgres;

--
-- Name: macvisualsensor; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.macvisualsensor (
    idpersistencia integer NOT NULL,
    tipomeio integer NOT NULL,
    idmeio integer NOT NULL,
    tipoalcancesensor integer NOT NULL,
    alcancesensorvisivel integer NOT NULL,
    alcancemagevisivel integer NOT NULL,
    compreenchimento integer NOT NULL
);


ALTER TABLE dbo.macvisualsensor OWNER TO postgres;

--
-- Name: meioexterno; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.meioexterno (
    id_meiosimulado integer NOT NULL,
    tipo character varying(50),
    subtipo character varying(50),
    dh_informacao character varying(14),
    observacoes character varying(500),
    origem character varying(20),
    id_na_origem integer NOT NULL
);


ALTER TABLE dbo.meioexterno OWNER TO postgres;

--
-- Name: meiosimulado; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.meiosimulado (
    id_meiosimulado integer NOT NULL,
    nome character varying(50),
    acaoms character varying(100),
    id_partido integer,
    rumo double precision,
    velocavanco double precision,
    latitude numeric(15,9),
    longitude numeric(15,9),
    id_mss integer,
    datahora character varying(14),
    tabelameiosimulado character varying(50),
    id_trajeto integer,
    id_um integer,
    veloctrajeto double precision,
    proximoponto integer,
    trajeto_ultimoponto integer,
    plano_voltasrestantes integer,
    id_plano integer,
    "Login" character varying(50),
    observacao character varying(100)
);


ALTER TABLE dbo.meiosimulado OWNER TO postgres;

--
-- Name: meiosimuladoliberado; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.meiosimuladoliberado (
    id_meiosimulado integer NOT NULL,
    id_partido integer NOT NULL,
    id_papel integer NOT NULL,
    logincontrolador character varying(50),
    tipomeiosimulado character varying(50),
    identificacaoocultada smallint NOT NULL
);


ALTER TABLE dbo.meiosimuladoliberado OWNER TO postgres;

--
-- Name: meiosimuladomav; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.meiosimuladomav (
    id_meiosimulado integer NOT NULL,
    nome character varying(50),
    acaoms character varying(100),
    id_partido integer,
    rumo double precision,
    velocavanco double precision,
    latitude numeric(15,9),
    longitude numeric(15,9),
    id_mss integer,
    datahora character varying(14),
    tabelameiosimulado character varying(50),
    id_trajeto integer,
    id_um integer,
    veloctrajeto double precision,
    proximoponto integer,
    trajeto_ultimoponto integer,
    plano_voltasrestantes integer,
    id_plano integer,
    "Login" character varying(50),
    observacao character varying(100)
);


ALTER TABLE dbo.meiosimuladomav OWNER TO postgres;

--
-- Name: mina; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.mina (
    id_armamento integer NOT NULL,
    agentelancadorabrev character varying(10),
    atuacaoarmamentoabrev character varying(50),
    peso double precision NOT NULL,
    profundidade character varying(50),
    tipoalvo character varying(50),
    tipomina character varying(50)
);


ALTER TABLE dbo.mina OWNER TO postgres;

--
-- Name: missil; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.missil (
    id_armamento integer NOT NULL,
    pai double precision,
    pam double precision,
    paa double precision,
    nomeguiagemabrev character varying(50),
    veloc double precision,
    agentelancadorabrev character varying(10),
    trigrama character varying(3),
    tipomissil character varying(50),
    tipomissilnum integer,
    alcanceeficaz double precision
);


ALTER TABLE dbo.missil OWNER TO postgres;

--
-- Name: modeloformatura; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.modeloformatura (
    id_modeloformatura integer NOT NULL,
    nome character varying(51),
    tipoformatura character varying(1),
    patrulhasetores character varying(1)
);


ALTER TABLE dbo.modeloformatura OWNER TO postgres;

--
-- Name: modeloplano; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.modeloplano (
    id_modeloplano integer NOT NULL,
    nome character varying(50),
    tipoplano character varying(1),
    id_partido integer
);


ALTER TABLE dbo.modeloplano OWNER TO postgres;

--
-- Name: mss_constante; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.mss_constante (
    id_mssconstante integer NOT NULL,
    nome character varying(50),
    id_tiporecursologisitico integer NOT NULL,
    id_recursologistico integer NOT NULL
);


ALTER TABLE dbo.mss_constante OWNER TO postgres;

--
-- Name: nri; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.nri (
    id_meiosimulado integer NOT NULL,
    velocavanco integer NOT NULL,
    nri double precision NOT NULL
);


ALTER TABLE dbo.nri OWNER TO postgres;

--
-- Name: organizacaotarefa; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.organizacaotarefa (
    id_organizacaotarefa integer NOT NULL,
    nome character varying(50),
    id_organizacaotarefa_sup integer,
    situacao integer NOT NULL,
    horaativacao character varying(14),
    tipoativacao character varying(3),
    id_partido integer NOT NULL
);


ALTER TABLE dbo.organizacaotarefa OWNER TO postgres;

--
-- Name: organizacaotarefaliberada; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.organizacaotarefaliberada (
    id_organizacaotarefa integer NOT NULL,
    id_partido integer NOT NULL,
    id_papel integer NOT NULL,
    logincontrolador character varying(50)
);


ALTER TABLE dbo.organizacaotarefaliberada OWNER TO postgres;

--
-- Name: partido; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.partido (
    id_partido integer NOT NULL,
    nome character varying(50),
    codigocor integer NOT NULL,
    nomecor character varying(50),
    neutro character varying(1)
);


ALTER TABLE dbo.partido OWNER TO postgres;

--
-- Name: pdv; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.pdv (
    id_pdv integer NOT NULL,
    login_de character varying(30),
    grta character varying(30),
    sala character varying(30),
    "Data" character varying(30),
    criacao character varying(30),
    liberacao character varying(30),
    seqnumaltpdv integer,
    offsetprimeiroevento integer,
    "XML" text,
    controladornotificado bit(1),
    identificacao character varying(50),
    tipo character varying(3),
    invisivel bit(1) NOT NULL
);


ALTER TABLE dbo.pdv OWNER TO postgres;

--
-- Name: pista; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.pista (
    id_pista integer NOT NULL,
    classe integer NOT NULL,
    capaccarga character varying(50),
    comppista character varying(50),
    pavimentacao character varying(50)
);


ALTER TABLE dbo.pista OWNER TO postgres;

--
-- Name: pistabase; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.pistabase (
    id_pista integer NOT NULL,
    id_base integer NOT NULL,
    quantpista integer
);


ALTER TABLE dbo.pistabase OWNER TO postgres;

--
-- Name: plano; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.plano (
    id_plano integer NOT NULL,
    id_modeloplano integer NOT NULL,
    id_ms_referencia integer,
    id_partido integer NOT NULL,
    id_base_referencia integer,
    nome character varying(50),
    latitude_ref numeric(15,9),
    longitude_ref numeric(15,9),
    distancia_ref double precision,
    marcacao_ref numeric(15,9),
    eixo integer,
    movimento integer,
    "Login" character varying(50)
);


ALTER TABLE dbo.plano OWNER TO postgres;

--
-- Name: plantapropulsora; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.plantapropulsora (
    id_plantapropulsora integer NOT NULL,
    tipoplanta character varying(5),
    descricao character varying(50),
    designacaoplanta character varying(15)
);


ALTER TABLE dbo.plantapropulsora OWNER TO postgres;

--
-- Name: plataformaaerea; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.plataformaaerea (
    id_meiosimulado integer NOT NULL,
    id_localizacao integer,
    id_localizacaopousada integer,
    nometipoaeronave character varying(50),
    id_situacaoplataforma integer NOT NULL,
    modelo character varying(50),
    embarcado character varying(1),
    tipoasa character varying(50),
    indicesortidas character varying(15),
    horasmes double precision,
    tipomotoraeronave character varying(50),
    qtdemotores integer,
    propulsao character varying(3),
    empuxo double precision,
    consumomedio double precision,
    altura double precision,
    comprimento double precision,
    largura double precision,
    hangaragems2 double precision,
    areaasas double precision,
    diametrora double precision,
    pesobasico double precision,
    pesomaximo double precision,
    pesosupasa double precision,
    pesopotencia double precision,
    cargautil double precision,
    geometriavariavel character varying(1),
    razaosubida double precision,
    tetoservico double precision,
    tetovoolibrado double precision,
    velocmaxalto double precision,
    velocmaxbaixo double precision,
    veloccruzeiroalto double precision,
    veloccruzeirobaixo double precision,
    altitude double precision,
    horizontalsubida double precision,
    navegacao character varying(50),
    bloqueio character varying(1),
    equipamentobloqueio character varying(50),
    empregoaeronave character varying(50),
    reabastecimentovoo character varying(1),
    operacaoaeronave character varying(50),
    interceptacaoaeronave character varying(50),
    ataqueaeronave character varying(50),
    altitudeperfilvooa double precision,
    altitudeperfilvoob double precision,
    autonomia double precision,
    perfilvoo character varying(3),
    cteconsumo1 double precision,
    cteconsumo2 double precision,
    ctepatrulha double precision,
    danoveloc double precision,
    iff character varying(1),
    mage character varying(1),
    veloclogistica double precision,
    id_configuracaocorrente integer,
    hf character varying(10),
    uhf character varying(10),
    vhf character varying(10),
    observacao character varying(50),
    id_pista integer,
    id_tipopropulsao integer,
    id_recursopropulsao integer,
    danosensor double precision,
    outrossistemascomunicacao character varying(50),
    sigla character varying(10),
    emespera character varying(1),
    dhterminoespera character varying(15)
);


ALTER TABLE dbo.plataformaaerea OWNER TO postgres;

--
-- Name: plataformasubmarina; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.plataformasubmarina (
    id_meiosimulado integer NOT NULL,
    id_base integer,
    nomeclasse character varying(50),
    id_situacaoplataforma integer NOT NULL,
    deslocamentosup double precision,
    deslocamentoimerso double precision,
    boca double precision,
    calado double precision,
    comprimento double precision,
    esnorquel character varying(50),
    coeficienteseguranca double precision,
    autonomia double precision,
    manutencao integer,
    numtubos integer,
    velocecsup integer,
    velocecimerso integer,
    velocmaximerso integer,
    velocmmsuperficie integer,
    velocmmesnorquel integer,
    velocmmnuclear integer,
    ravecsup integer,
    ravelocmaximerso integer,
    ravelocmmsup integer,
    ravelocmmesnorquel integer,
    ravelocecimerso integer,
    ravelocmmnuclear integer,
    consumovelocecsup double precision,
    consumovelocecimerso double precision,
    consumovelocmaximerso double precision,
    consumovelocmmsup double precision,
    consumovelocmmesnorquel double precision,
    cargamaxima double precision,
    cargaatual double precision,
    ctedescarga1 double precision,
    ctedescarga2 double precision,
    profundidade integer,
    observacao character varying(100),
    propulsao character varying(3),
    cteconsumo1 double precision,
    cteconsumo2 double precision,
    ctepatrulha double precision,
    danoveloc double precision,
    iff character varying(1),
    mage character varying(1),
    bandamage character varying(50),
    despist character varying(10),
    vlf character varying(10),
    hf_lf character varying(10),
    vhf character varying(10),
    uhf character varying(10),
    cotamaxoperac double precision,
    veloclogistica double precision,
    id_plantapropulsora integer,
    id_tipopropulsao integer,
    id_recursopropulsao integer,
    danosensor double precision,
    sigla character varying(10),
    m_danocoms_hf integer,
    m_danocoms_vhf integer,
    m_danocoms_vlf integer,
    m_danocoms_hf_lf integer
);


ALTER TABLE dbo.plataformasubmarina OWNER TO postgres;

--
-- Name: plataformasuperficie; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.plataformasuperficie (
    id_meiosimulado integer NOT NULL,
    id_base integer,
    nomeclasse character varying(50),
    id_situacaoplataforma integer NOT NULL,
    veloclogistica double precision,
    cteconsumo1 double precision,
    cteconsumo2 double precision,
    ctepatrulha double precision,
    danoveloc double precision,
    cme character varying(1),
    bandacme character varying(50),
    iff character varying(1),
    mage character varying(1),
    bandamage character varying(50),
    tipoplatsuperficienum integer,
    tipoplatsuperficie character varying(50),
    deslocamento double precision NOT NULL,
    calado double precision NOT NULL,
    comprimento double precision NOT NULL,
    boca double precision NOT NULL,
    velocec integer,
    velocmm integer,
    velocmax integer,
    ravelocec integer,
    ravelocmm integer,
    ravelocmax integer,
    consumovelocec double precision,
    consumovelocmm double precision,
    consumovelocmax double precision,
    propulsao character varying(3),
    capacdocagem double precision,
    capachangaragem double precision,
    areahangarocupada double precision,
    id_pista integer,
    observacao character varying(100),
    janela character varying(1),
    vhf character varying(10),
    uhf character varying(10),
    hf character varying(10),
    guia integer,
    id_tipopropulsao integer,
    id_recursopropulsao integer,
    id_plantapropulsora integer,
    danosensor double precision,
    sigla character varying(10),
    m_danoreabastecimento integer,
    m_danoopsaereashe integer,
    m_danoopsaereasasafixa integer,
    m_danocoms_hf integer,
    m_danocoms_vhf integer,
    m_danocoms_uhf integer,
    ehcapitanea character varying(1)
);


ALTER TABLE dbo.plataformasuperficie OWNER TO postgres;

--
-- Name: plataformaterrestre; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.plataformaterrestre (
    id_meiosimulado integer NOT NULL,
    tipoplataformaterrestrenum integer,
    tipoplataformaterrestre character varying(50),
    id_situacaoplataforma integer,
    danoveloc double precision,
    danosensor double precision,
    velocmax double precision,
    ravelocmax double precision,
    consumovelocmax double precision,
    id_tipopropulsao integer,
    id_recursopropulsao integer,
    observacao character varying(100),
    sigla character varying(10),
    id_localizacaoembarcada integer
);


ALTER TABLE dbo.plataformaterrestre OWNER TO postgres;

--
-- Name: pontonotavel; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.pontonotavel (
    id_meiosimulado integer NOT NULL,
    id_finalidade integer NOT NULL
);


ALTER TABLE dbo.pontonotavel OWNER TO postgres;

--
-- Name: pontosarea; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.pontosarea (
    id_pontosarea integer NOT NULL,
    id_meiosimulado integer NOT NULL,
    nome character varying(50),
    marcacao double precision NOT NULL,
    distancia double precision NOT NULL
);


ALTER TABLE dbo.pontosarea OWNER TO postgres;

--
-- Name: pontoslinha; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.pontoslinha (
    id_meiosimulado integer NOT NULL,
    id_pontoslinha integer NOT NULL,
    nome character varying(50),
    marcacao double precision NOT NULL,
    distancia double precision NOT NULL
);


ALTER TABLE dbo.pontoslinha OWNER TO postgres;

--
-- Name: pontosmodeloformatura; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.pontosmodeloformatura (
    id_pontosmodeloformatura integer NOT NULL,
    id_modeloformatura integer NOT NULL,
    nome character varying(50),
    marcacao numeric(15,9),
    distancia numeric(15,9)
);


ALTER TABLE dbo.pontosmodeloformatura OWNER TO postgres;

--
-- Name: pontosmodeloplano; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.pontosmodeloplano (
    id_pontosmodeloplano integer NOT NULL,
    id_modeloplano integer NOT NULL,
    nome character varying(10),
    marcacao double precision NOT NULL,
    distancia double precision NOT NULL
);


ALTER TABLE dbo.pontosmodeloplano OWNER TO postgres;

--
-- Name: pontostrajeto; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.pontostrajeto (
    id_pontos integer NOT NULL,
    id_trajeto integer NOT NULL,
    nome character varying(50),
    latitude numeric(15,9),
    longitude numeric(15,9),
    datahora character varying(14),
    veloc double precision NOT NULL
);


ALTER TABLE dbo.pontostrajeto OWNER TO postgres;

--
-- Name: postosformatura; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.postosformatura (
    id_postosformatura integer NOT NULL,
    id_formatura integer NOT NULL,
    id_ms_posto integer,
    nome character varying(50),
    marcacao numeric(15,9),
    distancia numeric(15,9)
);


ALTER TABLE dbo.postosformatura OWNER TO postgres;

--
-- Name: previsaometeorologica; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.previsaometeorologica (
    id_previsaometeorologica integer NOT NULL,
    tempo character varying(50),
    velocvento character varying(50),
    pressaoatm integer NOT NULL,
    estadomar character varying(50),
    visibilidade character varying(50),
    teto character varying(50),
    degradacaosensores double precision NOT NULL,
    maximaveloc integer NOT NULL,
    operacoesaereas character varying(50)
);


ALTER TABLE dbo.previsaometeorologica OWNER TO postgres;

--
-- Name: recursopropulsao; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.recursopropulsao (
    id_recursopropulsao integer NOT NULL,
    id_recursologistico integer NOT NULL,
    id_tipopropulsao integer NOT NULL
);


ALTER TABLE dbo.recursopropulsao OWNER TO postgres;

--
-- Name: recursoslogisticos; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.recursoslogisticos (
    id_recursologistico integer NOT NULL,
    id_localizacao integer NOT NULL,
    nome character varying(50),
    nomereclog_num integer,
    tipo character varying(50),
    tiporeclog_num integer,
    categoria character varying(10),
    capacarmazenamento double precision,
    qtdercb double precision,
    qtdeconsfnc double precision,
    numerotomadas integer,
    numerotanques integer,
    capacmaxtanque integer,
    vazaofnc integer,
    vazaorcb integer,
    id_armamento integer,
    id_sensor integer
);


ALTER TABLE dbo.recursoslogisticos OWNER TO postgres;

--
-- Name: sensor; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.sensor (
    id_sensor integer NOT NULL,
    tiposensor character varying(50),
    nome character varying(50),
    modelo character varying(50),
    alcancemaximo double precision,
    emprego character varying(50),
    modooperacao character varying(50),
    dano_sensor integer
);


ALTER TABLE dbo.sensor OWNER TO postgres;

--
-- Name: situacaoplataforma; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.situacaoplataforma (
    id_situacaoplataforma integer NOT NULL,
    nome character varying(50),
    tipoplataforma character varying(25),
    constante integer
);


ALTER TABLE dbo.situacaoplataforma OWNER TO postgres;

--
-- Name: ssgn_acesso; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.ssgn_acesso (
    id_funcao integer NOT NULL,
    id_recurso integer NOT NULL,
    id_fase integer NOT NULL,
    acesso character varying(10)
);


ALTER TABLE dbo.ssgn_acesso OWNER TO postgres;

--
-- Name: ssgn_auditoria; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.ssgn_auditoria (
    datahora character varying(14),
    maquina character varying(50),
    loginwindows character varying(50),
    "Login" character varying(50),
    bancodados character varying(50),
    id_fase integer,
    id_funcao integer,
    id_recurso integer,
    id_papel integer,
    situacao character varying(50),
    observacao character varying(200)
);


ALTER TABLE dbo.ssgn_auditoria OWNER TO postgres;

--
-- Name: ssgn_comando; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.ssgn_comando (
    id_mss integer NOT NULL,
    indice integer,
    datahoraexec character varying(14),
    "Login" character varying(50),
    statuscomando character varying(4),
    feedback integer,
    id_mcc integer,
    comandoxml character varying(100),
    offsetenc integer,
    id_fab character varying(100)
);


ALTER TABLE dbo.ssgn_comando OWNER TO postgres;

--
-- Name: ssgn_comando_pdv; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.ssgn_comando_pdv (
    id_pdv character varying(100),
    id_mss integer NOT NULL
);


ALTER TABLE dbo.ssgn_comando_pdv OWNER TO postgres;

--
-- Name: ssgn_comando_preab; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.ssgn_comando_preab (
    id_preab character varying(100),
    id_mss integer NOT NULL
);


ALTER TABLE dbo.ssgn_comando_preab OWNER TO postgres;

--
-- Name: ssgn_controlejogo; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.ssgn_controlejogo (
    jogo character varying(50),
    versao character varying(50),
    data_criacao character varying(15),
    id_fase integer,
    datahorainicreal character varying(14),
    datahorainicsimulada character varying(14),
    datahoraatualreal character varying(14),
    datahoraatualsimulada character varying(14),
    status character varying(10),
    marchareal integer,
    marchasimulada integer,
    delta_t integer,
    statusbackup character varying(1),
    taxabackup integer,
    statusdeteccao character varying(1),
    taxadeteccao integer,
    taxaatuplataerea integer,
    taxaatuplatsuperficie integer,
    taxaatuplatsubmarina integer,
    taxaatumeiosimulado integer,
    contatuplataereas integer,
    contatuplatsuperficie integer,
    contatuplatsubmarina integer,
    contatumeiosimulado integer,
    proximoidmss integer,
    constidpass integer
);


ALTER TABLE dbo.ssgn_controlejogo OWNER TO postgres;

--
-- Name: ssgn_exportacao_processamento; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.ssgn_exportacao_processamento (
    id_exportacao_processada integer NOT NULL,
    id_elemento_exportado integer NOT NULL,
    tipoelementoexportacao character varying(100),
    nomeelemento character varying(100),
    id_meiosimulado_importado integer,
    id_modeloplano_importado integer,
    id_trajeto_importado integer,
    id_partido integer NOT NULL,
    elementoimportado integer NOT NULL
);


ALTER TABLE dbo.ssgn_exportacao_processamento OWNER TO postgres;

--
-- Name: ssgn_exportacaomav; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.ssgn_exportacaomav (
    id_exportacaomav integer NOT NULL,
    "Login" character varying(50),
    logincontrolador character varying(50),
    nome character varying(50),
    conteudoxml character varying(100)
);


ALTER TABLE dbo.ssgn_exportacaomav OWNER TO postgres;

--
-- Name: ssgn_fase; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.ssgn_fase (
    id_fase integer NOT NULL,
    nome character varying(50)
);


ALTER TABLE dbo.ssgn_fase OWNER TO postgres;

--
-- Name: ssgn_hierarquiacomponente; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.ssgn_hierarquiacomponente (
    id_hierarquiacomponente integer NOT NULL,
    id_tipocomponente integer NOT NULL,
    codigo_mcc character varying(50),
    codigo_pai character varying(50),
    stored_procedure character varying(50),
    camposapresentados character varying(80),
    campoenviado character varying(30),
    composicao character varying(20),
    camposparametro character varying(50)
);


ALTER TABLE dbo.ssgn_hierarquiacomponente OWNER TO postgres;

--
-- Name: ssgn_itemacesso; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.ssgn_itemacesso (
    id_funcao integer NOT NULL,
    id_recurso integer NOT NULL,
    id_fase integer NOT NULL,
    id_tagitemmenu integer NOT NULL
);


ALTER TABLE dbo.ssgn_itemacesso OWNER TO postgres;

--
-- Name: ssgn_itemmenurecurso; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.ssgn_itemmenurecurso (
    id_recurso integer NOT NULL,
    id_tagitemmenu integer NOT NULL,
    nome character varying(50),
    id_tagpai integer NOT NULL,
    nivel integer NOT NULL
);


ALTER TABLE dbo.ssgn_itemmenurecurso OWNER TO postgres;

--
-- Name: ssgn_logjogo; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.ssgn_logjogo (
    id_logjogo integer NOT NULL,
    dh character varying(14),
    id_recurso integer NOT NULL,
    "Login" character varying(50),
    tipomensagem integer NOT NULL,
    mensagem character varying(7900),
    id_comandomss integer,
    id_comandomcc integer,
    id_comandoencadeado integer,
    classif integer,
    dh_real character varying(14)
);


ALTER TABLE dbo.ssgn_logjogo OWNER TO postgres;

--
-- Name: ssgn_msslog; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.ssgn_msslog (
    indicemensagem integer NOT NULL,
    mensagem character varying(600)
);


ALTER TABLE dbo.ssgn_msslog OWNER TO postgres;

--
-- Name: ssgn_papeisaplicfuncao; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.ssgn_papeisaplicfuncao (
    id_funcao integer NOT NULL,
    id_papel integer NOT NULL
);


ALTER TABLE dbo.ssgn_papeisaplicfuncao OWNER TO postgres;

--
-- Name: ssgn_recurso; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.ssgn_recurso (
    id_recurso integer NOT NULL,
    recurso character varying(10),
    descricaorecurso character varying(50)
);


ALTER TABLE dbo.ssgn_recurso OWNER TO postgres;

--
-- Name: ssgn_recursologistico; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.ssgn_recursologistico (
    id_recursologistico integer NOT NULL,
    nome character varying(50),
    categoria character varying(10)
);


ALTER TABLE dbo.ssgn_recursologistico OWNER TO postgres;

--
-- Name: ssgn_temp_verificacaoidentificador; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.ssgn_temp_verificacaoidentificador (
    taguso character varying(16),
    identificador character varying(100),
    id_partido integer NOT NULL,
    "Login" character varying(100),
    id_exportacao integer NOT NULL,
    elemento character varying(100),
    dh_criacao date
);


ALTER TABLE dbo.ssgn_temp_verificacaoidentificador OWNER TO postgres;

--
-- Name: ssgn_tipocomponente; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.ssgn_tipocomponente (
    id_tipocomponente integer NOT NULL,
    nome character varying(50),
    icone bytea,
    grupo character varying(10),
    treenode bit(1) NOT NULL,
    nomearmamento character varying(50),
    persistenciaencadeamento bit(1) NOT NULL,
    atualizacaoautomatica bit(1) NOT NULL,
    filtraritemraiz bit(1) NOT NULL
);


ALTER TABLE dbo.ssgn_tipocomponente OWNER TO postgres;

--
-- Name: tabeladejogos; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.tabeladejogos (
    name character varying(256),
    size integer NOT NULL,
    low integer NOT NULL,
    high integer NOT NULL,
    cntrltype smallint NOT NULL,
    phyname character varying(260),
    status smallint NOT NULL
);


ALTER TABLE dbo.tabeladejogos OWNER TO postgres;

--
-- Name: tempdano; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.tempdano (
    id_plataforma integer NOT NULL,
    m_percentdanototal double precision,
    m_duracaomaximareparobase double precision,
    m_valorapresentado character varying(400)
);


ALTER TABLE dbo.tempdano OWNER TO postgres;

--
-- Name: tempglossario; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.tempglossario (
    id integer NOT NULL,
    compactado character varying(50),
    descompactado character varying(50)
);


ALTER TABLE dbo.tempglossario OWNER TO postgres;

--
-- Name: tipodano; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.tipodano (
    id_tipodano integer NOT NULL,
    descricao character varying(50)
);


ALTER TABLE dbo.tipodano OWNER TO postgres;

--
-- Name: tipopropulsao; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.tipopropulsao (
    id_tipopropulsao integer NOT NULL,
    tiporecursologistico character varying(50),
    recursologistico character varying(50),
    id_tiporecursologistico integer,
    id_recursologistico integer,
    nome character varying(10)
);


ALTER TABLE dbo.tipopropulsao OWNER TO postgres;

--
-- Name: tiporecursologistico; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.tiporecursologistico (
    id_tiporecursologistico integer NOT NULL,
    id_recursologistico integer NOT NULL,
    tiporecursologistico character varying(50),
    id_armamento integer,
    id_sensor integer
);


ALTER TABLE dbo.tiporecursologistico OWNER TO postgres;

--
-- Name: torpedo; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.torpedo (
    id_armamento integer NOT NULL,
    tipotorpedo character varying(50),
    pai double precision,
    paias double precision,
    paiasup double precision,
    nomebusca character varying(50),
    agentelancadorabrev character varying(50),
    profundidademax integer,
    alcancemaximo double precision,
    veloccorrida integer
);


ALTER TABLE dbo.torpedo OWNER TO postgres;

--
-- Name: trajeto; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.trajeto (
    id_trajeto integer NOT NULL,
    tipotrajeto character varying(50),
    nome character varying(50),
    id_partido integer NOT NULL,
    "Login" character varying(50)
);


ALTER TABLE dbo.trajeto OWNER TO postgres;

--
-- Name: transitopatrulha; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.transitopatrulha (
    id_meiosimulado integer NOT NULL,
    velocavanco integer NOT NULL,
    taxaindiscricao double precision NOT NULL
);


ALTER TABLE dbo.transitopatrulha OWNER TO postgres;

--
-- Name: transporteaeronave; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.transporteaeronave (
    id_meiosimulado_platsup integer NOT NULL,
    id_meiosimulado_plataer integer NOT NULL
);


ALTER TABLE dbo.transporteaeronave OWNER TO postgres;

--
-- Name: um; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.um (
    id_meiosimulado_um integer NOT NULL,
    id_formatura integer,
    id_areapatrulha integer,
    ladodestino integer,
    marcacao numeric(15,9),
    distancia double precision,
    datahoratermino character varying(15),
    tipoum integer,
    incluidaencadeado integer
);


ALTER TABLE dbo.um OWNER TO postgres;

--
-- Name: visibilidadepartido; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.visibilidadepartido (
    id_partido integer NOT NULL,
    id_partido_visivel integer NOT NULL
);


ALTER TABLE dbo.visibilidadepartido OWNER TO postgres;

--
-- Data for Name: acompanhamento; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.acompanhamento (id_acompanhamento, id_meiosimulado_um, id_meiosimulado_um_acompanhamento, latitudeposgeo, longitudeposgeo, marcacao, distancia, tipoacompanhamento, removida, movimento, datahoratermino) FROM stdin;
\.
COPY dbo.acompanhamento (id_acompanhamento, id_meiosimulado_um, id_meiosimulado_um_acompanhamento, latitudeposgeo, longitudeposgeo, marcacao, distancia, tipoacompanhamento, removida, movimento, datahoratermino) FROM '$$PATH$$/5135.dat';

--
-- Data for Name: acompanhamentomav; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.acompanhamentomav (id_meiosimulado, id_finalidade, id_acompanhado, datahoramovimento) FROM stdin;
\.
COPY dbo.acompanhamentomav (id_meiosimulado, id_finalidade, id_acompanhado, datahoramovimento) FROM '$$PATH$$/5136.dat';

--
-- Data for Name: area; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.area (id_meiosimulado, id_finalidade, tabelaarea, situacao, movimento, eixo, eixoacompanhamento) FROM stdin;
\.
COPY dbo.area (id_meiosimulado, id_finalidade, tabelaarea, situacao, movimento, eixo, eixoacompanhamento) FROM '$$PATH$$/5137.dat';

--
-- Data for Name: areaambiental; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.areaambiental (id_meiosimulado, diainicio, horainicio, id_previsaometeorologica, direcaovento, horaporsol, horanascersol, profundidadecamada, perfilsonoro, propagacaoeletromagnetica, percentagemceu, temperaturamar, horaporlua, horanascerlua, faselua, rumocorrente, veloccorrente) FROM stdin;
\.
COPY dbo.areaambiental (id_meiosimulado, diainicio, horainicio, id_previsaometeorologica, direcaovento, horaporsol, horanascersol, profundidadecamada, perfilsonoro, propagacaoeletromagnetica, percentagemceu, temperaturamar, horaporlua, horanascerlua, faselua, rumocorrente, veloccorrente) FROM '$$PATH$$/5138.dat';

--
-- Data for Name: areapoligonal; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.areapoligonal (id_meiosimulado) FROM stdin;
\.
COPY dbo.areapoligonal (id_meiosimulado) FROM '$$PATH$$/5139.dat';

--
-- Data for Name: areasetorial; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.areasetorial (id_meiosimulado, limitedireito, limiteesquerdo, limiteinterno, limiteexterno) FROM stdin;
\.
COPY dbo.areasetorial (id_meiosimulado, limitedireito, limiteesquerdo, limiteinterno, limiteexterno) FROM '$$PATH$$/5140.dat';

--
-- Data for Name: armamento; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.armamento (id_armamento, nome, tabelaarmamento, cargaexplosiva, observacao, empregoarmamento) FROM stdin;
\.
COPY dbo.armamento (id_armamento, nome, tabelaarmamento, cargaexplosiva, observacao, empregoarmamento) FROM '$$PATH$$/5059.dat';

--
-- Data for Name: armasas; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.armasas (id_armamento, numprojsalva, agentelancadorabrev, alcancemaximo, tipo_armasas) FROM stdin;
\.
COPY dbo.armasas (id_armamento, numprojsalva, agentelancadorabrev, alcancemaximo, tipo_armasas) FROM '$$PATH$$/5102.dat';

--
-- Data for Name: base; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.base (id_base, nome, tipobase, tipobasenum, id_partido, extensaocais, caladomaximo, latitude, longitude, classereparo, facilidadereparo, fundeadnummaxnavio, fundeadcaladomax, capachangaragem, observacao, "Login") FROM stdin;
\.
COPY dbo.base (id_base, nome, tipobase, tipobasenum, id_partido, extensaocais, caladomaximo, latitude, longitude, classereparo, facilidadereparo, fundeadnummaxnavio, fundeadcaladomax, capachangaragem, observacao, "Login") FROM '$$PATH$$/5103.dat';

--
-- Data for Name: bomba; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.bomba (id_armamento, tipobomba, agentelancadorabrev, pai, trigrama, nomeguiagemabrev, alcanceeficaz) FROM stdin;
\.
COPY dbo.bomba (id_armamento, tipobomba, agentelancadorabrev, pai, trigrama, nomeguiagemabrev, alcanceeficaz) FROM '$$PATH$$/5104.dat';

--
-- Data for Name: canhao; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.canhao (id_armamento, calibretuboalma, cadenciatiromantida, cadenciatirorapida, numtuboalma, alcancemaximo, alcanceeficaz) FROM stdin;
\.
COPY dbo.canhao (id_armamento, calibretuboalma, cadenciatiromantida, cadenciatirorapida, numtuboalma, alcancemaximo, alcanceeficaz) FROM '$$PATH$$/5105.dat';

--
-- Data for Name: classeefetivapista; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.classeefetivapista (classe_atual, classe_efetiva) FROM stdin;
\.
COPY dbo.classeefetivapista (classe_atual, classe_efetiva) FROM '$$PATH$$/5060.dat';

--
-- Data for Name: codigoerros; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.codigoerros (codigoerro, storedprocedure, erro, msgerro, observacao) FROM stdin;
\.
COPY dbo.codigoerros (codigoerro, storedprocedure, erro, msgerro, observacao) FROM '$$PATH$$/5061.dat';

--
-- Data for Name: componentetarefa; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.componentetarefa (id_meiosimulado, id_organizacaotarefa, situacao, id_gt) FROM stdin;
\.
COPY dbo.componentetarefa (id_meiosimulado, id_organizacaotarefa, situacao, id_gt) FROM '$$PATH$$/5141.dat';

--
-- Data for Name: configuracao; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.configuracao (id_configuracao, id_meiosimulado, codconfiguracao, codraioacaoconfiguracao, caracteristicaconfiguracao, carga, capactanquecombexterno, qtdetanques, listacabidestanque, coeficientepos, raioacaoaa, raioacaobb, qtdebrs_ativa, alcancemaximobrs, listacabidesbrs_ativa, qtderc, listacabidesrc, classecaracteristica, qtdebrs_passiva, listacabidesbrs_passiva) FROM stdin;
\.
COPY dbo.configuracao (id_configuracao, id_meiosimulado, codconfiguracao, codraioacaoconfiguracao, caracteristicaconfiguracao, carga, capactanquecombexterno, qtdetanques, listacabidestanque, coeficientepos, raioacaoaa, raioacaobb, qtdebrs_ativa, alcancemaximobrs, listacabidesbrs_ativa, qtderc, listacabidesrc, classecaracteristica, qtdebrs_passiva, listacabidesbrs_passiva) FROM '$$PATH$$/5142.dat';

--
-- Data for Name: dano; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.dano (id_plataforma, m_percentdanototal, m_duracaomaximareparobase, m_valorapresentado) FROM stdin;
\.
COPY dbo.dano (id_plataforma, m_percentdanototal, m_duracaomaximareparobase, m_valorapresentado) FROM '$$PATH$$/5143.dat';

--
-- Data for Name: danoespecifico; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.danoespecifico (id_danoespecifico, id_tipodano, id_plataforma, localreparo, temporeparomar, dhinicioreparomar_str, temporeparobase, dhinicioreparobase_str, perdas) FROM stdin;
\.
COPY dbo.danoespecifico (id_danoespecifico, id_tipodano, id_plataforma, localreparo, temporeparomar, dhinicioreparomar_str, temporeparobase, dhinicioreparobase_str, perdas) FROM '$$PATH$$/5144.dat';

--
-- Data for Name: dd_propulsao; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.dd_propulsao (id_propulsao, tiporecursologistico, recursologistico, id_tiporecursologistico, id_recursologistico, nome) FROM stdin;
\.
COPY dbo.dd_propulsao (id_propulsao, tiporecursologistico, recursologistico, id_tiporecursologistico, id_recursologistico, nome) FROM '$$PATH$$/5062.dat';

--
-- Data for Name: dotacaoarmamento; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.dotacaoarmamento (id_armamento, id_localizacao, qtdedotacao, qtdercb, qtdecons, reparo, listacabidesarm, qtdelancavariados, dano_armamento) FROM stdin;
\.
COPY dbo.dotacaoarmamento (id_armamento, id_localizacao, qtdedotacao, qtdercb, qtdecons, reparo, listacabidesarm, qtdelancavariados, dano_armamento) FROM '$$PATH$$/5145.dat';

--
-- Data for Name: dotacaosensor; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.dotacaosensor (id_dotacaosensor, id_sensor, id_localizacao, situacao, configurado) FROM stdin;
\.
COPY dbo.dotacaosensor (id_dotacaosensor, id_sensor, id_localizacao, situacao, configurado) FROM '$$PATH$$/5146.dat';

--
-- Data for Name: finalidadeacompanhamentomav; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.finalidadeacompanhamentomav (id_finalidade, nome) FROM stdin;
\.
COPY dbo.finalidadeacompanhamentomav (id_finalidade, nome) FROM '$$PATH$$/5063.dat';

--
-- Data for Name: finalidadearea; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.finalidadearea (id_finalidadearea, nome) FROM stdin;
\.
COPY dbo.finalidadearea (id_finalidadearea, nome) FROM '$$PATH$$/5064.dat';

--
-- Data for Name: finalidadelinha; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.finalidadelinha (id_finalidadelinha, nome) FROM stdin;
\.
COPY dbo.finalidadelinha (id_finalidadelinha, nome) FROM '$$PATH$$/5065.dat';

--
-- Data for Name: finalidadepontonotavel; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.finalidadepontonotavel (id_finalidadepontonotavel, nome) FROM stdin;
\.
COPY dbo.finalidadepontonotavel (id_finalidadepontonotavel, nome) FROM '$$PATH$$/5066.dat';

--
-- Data for Name: foguete; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.foguete (id_armamento, pai, agentelancadorabrev, trigrama, alcanceeficaz) FROM stdin;
\.
COPY dbo.foguete (id_armamento, pai, agentelancadorabrev, trigrama, alcanceeficaz) FROM '$$PATH$$/5106.dat';

--
-- Data for Name: formatura; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.formatura (id_formatura, id_modeloformatura, id_guiaformatura, eixo, marcacao_guia, distancia_guia, id_um, "Login") FROM stdin;
\.
COPY dbo.formatura (id_formatura, id_modeloformatura, id_guiaformatura, eixo, marcacao_guia, distancia_guia, id_um, "Login") FROM '$$PATH$$/5147.dat';

--
-- Data for Name: glossario; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.glossario (id, compactado, descompactado) FROM stdin;
\.
COPY dbo.glossario (id, compactado, descompactado) FROM '$$PATH$$/5067.dat';

--
-- Data for Name: interceptacao; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.interceptacao (id_interceptacao, id_meiosimulado_um, id_meiosimulado_interceptar, id_meiosimulado_area, id_trajeto, id_pontotrajeto, ladodestino, velocmanobra, latitudeposgeo, longitudeposgeo, marcacao, distancia, datahoratermino, tipointerceptacao, removida, nomebase, movimento) FROM stdin;
\.
COPY dbo.interceptacao (id_interceptacao, id_meiosimulado_um, id_meiosimulado_interceptar, id_meiosimulado_area, id_trajeto, id_pontotrajeto, ladodestino, velocmanobra, latitudeposgeo, longitudeposgeo, marcacao, distancia, datahoratermino, tipointerceptacao, removida, nomebase, movimento) FROM '$$PATH$$/5148.dat';

--
-- Data for Name: itemconfiguracao; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.itemconfiguracao (id_itemconfiguracao, id_configuracao, id_armamento, id_sensor, quantidade, listacabideitem) FROM stdin;
\.
COPY dbo.itemconfiguracao (id_itemconfiguracao, id_configuracao, id_armamento, id_sensor, quantidade, listacabideitem) FROM '$$PATH$$/5149.dat';

--
-- Data for Name: linha; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.linha (id_meiosimulado, id_finalidade, tabelalinha) FROM stdin;
\.
COPY dbo.linha (id_meiosimulado, id_finalidade, tabelalinha) FROM '$$PATH$$/5150.dat';

--
-- Data for Name: linhamarcacao; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.linhamarcacao (id_meiosimulado, marcacao, distancia) FROM stdin;
\.
COPY dbo.linhamarcacao (id_meiosimulado, marcacao, distancia) FROM '$$PATH$$/5151.dat';

--
-- Data for Name: linhapoligonal; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.linhapoligonal (id_meiosimulado) FROM stdin;
\.
COPY dbo.linhapoligonal (id_meiosimulado) FROM '$$PATH$$/5152.dat';

--
-- Data for Name: localizacao; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.localizacao (id_localizacao, id_meiosimulado_platsup, id_meiosimulado_platsub, id_meiosimulado_plataer, id_base, id_meiosimulado_platterra) FROM stdin;
\.
COPY dbo.localizacao (id_localizacao, id_meiosimulado_platsup, id_meiosimulado_platsub, id_meiosimulado_plataer, id_base, id_meiosimulado_platterra) FROM '$$PATH$$/5153.dat';

--
-- Data for Name: logerrossp; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.logerrossp (id_erro, dh_erro, nomesp, num_secao, codigomssql, usuarioconectado, aplicacao, mensagemerro) FROM stdin;
\.
COPY dbo.logerrossp (id_erro, dh_erro, nomesp, num_secao, codigomssql, usuarioconectado, aplicacao, mensagemerro) FROM '$$PATH$$/5068.dat';

--
-- Data for Name: logtransacoes; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.logtransacoes (idlog, nomesp, parametrossp, datahora) FROM stdin;
\.
COPY dbo.logtransacoes (idlog, nomesp, parametrossp, datahora) FROM '$$PATH$$/5069.dat';

--
-- Data for Name: macambiente; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.macambiente (idpersistencia, loginusuario, "TimeStamp", nomepersistencia, fgver, frver, nomecartavector, intervaloatualizacao, tamanhosimbologia, estadobotaoatualizacao, contadoracompmav, contadormodeloplano, idvisaoativa, prefixodefiguravisivel) FROM stdin;
\.
COPY dbo.macambiente (idpersistencia, loginusuario, "TimeStamp", nomepersistencia, fgver, frver, nomecartavector, intervaloatualizacao, tamanhosimbologia, estadobotaoatualizacao, contadoracompmav, contadormodeloplano, idvisaoativa, prefixodefiguravisivel) FROM '$$PATH$$/5070.dat';

--
-- Data for Name: macarmamentovisivel; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.macarmamentovisivel (idpersistencia, tipomeio, idmeio, idarmamento, nomearma) FROM stdin;
\.
COPY dbo.macarmamentovisivel (idpersistencia, tipomeio, idmeio, idarmamento, nomearma) FROM '$$PATH$$/5107.dat';

--
-- Data for Name: maccartaraster; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.maccartaraster (idpersistencia, idcartaraster, nomecartaraster, escalade, escalapara, resolucaox, resolucaoy, posicaomediasegx, posicaomediasegy, visivel, rectlimitesegleft, rectlimitesegtop, rectlimitesegright, rectlimitesegbottom, copymode, idescala) FROM stdin;
\.
COPY dbo.maccartaraster (idpersistencia, idcartaraster, nomecartaraster, escalade, escalapara, resolucaox, resolucaoy, posicaomediasegx, posicaomediasegy, visivel, rectlimitesegleft, rectlimitesegtop, rectlimitesegright, rectlimitesegbottom, copymode, idescala) FROM '$$PATH$$/5108.dat';

--
-- Data for Name: macdesenho; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.macdesenho (idpersistencia, nomearquivodesenho, arquivodesenho) FROM stdin;
\.
COPY dbo.macdesenho (idpersistencia, nomearquivodesenho, arquivodesenho) FROM '$$PATH$$/5109.dat';

--
-- Data for Name: macfiltropartido; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.macfiltropartido (idpersistencia, idvisao, idpartido, visivel) FROM stdin;
\.
COPY dbo.macfiltropartido (idpersistencia, idvisao, idpartido, visivel) FROM '$$PATH$$/5133.dat';

--
-- Data for Name: macmarcador; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.macmarcador (idpersistencia, idvisao, idmarcador, nome, escala, latitude, longitude, deslocx, deslocy) FROM stdin;
\.
COPY dbo.macmarcador (idpersistencia, idvisao, idmarcador, nome, escala, latitude, longitude, deslocx, deslocy) FROM '$$PATH$$/5134.dat';

--
-- Data for Name: macmeiovisivel; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.macmeiovisivel (idpersistencia, tipomeio, idmeio) FROM stdin;
\.
COPY dbo.macmeiovisivel (idpersistencia, tipomeio, idmeio) FROM '$$PATH$$/5110.dat';

--
-- Data for Name: macmodeloplano; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.macmodeloplano (idpersistencia, idplano, nomeplano, logincontrolador, latorigem, longorigem, eixo, idmodelo, idpartido) FROM stdin;
\.
COPY dbo.macmodeloplano (idpersistencia, idplano, nomeplano, logincontrolador, latorigem, longorigem, eixo, idmodelo, idpartido) FROM '$$PATH$$/5111.dat';

--
-- Data for Name: macplanovisivel; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.macplanovisivel (idpersistencia, idplano) FROM stdin;
\.
COPY dbo.macplanovisivel (idpersistencia, idplano) FROM '$$PATH$$/5112.dat';

--
-- Data for Name: macsensorvisivel; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.macsensorvisivel (idpersistencia, tipomeio, idmeio, idsensor, nomesensor) FROM stdin;
\.
COPY dbo.macsensorvisivel (idpersistencia, tipomeio, idmeio, idsensor, nomesensor) FROM '$$PATH$$/5113.dat';

--
-- Data for Name: mactrajetovisivel; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.mactrajetovisivel (idpersistencia, idtrajeto) FROM stdin;
\.
COPY dbo.mactrajetovisivel (idpersistencia, idtrajeto) FROM '$$PATH$$/5114.dat';

--
-- Data for Name: macvisao; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.macvisao (idpersistencia, idvisao, windowleft, windowtop, windowwidth, windowheight, windowstate, cormar, corbrasil, corisobatimetrica, corcontinente, corlago, corrio, escala, fo, lo, deslocmovex, deslocmovey, ambfigura, ambsimbfigura, ambnomefigura, ambnomeconexao, btngradevisivel, btndestruidaabatida, btnmsliberado, btnmslibcontato) FROM stdin;
\.
COPY dbo.macvisao (idpersistencia, idvisao, windowleft, windowtop, windowwidth, windowheight, windowstate, cormar, corbrasil, corisobatimetrica, corcontinente, corlago, corrio, escala, fo, lo, deslocmovex, deslocmovey, ambfigura, ambsimbfigura, ambnomefigura, ambnomeconexao, btngradevisivel, btndestruidaabatida, btnmsliberado, btnmslibcontato) FROM '$$PATH$$/5115.dat';

--
-- Data for Name: macvisualarma; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.macvisualarma (idpersistencia, tipomeio, idmeio, tipoalcancearmamento, alcancearmamentovisivel, compreenchimento) FROM stdin;
\.
COPY dbo.macvisualarma (idpersistencia, tipomeio, idmeio, tipoalcancearmamento, alcancearmamentovisivel, compreenchimento) FROM '$$PATH$$/5116.dat';

--
-- Data for Name: macvisualsensor; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.macvisualsensor (idpersistencia, tipomeio, idmeio, tipoalcancesensor, alcancesensorvisivel, alcancemagevisivel, compreenchimento) FROM stdin;
\.
COPY dbo.macvisualsensor (idpersistencia, tipomeio, idmeio, tipoalcancesensor, alcancesensorvisivel, alcancemagevisivel, compreenchimento) FROM '$$PATH$$/5117.dat';

--
-- Data for Name: meioexterno; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.meioexterno (id_meiosimulado, tipo, subtipo, dh_informacao, observacoes, origem, id_na_origem) FROM stdin;
\.
COPY dbo.meioexterno (id_meiosimulado, tipo, subtipo, dh_informacao, observacoes, origem, id_na_origem) FROM '$$PATH$$/5154.dat';

--
-- Data for Name: meiosimulado; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.meiosimulado (id_meiosimulado, nome, acaoms, id_partido, rumo, velocavanco, latitude, longitude, id_mss, datahora, tabelameiosimulado, id_trajeto, id_um, veloctrajeto, proximoponto, trajeto_ultimoponto, plano_voltasrestantes, id_plano, "Login", observacao) FROM stdin;
\.
COPY dbo.meiosimulado (id_meiosimulado, nome, acaoms, id_partido, rumo, velocavanco, latitude, longitude, id_mss, datahora, tabelameiosimulado, id_trajeto, id_um, veloctrajeto, proximoponto, trajeto_ultimoponto, plano_voltasrestantes, id_plano, "Login", observacao) FROM '$$PATH$$/5155.dat';

--
-- Data for Name: meiosimuladoliberado; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.meiosimuladoliberado (id_meiosimulado, id_partido, id_papel, logincontrolador, tipomeiosimulado, identificacaoocultada) FROM stdin;
\.
COPY dbo.meiosimuladoliberado (id_meiosimulado, id_partido, id_papel, logincontrolador, tipomeiosimulado, identificacaoocultada) FROM '$$PATH$$/5156.dat';

--
-- Data for Name: meiosimuladomav; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.meiosimuladomav (id_meiosimulado, nome, acaoms, id_partido, rumo, velocavanco, latitude, longitude, id_mss, datahora, tabelameiosimulado, id_trajeto, id_um, veloctrajeto, proximoponto, trajeto_ultimoponto, plano_voltasrestantes, id_plano, "Login", observacao) FROM stdin;
\.
COPY dbo.meiosimuladomav (id_meiosimulado, nome, acaoms, id_partido, rumo, velocavanco, latitude, longitude, id_mss, datahora, tabelameiosimulado, id_trajeto, id_um, veloctrajeto, proximoponto, trajeto_ultimoponto, plano_voltasrestantes, id_plano, "Login", observacao) FROM '$$PATH$$/5157.dat';

--
-- Data for Name: mina; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.mina (id_armamento, agentelancadorabrev, atuacaoarmamentoabrev, peso, profundidade, tipoalvo, tipomina) FROM stdin;
\.
COPY dbo.mina (id_armamento, agentelancadorabrev, atuacaoarmamentoabrev, peso, profundidade, tipoalvo, tipomina) FROM '$$PATH$$/5118.dat';

--
-- Data for Name: missil; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.missil (id_armamento, pai, pam, paa, nomeguiagemabrev, veloc, agentelancadorabrev, trigrama, tipomissil, tipomissilnum, alcanceeficaz) FROM stdin;
\.
COPY dbo.missil (id_armamento, pai, pam, paa, nomeguiagemabrev, veloc, agentelancadorabrev, trigrama, tipomissil, tipomissilnum, alcanceeficaz) FROM '$$PATH$$/5119.dat';

--
-- Data for Name: modeloformatura; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.modeloformatura (id_modeloformatura, nome, tipoformatura, patrulhasetores) FROM stdin;
\.
COPY dbo.modeloformatura (id_modeloformatura, nome, tipoformatura, patrulhasetores) FROM '$$PATH$$/5072.dat';

--
-- Data for Name: modeloplano; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.modeloplano (id_modeloplano, nome, tipoplano, id_partido) FROM stdin;
\.
COPY dbo.modeloplano (id_modeloplano, nome, tipoplano, id_partido) FROM '$$PATH$$/5120.dat';

--
-- Data for Name: mss_constante; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.mss_constante (id_mssconstante, nome, id_tiporecursologisitico, id_recursologistico) FROM stdin;
\.
COPY dbo.mss_constante (id_mssconstante, nome, id_tiporecursologisitico, id_recursologistico) FROM '$$PATH$$/5071.dat';

--
-- Data for Name: nri; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.nri (id_meiosimulado, velocavanco, nri) FROM stdin;
\.
COPY dbo.nri (id_meiosimulado, velocavanco, nri) FROM '$$PATH$$/5158.dat';

--
-- Data for Name: organizacaotarefa; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.organizacaotarefa (id_organizacaotarefa, nome, id_organizacaotarefa_sup, situacao, horaativacao, tipoativacao, id_partido) FROM stdin;
\.
COPY dbo.organizacaotarefa (id_organizacaotarefa, nome, id_organizacaotarefa_sup, situacao, horaativacao, tipoativacao, id_partido) FROM '$$PATH$$/5121.dat';

--
-- Data for Name: organizacaotarefaliberada; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.organizacaotarefaliberada (id_organizacaotarefa, id_partido, id_papel, logincontrolador) FROM stdin;
\.
COPY dbo.organizacaotarefaliberada (id_organizacaotarefa, id_partido, id_papel, logincontrolador) FROM '$$PATH$$/5122.dat';

--
-- Data for Name: partido; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.partido (id_partido, nome, codigocor, nomecor, neutro) FROM stdin;
\.
COPY dbo.partido (id_partido, nome, codigocor, nomecor, neutro) FROM '$$PATH$$/5074.dat';

--
-- Data for Name: pdv; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.pdv (id_pdv, login_de, grta, sala, "Data", criacao, liberacao, seqnumaltpdv, offsetprimeiroevento, "XML", controladornotificado, identificacao, tipo, invisivel) FROM stdin;
\.
COPY dbo.pdv (id_pdv, login_de, grta, sala, "Data", criacao, liberacao, seqnumaltpdv, offsetprimeiroevento, "XML", controladornotificado, identificacao, tipo, invisivel) FROM '$$PATH$$/5073.dat';

--
-- Data for Name: pista; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.pista (id_pista, classe, capaccarga, comppista, pavimentacao) FROM stdin;
\.
COPY dbo.pista (id_pista, classe, capaccarga, comppista, pavimentacao) FROM '$$PATH$$/5075.dat';

--
-- Data for Name: pistabase; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.pistabase (id_pista, id_base, quantpista) FROM stdin;
\.
COPY dbo.pistabase (id_pista, id_base, quantpista) FROM '$$PATH$$/5123.dat';

--
-- Data for Name: plano; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.plano (id_plano, id_modeloplano, id_ms_referencia, id_partido, id_base_referencia, nome, latitude_ref, longitude_ref, distancia_ref, marcacao_ref, eixo, movimento, "Login") FROM stdin;
\.
COPY dbo.plano (id_plano, id_modeloplano, id_ms_referencia, id_partido, id_base_referencia, nome, latitude_ref, longitude_ref, distancia_ref, marcacao_ref, eixo, movimento, "Login") FROM '$$PATH$$/5159.dat';

--
-- Data for Name: plantapropulsora; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.plantapropulsora (id_plantapropulsora, tipoplanta, descricao, designacaoplanta) FROM stdin;
\.
COPY dbo.plantapropulsora (id_plantapropulsora, tipoplanta, descricao, designacaoplanta) FROM '$$PATH$$/5076.dat';

--
-- Data for Name: plataformaaerea; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.plataformaaerea (id_meiosimulado, id_localizacao, id_localizacaopousada, nometipoaeronave, id_situacaoplataforma, modelo, embarcado, tipoasa, indicesortidas, horasmes, tipomotoraeronave, qtdemotores, propulsao, empuxo, consumomedio, altura, comprimento, largura, hangaragems2, areaasas, diametrora, pesobasico, pesomaximo, pesosupasa, pesopotencia, cargautil, geometriavariavel, razaosubida, tetoservico, tetovoolibrado, velocmaxalto, velocmaxbaixo, veloccruzeiroalto, veloccruzeirobaixo, altitude, horizontalsubida, navegacao, bloqueio, equipamentobloqueio, empregoaeronave, reabastecimentovoo, operacaoaeronave, interceptacaoaeronave, ataqueaeronave, altitudeperfilvooa, altitudeperfilvoob, autonomia, perfilvoo, cteconsumo1, cteconsumo2, ctepatrulha, danoveloc, iff, mage, veloclogistica, id_configuracaocorrente, hf, uhf, vhf, observacao, id_pista, id_tipopropulsao, id_recursopropulsao, danosensor, outrossistemascomunicacao, sigla, emespera, dhterminoespera) FROM stdin;
\.
COPY dbo.plataformaaerea (id_meiosimulado, id_localizacao, id_localizacaopousada, nometipoaeronave, id_situacaoplataforma, modelo, embarcado, tipoasa, indicesortidas, horasmes, tipomotoraeronave, qtdemotores, propulsao, empuxo, consumomedio, altura, comprimento, largura, hangaragems2, areaasas, diametrora, pesobasico, pesomaximo, pesosupasa, pesopotencia, cargautil, geometriavariavel, razaosubida, tetoservico, tetovoolibrado, velocmaxalto, velocmaxbaixo, veloccruzeiroalto, veloccruzeirobaixo, altitude, horizontalsubida, navegacao, bloqueio, equipamentobloqueio, empregoaeronave, reabastecimentovoo, operacaoaeronave, interceptacaoaeronave, ataqueaeronave, altitudeperfilvooa, altitudeperfilvoob, autonomia, perfilvoo, cteconsumo1, cteconsumo2, ctepatrulha, danoveloc, iff, mage, veloclogistica, id_configuracaocorrente, hf, uhf, vhf, observacao, id_pista, id_tipopropulsao, id_recursopropulsao, danosensor, outrossistemascomunicacao, sigla, emespera, dhterminoespera) FROM '$$PATH$$/5160.dat';

--
-- Data for Name: plataformasubmarina; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.plataformasubmarina (id_meiosimulado, id_base, nomeclasse, id_situacaoplataforma, deslocamentosup, deslocamentoimerso, boca, calado, comprimento, esnorquel, coeficienteseguranca, autonomia, manutencao, numtubos, velocecsup, velocecimerso, velocmaximerso, velocmmsuperficie, velocmmesnorquel, velocmmnuclear, ravecsup, ravelocmaximerso, ravelocmmsup, ravelocmmesnorquel, ravelocecimerso, ravelocmmnuclear, consumovelocecsup, consumovelocecimerso, consumovelocmaximerso, consumovelocmmsup, consumovelocmmesnorquel, cargamaxima, cargaatual, ctedescarga1, ctedescarga2, profundidade, observacao, propulsao, cteconsumo1, cteconsumo2, ctepatrulha, danoveloc, iff, mage, bandamage, despist, vlf, hf_lf, vhf, uhf, cotamaxoperac, veloclogistica, id_plantapropulsora, id_tipopropulsao, id_recursopropulsao, danosensor, sigla, m_danocoms_hf, m_danocoms_vhf, m_danocoms_vlf, m_danocoms_hf_lf) FROM stdin;
\.
COPY dbo.plataformasubmarina (id_meiosimulado, id_base, nomeclasse, id_situacaoplataforma, deslocamentosup, deslocamentoimerso, boca, calado, comprimento, esnorquel, coeficienteseguranca, autonomia, manutencao, numtubos, velocecsup, velocecimerso, velocmaximerso, velocmmsuperficie, velocmmesnorquel, velocmmnuclear, ravecsup, ravelocmaximerso, ravelocmmsup, ravelocmmesnorquel, ravelocecimerso, ravelocmmnuclear, consumovelocecsup, consumovelocecimerso, consumovelocmaximerso, consumovelocmmsup, consumovelocmmesnorquel, cargamaxima, cargaatual, ctedescarga1, ctedescarga2, profundidade, observacao, propulsao, cteconsumo1, cteconsumo2, ctepatrulha, danoveloc, iff, mage, bandamage, despist, vlf, hf_lf, vhf, uhf, cotamaxoperac, veloclogistica, id_plantapropulsora, id_tipopropulsao, id_recursopropulsao, danosensor, sigla, m_danocoms_hf, m_danocoms_vhf, m_danocoms_vlf, m_danocoms_hf_lf) FROM '$$PATH$$/5161.dat';

--
-- Data for Name: plataformasuperficie; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.plataformasuperficie (id_meiosimulado, id_base, nomeclasse, id_situacaoplataforma, veloclogistica, cteconsumo1, cteconsumo2, ctepatrulha, danoveloc, cme, bandacme, iff, mage, bandamage, tipoplatsuperficienum, tipoplatsuperficie, deslocamento, calado, comprimento, boca, velocec, velocmm, velocmax, ravelocec, ravelocmm, ravelocmax, consumovelocec, consumovelocmm, consumovelocmax, propulsao, capacdocagem, capachangaragem, areahangarocupada, id_pista, observacao, janela, vhf, uhf, hf, guia, id_tipopropulsao, id_recursopropulsao, id_plantapropulsora, danosensor, sigla, m_danoreabastecimento, m_danoopsaereashe, m_danoopsaereasasafixa, m_danocoms_hf, m_danocoms_vhf, m_danocoms_uhf, ehcapitanea) FROM stdin;
\.
COPY dbo.plataformasuperficie (id_meiosimulado, id_base, nomeclasse, id_situacaoplataforma, veloclogistica, cteconsumo1, cteconsumo2, ctepatrulha, danoveloc, cme, bandacme, iff, mage, bandamage, tipoplatsuperficienum, tipoplatsuperficie, deslocamento, calado, comprimento, boca, velocec, velocmm, velocmax, ravelocec, ravelocmm, ravelocmax, consumovelocec, consumovelocmm, consumovelocmax, propulsao, capacdocagem, capachangaragem, areahangarocupada, id_pista, observacao, janela, vhf, uhf, hf, guia, id_tipopropulsao, id_recursopropulsao, id_plantapropulsora, danosensor, sigla, m_danoreabastecimento, m_danoopsaereashe, m_danoopsaereasasafixa, m_danocoms_hf, m_danocoms_vhf, m_danocoms_uhf, ehcapitanea) FROM '$$PATH$$/5162.dat';

--
-- Data for Name: plataformaterrestre; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.plataformaterrestre (id_meiosimulado, tipoplataformaterrestrenum, tipoplataformaterrestre, id_situacaoplataforma, danoveloc, danosensor, velocmax, ravelocmax, consumovelocmax, id_tipopropulsao, id_recursopropulsao, observacao, sigla, id_localizacaoembarcada) FROM stdin;
\.
COPY dbo.plataformaterrestre (id_meiosimulado, tipoplataformaterrestrenum, tipoplataformaterrestre, id_situacaoplataforma, danoveloc, danosensor, velocmax, ravelocmax, consumovelocmax, id_tipopropulsao, id_recursopropulsao, observacao, sigla, id_localizacaoembarcada) FROM '$$PATH$$/5163.dat';

--
-- Data for Name: pontonotavel; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.pontonotavel (id_meiosimulado, id_finalidade) FROM stdin;
\.
COPY dbo.pontonotavel (id_meiosimulado, id_finalidade) FROM '$$PATH$$/5164.dat';

--
-- Data for Name: pontosarea; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.pontosarea (id_pontosarea, id_meiosimulado, nome, marcacao, distancia) FROM stdin;
\.
COPY dbo.pontosarea (id_pontosarea, id_meiosimulado, nome, marcacao, distancia) FROM '$$PATH$$/5165.dat';

--
-- Data for Name: pontoslinha; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.pontoslinha (id_meiosimulado, id_pontoslinha, nome, marcacao, distancia) FROM stdin;
\.
COPY dbo.pontoslinha (id_meiosimulado, id_pontoslinha, nome, marcacao, distancia) FROM '$$PATH$$/5166.dat';

--
-- Data for Name: pontosmodeloformatura; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.pontosmodeloformatura (id_pontosmodeloformatura, id_modeloformatura, nome, marcacao, distancia) FROM stdin;
\.
COPY dbo.pontosmodeloformatura (id_pontosmodeloformatura, id_modeloformatura, nome, marcacao, distancia) FROM '$$PATH$$/5124.dat';

--
-- Data for Name: pontosmodeloplano; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.pontosmodeloplano (id_pontosmodeloplano, id_modeloplano, nome, marcacao, distancia) FROM stdin;
\.
COPY dbo.pontosmodeloplano (id_pontosmodeloplano, id_modeloplano, nome, marcacao, distancia) FROM '$$PATH$$/5125.dat';

--
-- Data for Name: pontostrajeto; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.pontostrajeto (id_pontos, id_trajeto, nome, latitude, longitude, datahora, veloc) FROM stdin;
\.
COPY dbo.pontostrajeto (id_pontos, id_trajeto, nome, latitude, longitude, datahora, veloc) FROM '$$PATH$$/5126.dat';

--
-- Data for Name: postosformatura; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.postosformatura (id_postosformatura, id_formatura, id_ms_posto, nome, marcacao, distancia) FROM stdin;
\.
COPY dbo.postosformatura (id_postosformatura, id_formatura, id_ms_posto, nome, marcacao, distancia) FROM '$$PATH$$/5167.dat';

--
-- Data for Name: previsaometeorologica; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.previsaometeorologica (id_previsaometeorologica, tempo, velocvento, pressaoatm, estadomar, visibilidade, teto, degradacaosensores, maximaveloc, operacoesaereas) FROM stdin;
\.
COPY dbo.previsaometeorologica (id_previsaometeorologica, tempo, velocvento, pressaoatm, estadomar, visibilidade, teto, degradacaosensores, maximaveloc, operacoesaereas) FROM '$$PATH$$/5077.dat';

--
-- Data for Name: recursopropulsao; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.recursopropulsao (id_recursopropulsao, id_recursologistico, id_tipopropulsao) FROM stdin;
\.
COPY dbo.recursopropulsao (id_recursopropulsao, id_recursologistico, id_tipopropulsao) FROM '$$PATH$$/5168.dat';

--
-- Data for Name: recursoslogisticos; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.recursoslogisticos (id_recursologistico, id_localizacao, nome, nomereclog_num, tipo, tiporeclog_num, categoria, capacarmazenamento, qtdercb, qtdeconsfnc, numerotomadas, numerotanques, capacmaxtanque, vazaofnc, vazaorcb, id_armamento, id_sensor) FROM stdin;
\.
COPY dbo.recursoslogisticos (id_recursologistico, id_localizacao, nome, nomereclog_num, tipo, tiporeclog_num, categoria, capacarmazenamento, qtdercb, qtdeconsfnc, numerotomadas, numerotanques, capacmaxtanque, vazaofnc, vazaorcb, id_armamento, id_sensor) FROM '$$PATH$$/5169.dat';

--
-- Data for Name: sensor; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.sensor (id_sensor, tiposensor, nome, modelo, alcancemaximo, emprego, modooperacao, dano_sensor) FROM stdin;
\.
COPY dbo.sensor (id_sensor, tiposensor, nome, modelo, alcancemaximo, emprego, modooperacao, dano_sensor) FROM '$$PATH$$/5093.dat';

--
-- Data for Name: situacaoplataforma; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.situacaoplataforma (id_situacaoplataforma, nome, tipoplataforma, constante) FROM stdin;
\.
COPY dbo.situacaoplataforma (id_situacaoplataforma, nome, tipoplataforma, constante) FROM '$$PATH$$/5094.dat';

--
-- Data for Name: ssgn_acesso; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.ssgn_acesso (id_funcao, id_recurso, id_fase, acesso) FROM stdin;
\.
COPY dbo.ssgn_acesso (id_funcao, id_recurso, id_fase, acesso) FROM '$$PATH$$/5078.dat';

--
-- Data for Name: ssgn_auditoria; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.ssgn_auditoria (datahora, maquina, loginwindows, "Login", bancodados, id_fase, id_funcao, id_recurso, id_papel, situacao, observacao) FROM stdin;
\.
COPY dbo.ssgn_auditoria (datahora, maquina, loginwindows, "Login", bancodados, id_fase, id_funcao, id_recurso, id_papel, situacao, observacao) FROM '$$PATH$$/5079.dat';

--
-- Data for Name: ssgn_comando; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.ssgn_comando (id_mss, indice, datahoraexec, "Login", statuscomando, feedback, id_mcc, comandoxml, offsetenc, id_fab) FROM stdin;
\.
COPY dbo.ssgn_comando (id_mss, indice, datahoraexec, "Login", statuscomando, feedback, id_mcc, comandoxml, offsetenc, id_fab) FROM '$$PATH$$/5081.dat';

--
-- Data for Name: ssgn_comando_pdv; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.ssgn_comando_pdv (id_pdv, id_mss) FROM stdin;
\.
COPY dbo.ssgn_comando_pdv (id_pdv, id_mss) FROM '$$PATH$$/5127.dat';

--
-- Data for Name: ssgn_comando_preab; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.ssgn_comando_preab (id_preab, id_mss) FROM stdin;
\.
COPY dbo.ssgn_comando_preab (id_preab, id_mss) FROM '$$PATH$$/5080.dat';

--
-- Data for Name: ssgn_controlejogo; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.ssgn_controlejogo (jogo, versao, data_criacao, id_fase, datahorainicreal, datahorainicsimulada, datahoraatualreal, datahoraatualsimulada, status, marchareal, marchasimulada, delta_t, statusbackup, taxabackup, statusdeteccao, taxadeteccao, taxaatuplataerea, taxaatuplatsuperficie, taxaatuplatsubmarina, taxaatumeiosimulado, contatuplataereas, contatuplatsuperficie, contatuplatsubmarina, contatumeiosimulado, proximoidmss, constidpass) FROM stdin;
\.
COPY dbo.ssgn_controlejogo (jogo, versao, data_criacao, id_fase, datahorainicreal, datahorainicsimulada, datahoraatualreal, datahoraatualsimulada, status, marchareal, marchasimulada, delta_t, statusbackup, taxabackup, statusdeteccao, taxadeteccao, taxaatuplataerea, taxaatuplatsuperficie, taxaatuplatsubmarina, taxaatumeiosimulado, contatuplataereas, contatuplatsuperficie, contatuplatsubmarina, contatumeiosimulado, proximoidmss, constidpass) FROM '$$PATH$$/5128.dat';

--
-- Data for Name: ssgn_exportacao_processamento; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.ssgn_exportacao_processamento (id_exportacao_processada, id_elemento_exportado, tipoelementoexportacao, nomeelemento, id_meiosimulado_importado, id_modeloplano_importado, id_trajeto_importado, id_partido, elementoimportado) FROM stdin;
\.
COPY dbo.ssgn_exportacao_processamento (id_exportacao_processada, id_elemento_exportado, tipoelementoexportacao, nomeelemento, id_meiosimulado_importado, id_modeloplano_importado, id_trajeto_importado, id_partido, elementoimportado) FROM '$$PATH$$/5129.dat';

--
-- Data for Name: ssgn_exportacaomav; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.ssgn_exportacaomav (id_exportacaomav, "Login", logincontrolador, nome, conteudoxml) FROM stdin;
\.
COPY dbo.ssgn_exportacaomav (id_exportacaomav, "Login", logincontrolador, nome, conteudoxml) FROM '$$PATH$$/5082.dat';

--
-- Data for Name: ssgn_fase; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.ssgn_fase (id_fase, nome) FROM stdin;
\.
COPY dbo.ssgn_fase (id_fase, nome) FROM '$$PATH$$/5083.dat';

--
-- Data for Name: ssgn_hierarquiacomponente; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.ssgn_hierarquiacomponente (id_hierarquiacomponente, id_tipocomponente, codigo_mcc, codigo_pai, stored_procedure, camposapresentados, campoenviado, composicao, camposparametro) FROM stdin;
\.
COPY dbo.ssgn_hierarquiacomponente (id_hierarquiacomponente, id_tipocomponente, codigo_mcc, codigo_pai, stored_procedure, camposapresentados, campoenviado, composicao, camposparametro) FROM '$$PATH$$/5130.dat';

--
-- Data for Name: ssgn_itemacesso; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.ssgn_itemacesso (id_funcao, id_recurso, id_fase, id_tagitemmenu) FROM stdin;
\.
COPY dbo.ssgn_itemacesso (id_funcao, id_recurso, id_fase, id_tagitemmenu) FROM '$$PATH$$/5084.dat';

--
-- Data for Name: ssgn_itemmenurecurso; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.ssgn_itemmenurecurso (id_recurso, id_tagitemmenu, nome, id_tagpai, nivel) FROM stdin;
\.
COPY dbo.ssgn_itemmenurecurso (id_recurso, id_tagitemmenu, nome, id_tagpai, nivel) FROM '$$PATH$$/5085.dat';

--
-- Data for Name: ssgn_logjogo; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.ssgn_logjogo (id_logjogo, dh, id_recurso, "Login", tipomensagem, mensagem, id_comandomss, id_comandomcc, id_comandoencadeado, classif, dh_real) FROM stdin;
\.
COPY dbo.ssgn_logjogo (id_logjogo, dh, id_recurso, "Login", tipomensagem, mensagem, id_comandomss, id_comandomcc, id_comandoencadeado, classif, dh_real) FROM '$$PATH$$/5086.dat';

--
-- Data for Name: ssgn_msslog; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.ssgn_msslog (indicemensagem, mensagem) FROM stdin;
\.
COPY dbo.ssgn_msslog (indicemensagem, mensagem) FROM '$$PATH$$/5087.dat';

--
-- Data for Name: ssgn_papeisaplicfuncao; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.ssgn_papeisaplicfuncao (id_funcao, id_papel) FROM stdin;
\.
COPY dbo.ssgn_papeisaplicfuncao (id_funcao, id_papel) FROM '$$PATH$$/5088.dat';

--
-- Data for Name: ssgn_recurso; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.ssgn_recurso (id_recurso, recurso, descricaorecurso) FROM stdin;
\.
COPY dbo.ssgn_recurso (id_recurso, recurso, descricaorecurso) FROM '$$PATH$$/5089.dat';

--
-- Data for Name: ssgn_recursologistico; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.ssgn_recursologistico (id_recursologistico, nome, categoria) FROM stdin;
\.
COPY dbo.ssgn_recursologistico (id_recursologistico, nome, categoria) FROM '$$PATH$$/5090.dat';

--
-- Data for Name: ssgn_temp_verificacaoidentificador; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.ssgn_temp_verificacaoidentificador (taguso, identificador, id_partido, "Login", id_exportacao, elemento, dh_criacao) FROM stdin;
\.
COPY dbo.ssgn_temp_verificacaoidentificador (taguso, identificador, id_partido, "Login", id_exportacao, elemento, dh_criacao) FROM '$$PATH$$/5091.dat';

--
-- Data for Name: ssgn_tipocomponente; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.ssgn_tipocomponente (id_tipocomponente, nome, icone, grupo, treenode, nomearmamento, persistenciaencadeamento, atualizacaoautomatica, filtraritemraiz) FROM stdin;
\.
COPY dbo.ssgn_tipocomponente (id_tipocomponente, nome, icone, grupo, treenode, nomearmamento, persistenciaencadeamento, atualizacaoautomatica, filtraritemraiz) FROM '$$PATH$$/5092.dat';

--
-- Data for Name: tabeladejogos; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.tabeladejogos (name, size, low, high, cntrltype, phyname, status) FROM stdin;
\.
COPY dbo.tabeladejogos (name, size, low, high, cntrltype, phyname, status) FROM '$$PATH$$/5096.dat';

--
-- Data for Name: tempdano; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.tempdano (id_plataforma, m_percentdanototal, m_duracaomaximareparobase, m_valorapresentado) FROM stdin;
\.
COPY dbo.tempdano (id_plataforma, m_percentdanototal, m_duracaomaximareparobase, m_valorapresentado) FROM '$$PATH$$/5095.dat';

--
-- Data for Name: tempglossario; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.tempglossario (id, compactado, descompactado) FROM stdin;
\.
COPY dbo.tempglossario (id, compactado, descompactado) FROM '$$PATH$$/5097.dat';

--
-- Data for Name: tipodano; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.tipodano (id_tipodano, descricao) FROM stdin;
\.
COPY dbo.tipodano (id_tipodano, descricao) FROM '$$PATH$$/5098.dat';

--
-- Data for Name: tipopropulsao; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.tipopropulsao (id_tipopropulsao, tiporecursologistico, recursologistico, id_tiporecursologistico, id_recursologistico, nome) FROM stdin;
\.
COPY dbo.tipopropulsao (id_tipopropulsao, tiporecursologistico, recursologistico, id_tiporecursologistico, id_recursologistico, nome) FROM '$$PATH$$/5099.dat';

--
-- Data for Name: tiporecursologistico; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.tiporecursologistico (id_tiporecursologistico, id_recursologistico, tiporecursologistico, id_armamento, id_sensor) FROM stdin;
\.
COPY dbo.tiporecursologistico (id_tiporecursologistico, id_recursologistico, tiporecursologistico, id_armamento, id_sensor) FROM '$$PATH$$/5100.dat';

--
-- Data for Name: torpedo; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.torpedo (id_armamento, tipotorpedo, pai, paias, paiasup, nomebusca, agentelancadorabrev, profundidademax, alcancemaximo, veloccorrida) FROM stdin;
\.
COPY dbo.torpedo (id_armamento, tipotorpedo, pai, paias, paiasup, nomebusca, agentelancadorabrev, profundidademax, alcancemaximo, veloccorrida) FROM '$$PATH$$/5131.dat';

--
-- Data for Name: trajeto; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.trajeto (id_trajeto, tipotrajeto, nome, id_partido, "Login") FROM stdin;
\.
COPY dbo.trajeto (id_trajeto, tipotrajeto, nome, id_partido, "Login") FROM '$$PATH$$/5101.dat';

--
-- Data for Name: transitopatrulha; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.transitopatrulha (id_meiosimulado, velocavanco, taxaindiscricao) FROM stdin;
\.
COPY dbo.transitopatrulha (id_meiosimulado, velocavanco, taxaindiscricao) FROM '$$PATH$$/5170.dat';

--
-- Data for Name: transporteaeronave; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.transporteaeronave (id_meiosimulado_platsup, id_meiosimulado_plataer) FROM stdin;
\.
COPY dbo.transporteaeronave (id_meiosimulado_platsup, id_meiosimulado_plataer) FROM '$$PATH$$/5171.dat';

--
-- Data for Name: um; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.um (id_meiosimulado_um, id_formatura, id_areapatrulha, ladodestino, marcacao, distancia, datahoratermino, tipoum, incluidaencadeado) FROM stdin;
\.
COPY dbo.um (id_meiosimulado_um, id_formatura, id_areapatrulha, ladodestino, marcacao, distancia, datahoratermino, tipoum, incluidaencadeado) FROM '$$PATH$$/5172.dat';

--
-- Data for Name: visibilidadepartido; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.visibilidadepartido (id_partido, id_partido_visivel) FROM stdin;
\.
COPY dbo.visibilidadepartido (id_partido, id_partido_visivel) FROM '$$PATH$$/5132.dat';

--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.
COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM '$$PATH$$/4873.dat';

--
-- Data for Name: geocode_settings; Type: TABLE DATA; Schema: tiger; Owner: postgres
--

COPY tiger.geocode_settings (name, setting, unit, category, short_desc) FROM stdin;
\.
COPY tiger.geocode_settings (name, setting, unit, category, short_desc) FROM '$$PATH$$/4877.dat';

--
-- Data for Name: pagc_gaz; Type: TABLE DATA; Schema: tiger; Owner: postgres
--

COPY tiger.pagc_gaz (id, seq, word, stdword, token, is_custom) FROM stdin;
\.
COPY tiger.pagc_gaz (id, seq, word, stdword, token, is_custom) FROM '$$PATH$$/4878.dat';

--
-- Data for Name: pagc_lex; Type: TABLE DATA; Schema: tiger; Owner: postgres
--

COPY tiger.pagc_lex (id, seq, word, stdword, token, is_custom) FROM stdin;
\.
COPY tiger.pagc_lex (id, seq, word, stdword, token, is_custom) FROM '$$PATH$$/4879.dat';

--
-- Data for Name: pagc_rules; Type: TABLE DATA; Schema: tiger; Owner: postgres
--

COPY tiger.pagc_rules (id, rule, is_custom) FROM stdin;
\.
COPY tiger.pagc_rules (id, rule, is_custom) FROM '$$PATH$$/4880.dat';

--
-- Data for Name: topology; Type: TABLE DATA; Schema: topology; Owner: postgres
--

COPY topology.topology (id, name, srid, "precision", hasz) FROM stdin;
\.
COPY topology.topology (id, name, srid, "precision", hasz) FROM '$$PATH$$/4875.dat';

--
-- Data for Name: layer; Type: TABLE DATA; Schema: topology; Owner: postgres
--

COPY topology.layer (topology_id, layer_id, schema_name, table_name, feature_column, feature_type, level, child_id) FROM stdin;
\.
COPY topology.layer (topology_id, layer_id, schema_name, table_name, feature_column, feature_type, level, child_id) FROM '$$PATH$$/4876.dat';

--
-- Name: topology_id_seq; Type: SEQUENCE SET; Schema: topology; Owner: postgres
--

SELECT pg_catalog.setval('topology.topology_id_seq', 1, false);


--
-- PostgreSQL database dump complete
--

